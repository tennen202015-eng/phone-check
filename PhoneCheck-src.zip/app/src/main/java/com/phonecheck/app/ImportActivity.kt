package com.phonecheck.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/**
 * استلام تقرير زبون على جوال المحل:
 * الزبون يرسل التقرير (مشاركة سريعة أو واتساب)، وصاحب المحل يختار "فاحص الجوال"،
 * فيتحفظ التقرير في سجل المحل ويفتح السجل.
 * اسم الملف من جوال الزبون: DW-xxxxxx-XXXX__اسم الجهاز__التقييم__q|f.pdf
 */
class ImportActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            Intent.ACTION_VIEW -> intent.data
            else -> null
        }
        val ok = uri?.let { importPdf(it) } ?: false
        Toast.makeText(
            this,
            if (ok) tr("تم حفظ التقرير في السجل ✓", "Report saved to history ✓")
            else tr("تعذّر استلام التقرير", "Could not receive the report"),
            Toast.LENGTH_LONG
        ).show()
        if (ok) startActivity(Intent(this, HistoryActivity::class.java))
        finish()
    }

    private fun importPdf(uri: Uri): Boolean = try {
        // ملف من التطبيق نفسه (مثلاً اخترنا فاحص الجوال لفتح تقرير محفوظ): هو أصلاً في السجل
        require(uri.authority != "$packageName.fileprovider")
        var name = "report.pdf"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val base = name.removeSuffix(".pdf").removeSuffix(".PDF")
        val parts = base.split("__")
        val id = parts[0].takeIf { it.startsWith("DW-") } ?: ("IN-" + System.currentTimeMillis().toString(36).uppercase())
        val device = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: tr("تقرير مستلم", "Received report")
        val score = parts.getOrNull(2)?.toIntOrNull()?.coerceIn(0, 100) ?: 0
        val mode = parts.getOrNull(3)?.takeIf { it == "q" || it == "f" } ?: ""

        // لو نفس التقرير اتسلّم قبل، نحذفه من السجل أول (قبل ما نكتب الملف الجديد)
        History.all(this).filter { it.id == id }.forEach { History.delete(this, it.id) }

        val dir = File(filesDir, "reports").apply { mkdirs() }
        val out = File(dir, "$id.pdf")
        contentResolver.openInputStream(uri)?.use { input ->
            // نتأكد إنه ملف PDF فعلاً
            val head = ByteArray(5)
            val n = input.read(head)
            require(n == 5 && String(head) == "%PDF-")
            out.outputStream().use { o ->
                o.write(head)
                input.copyTo(o)
            }
        } ?: throw IllegalStateException("no stream")

        History.add(this, HistoryEntry(id, System.currentTimeMillis(), device, score, false, out.absolutePath, mode))
        true
    } catch (e: Exception) {
        false
    }
}
