package com.phonecheck.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class HistoryEntry(
    val id: String,
    val ts: Long,
    val device: String,
    val score: Int,
    val remote: Boolean,
    val path: String,
    /** نوع الفحص: "q" سريع، "f" كامل، "" غير معروف (تقارير قديمة أو عن بُعد) */
    val mode: String = "",
)

/** سجل الفحوصات السابقة، محفوظ في الجهاز فقط */
object History {
    private const val PREFS = "history"
    private const val KEY = "entries"
    private const val MAX = 200

    fun all(ctx: Context): List<HistoryEntry> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryEntry(
                    o.getString("id"), o.getLong("ts"), o.getString("device"),
                    o.getInt("score"), o.optBoolean("remote"), o.getString("path"),
                    o.optString("mode", ""),
                )
            }.filter { File(it.path).exists() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, e: HistoryEntry) {
        val list = (listOf(e) + all(ctx)).toMutableList()
        while (list.size > MAX) File(list.removeAt(list.size - 1).path).delete()
        save(ctx, list)
    }

    fun delete(ctx: Context, id: String) {
        val list = all(ctx).toMutableList()
        list.filter { it.id == id }.forEach { File(it.path).delete() }
        save(ctx, list.filter { it.id != id })
    }

    fun clear(ctx: Context) {
        all(ctx).forEach { File(it.path).delete() }
        save(ctx, emptyList())
    }

    private fun save(ctx: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("ts", it.ts).put("device", it.device)
                    .put("score", it.score).put("remote", it.remote).put("path", it.path)
                    .put("mode", it.mode)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
