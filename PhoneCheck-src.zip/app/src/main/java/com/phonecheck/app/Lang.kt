package com.phonecheck.app

import android.content.Context
import android.view.View
import java.util.Locale

/**
 * لغة التطبيق: عربي أو إنجليزي. تنحفظ في الجهاز.
 * أول تشغيل: نتبع لغة الجوال (عربي لو الجوال عربي، وإلا إنجليزي).
 */
object Lang {
    private const val PREFS = "settings"
    private const val KEY = "lang_en"

    var en: Boolean = false
        private set
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        en = if (p.contains(KEY)) p.getBoolean(KEY, false) else Locale.getDefault().language != "ar"
        ready = true
    }

    fun set(ctx: Context, english: Boolean) {
        en = english
        ready = true
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, english).apply()
    }

    val dir: Int get() = if (en) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
    val textDir: Int get() = if (en) View.TEXT_DIRECTION_LTR else View.TEXT_DIRECTION_RTL
}

/** النص بالعربي أو الإنجليزي حسب لغة التطبيق */
fun tr(ar: String, en: String): String = if (Lang.en) en else ar
