package com.phonecheck.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * حرق الشاشة وتجانس الإضاءة:
 * الرمادي المتوسط يكشف الحرق (ظل الكيبورد أو شريط الإشعارات)،
 * والرمادي الغامق يكشف البقع والإضاءة غير المتساوية، والأبيض يكشف الاصفرار والظلال على الأطراف.
 */
class BurnInActivity : AppCompatActivity() {

    private val shades = intArrayOf(
        Color.rgb(128, 128, 128),
        Color.rgb(40, 40, 40),
        Color.rgb(200, 200, 200),
        Color.WHITE,
    )
    private val hints by lazy {
        arrayOf(
            tr("ظلال ثابتة (كيبورد، أزرار، شريط علوي)؟", "Fixed ghost images (keyboard, buttons, status bar)?"),
            tr("بقع أو أطراف أفتح من الباقي؟", "Patches or brighter edges?"),
            tr("بقع أو خطوط باهتة؟", "Faint blotches or lines?"),
            tr("اصفرار أو ظلال على الأطراف؟", "Yellow tint or shadows at the edges?"),
        )
    }
    private var idx = -1
    private lateinit var screen: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        // أعلى إضاءة عشان الحرق يبان
        window.attributes = window.attributes.also { it.screenBrightness = 1f }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        screen = TextView(this).apply {
            text = tr(
                "خلّ الإضاءة عالية ودقّق في كل شاشة.\nاضغط على الشاشة للانتقال.\n\nللإيقاف اضغط رجوع",
                "Keep brightness high and look closely at each screen.\nTap to continue.\n\nPress Back to stop"
            )
            textSize = 18f
            typeface = Fonts.medium
            gravity = Gravity.CENTER
            setPadding(48, 0, 48, 0)
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setOnClickListener { next() }
        }
        setContentView(screen)
        goFullscreen()
    }

    private fun next() {
        idx++
        if (idx >= shades.size) {
            ask()
            return
        }
        val c = shades[idx]
        screen.setBackgroundColor(c)
        // تلميح صغير في الأسفل يختفي ما يغطي الشاشة
        screen.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        screen.textSize = 13f
        screen.setTextColor(if (Color.red(c) > 128) 0x66000000 else 0x66FFFFFF)
        screen.text = hints[idx] + "\n\n"
    }

    private fun ask() {
        PcDialog(this)
            .setTitle(Test.BURN_IN.title)
            .setMessage(tr(
                "هل لاحظت ظلال ثابتة (حرق) أو بقع أو إضاءة غير متساوية أو اصفرار؟",
                "Did you notice ghost images (burn-in), patches, uneven light or yellow tint?"
            ))
            .setCancelable(false)
            .setPositiveButton(tr("لا، الشاشة سليمة", "No, screen is fine")) { _, _ ->
                setResult(RESULT_OK)
                finish()
            }
            .setNegativeButton(tr("نعم، فيه مشكلة", "Yes, there is an issue")) { _, _ ->
                setResult(RESULT_FIRST_USER)
                finish()
            }
            .setNeutralButton(tr("إعادة", "Repeat")) { _, _ ->
                idx = -1
                next()
            }
            .show()
    }
}
