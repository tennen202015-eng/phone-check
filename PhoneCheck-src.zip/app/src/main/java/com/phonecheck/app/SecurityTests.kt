package com.phonecheck.app

import android.content.Intent
import android.provider.Settings

/**
 * الحسابات وقفل جوجل (FRP):
 * لو حساب جوجل (أو سامسونج/شاومي) لسه مسجل وانعمل ضبط مصنع، الجوال يطلب نفس الحساب
 * ويتقفل على المشتري. أندرويد ما يسمح للتطبيقات تشوف الحسابات، فالتحقق يدوي من الإعدادات.
 */
internal fun MainActivity.testAccounts() {
    cleanup = {}
    PcDialog(this)
        .setTitle(Test.ACCOUNTS.title)
        .setMessage(tr(
            "افتح الحسابات وتأكد إن ما فيه أي حساب مسجل (جوجل، سامسونج، شاومي…).\n\n" +
                "ليش مهم؟ لو الحساب باقي وانعمل ضبط مصنع، الجوال يطلب حساب البائع ويتقفل عليك (قفل FRP).\n\n" +
                "لو الجوال لسه عند البائع، اطلب منه يحذف حساباته قدامك.",
            "Open Accounts and make sure no account is signed in (Google, Samsung, Xiaomi…).\n\n" +
                "Why? If an account remains and the phone is factory reset, it will ask for the seller's account and lock you out (FRP lock).\n\n" +
                "If the seller still has the phone, ask them to remove their accounts in front of you."
        ))
        .setCancelable(false)
        .setPositiveButton(tr("ما فيه حسابات ✓", "No accounts ✓")) { _, _ ->
            Results.details[Test.ACCOUNTS] = tr("الحسابات محذوفة", "Accounts removed")
            record(Test.ACCOUNTS, true)
        }
        .setNegativeButton(tr("فيه حساب مسجل", "An account remains")) { _, _ ->
            Results.details[Test.ACCOUNTS] = tr("فيه حساب مسجل", "Account still signed in")
            record(Test.ACCOUNTS, false)
        }
        .setNeutralButton(tr("فتح الحسابات", "Open accounts")) { _, _ ->
            try {
                startActivity(Intent(Settings.ACTION_SYNC_SETTINGS))
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (e2: Exception) {
                    toast(tr("افتح الإعدادات ← الحسابات", "Open Settings → Accounts"))
                }
            }
            // نرجّع السؤال، ويظهر لما يرجع من الإعدادات
            testAccounts()
        }
        .show()
}
