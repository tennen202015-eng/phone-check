package com.phonecheck.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Base64
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** صفحة التحقق من التقارير (GitHub Pages) */
const val VERIFY_URL = "https://tennen202015-eng.github.io/phone-check-web/verify.html"

/**
 * توقيع التقرير:
 * بيانات التقرير الأساسية تنحط في رمز QR مع توقيع رقمي (ECDSA P-256).
 * لما المشتري يمسح الرمز، صفحة التحقق تتأكد من التوقيع وتعرض البيانات الأصلية،
 * فلو أحد عدّل ملف الـ PDF (غيّر التقييم مثلاً) يبان الفرق.
 */
object ReportTrust {

    // مفتاح التوقيع (المفتاح العام المقابل موجود في verify.html)
    private const val KEY_ID = 1
    private const val PRIVATE_KEY =
        "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgLS0Rgo/4Ha0OxhZRDVQMMo2Mn9DbZDe4pz2by1wxZpmhRANCAAQlBTloQojrTa3tBEzEC9E6aPRtMFl4o+bhMp1GD4x1bKgPKJEs9UoVaUU3i9j6fTiqMfD2GjbSFSb3bM/PSSyg"

    /** IMEI صحيح: 15 رقم وخوارزمية Luhn */
    fun validImei(s: String): Boolean {
        if (s.length != 15 || !s.all { it.isDigit() }) return false
        var sum = 0
        for (i in 0 until 15) {
            var d = s[14 - i] - '0'
            if (i % 2 == 1) {
                d *= 2
                if (d > 9) d -= 9
            }
            sum += d
        }
        return sum % 10 == 0
    }

    /** بصمة قصيرة للجهاز (من معرّف أندرويد، تتغير بعد ضبط المصنع) */
    @SuppressLint("HardwareIds")
    fun deviceTag(ctx: Context): String = try {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        val h = MessageDigest.getInstance("SHA-256").digest((id + Build.MODEL).toByteArray())
        h.take(4).joinToString("") { String.format("%02X", it) }
    } catch (e: Exception) {
        ""
    }

    /** يبني رابط التحقق الموقّع */
    fun signedUrl(
        ctx: Context,
        reportId: String,
        now: Date,
        snap: DeviceSnapshot,
        score: ScoreResult,
        results: Map<Test, Boolean>,
        battery: BatteryReport?,
        body: Cond?,
        screen: Cond?,
        imei: String,
        flags: Int,
        mode: Mode,
    ): String? = try {
        val j = JSONObject()
        j.put("v", 1)
        j.put("k", KEY_ID)
        j.put("id", reportId)
        j.put("ts", now.time / 1000)
        j.put("d", snap.deviceName)
        if (imei.isNotBlank()) j.put("im", imei)
        j.put("dt", deviceTag(ctx))
        j.put("s", score.percent)
        j.put("md", if (mode == Mode.QUICK) "q" else "f")
        j.put("t", score.tested)
        j.put("n", score.total)
        j.put("x", JSONArray(results.filterValues { !it }.keys.map { it.name }))
        battery?.let { b ->
            val bj = JSONObject()
            b.healthPct?.let { bj.put("h", it) }
            bj.put("r", b.verdict)
            j.put("b", bj)
        }
        body?.let { j.put("cb", it.ordinal) }
        screen?.let { j.put("cs", it.ordinal) }
        j.put("fl", flags)
        snap.age?.let { a ->
            j.put("ag", a.score)
            a.launchYear?.let { j.put("ay", it) }
        }
        val data = j.toString().toByteArray(Charsets.UTF_8)

        val key = KeyFactory.getInstance("EC").generatePrivate(
            PKCS8EncodedKeySpec(Base64.decode(PRIVATE_KEY, Base64.DEFAULT))
        )
        val sig = Signature.getInstance("SHA256withECDSA").run {
            initSign(key)
            update(data)
            sign()
        }
        VERIFY_URL + "#" + b64(data) + "." + b64(derToRaw(sig))
    } catch (e: Exception) {
        null
    }

    fun qr(text: String): BitMatrix? = try {
        QRCodeWriter().encode(
            text, BarcodeFormat.QR_CODE, 0, 0,
            mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.MARGIN to 1)
        )
    } catch (e: Exception) {
        null
    }

    private fun b64(b: ByteArray): String =
        Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)

    /** جافا تطلع التوقيع بصيغة DER، والمتصفح يبيه r||s (64 بايت) */
    private fun derToRaw(der: ByteArray): ByteArray {
        var i = 2
        if ((der[1].toInt() and 0x80) != 0) i += der[1].toInt() and 0x7F
        fun readInt(): ByteArray {
            require(der[i].toInt() == 0x02)
            val len = der[i + 1].toInt() and 0xFF
            val v = der.copyOfRange(i + 2, i + 2 + len)
            i += 2 + len
            val trimmed = v.dropWhile { it.toInt() == 0 }.toByteArray()
            return ByteArray(32 - trimmed.size) + trimmed
        }
        val r = readInt()
        val s = readInt()
        return r + s
    }
}
