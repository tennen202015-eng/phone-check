package com.phonecheck.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.telecom.TelecomManager
import kotlin.math.roundToInt

/** فئات الاستخدام في التقرير */
enum class UsageCat(private val ar: String, private val en: String, val color: Int) {
    GAMES("ألعاب", "Games", 0xFFC7432E.toInt()),
    VIDEO("فيديو", "Video", 0xFF7A4BC2.toInt()),
    SOCIAL("تواصل اجتماعي", "Social media", 0xFF2F7DD1.toInt()),
    CALLS("مكالمات ومراسلة", "Calls & messaging", 0xFF1E8E5E.toInt()),
    BROWSING("تصفح", "Browsing", 0xFF0D4450.toInt()),
    MEDIA("صوت وصور", "Audio & photos", 0xFFC98A1B.toInt()),
    WORK("عمل وخرائط", "Productivity & maps", 0xFF5E7076.toInt()),
    OTHER("أخرى", "Other", 0xFFA9B6B9.toInt());

    val label: String get() = tr(ar, en)
}

/** ملف الاستخدام: فئات ونسب فقط، بدون أسماء تطبيقات */
data class UsageProfile(
    val inUseDays: Int?,              // تقريباً من أول تطبيق انثبّت بعد آخر ضبط مصنع
    val recentReset: Boolean,         // الجوال انمسح مؤخراً، فما فيه سجل كافي
    val avgDailyMin: Int?,            // متوسط وقت الشاشة يومياً (آخر 7 أيام)
    val longAvgDailyMin: Int?,        // متوسط يومي على المدى الطويل (حتى 6 شهور)
    val historyDays: Int,             // كم يوم يغطي السجل
    val shares: List<Pair<UsageCat, Int>>, // نسبة كل فئة %
    val gamingMinPerDay: Int,
) {
    /** 0 خفيف، 1 متوسط، 2 ثقيل، 3 ثقيل جداً */
    val intensity: Int?
        get() {
            val m = avgDailyMin ?: longAvgDailyMin ?: return null
            return when {
                m < 120 -> 0
                m < 240 -> 1
                m < 420 -> 2
                else -> 3
            }
        }

    val intensityText: String
        get() = when (intensity) {
            0 -> tr("خفيف", "Light")
            1 -> tr("متوسط", "Moderate")
            2 -> tr("ثقيل", "Heavy")
            3 -> tr("ثقيل جداً", "Very heavy")
            else -> tr("غير معروف", "Unknown")
        }

    val heavyGaming: Boolean
        get() = (shares.firstOrNull { it.first == UsageCat.GAMES }?.second ?: 0) >= 35 || gamingMinPerDay >= 120

    val inUseText: String
        get() {
            val d = inUseDays ?: return tr("غير معروف", "Unknown")
            return when {
                d < 30 -> tr("$d يوم", "$d days")
                d < 365 -> tr("${(d / 30.0).roundToInt()} شهر تقريباً", "about ${(d / 30.0).roundToInt()} months")
                else -> {
                    val y = d / 365.0
                    tr(String.format(java.util.Locale.US, "%.1f سنة تقريباً", y), String.format(java.util.Locale.US, "about %.1f years", y))
                }
            }
        }

    /** جملة الخلاصة */
    val summary: String
        get() {
            if (recentReset) return tr(
                "الجوال انعمل له ضبط مصنع مؤخراً، فما فيه سجل استخدام سابق كافي.",
                "The phone was factory reset recently, so there is not enough previous usage history."
            )
            val top = shares.firstOrNull()
            val calls = shares.firstOrNull { it.first == UsageCat.CALLS }?.second ?: 0
            val hours = (avgDailyMin ?: longAvgDailyMin ?: 0) / 60.0
            val h = String.format(java.util.Locale.US, "%.1f", hours)
            val base = tr("استخدام $intensityText بمتوسط $h ساعة يومياً", "$intensityText use, averaging ${h}h per day")
            val tail = when {
                heavyGaming -> tr("، وأغلبه ألعاب.", ", mostly gaming.")
                calls >= 50 && (intensity ?: 0) <= 1 -> tr("، وأغلبه مكالمات ومراسلة.", ", mostly calls and messaging.")
                top != null && top.second >= 30 -> tr("، وأكثره ${top.first.label}.", ", mostly ${top.first.label.lowercase()}.")
                else -> "."
            }
            return base + tail
        }
}

object UsageAnalyzer {

    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun settingsIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    private val callsPkgs = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "com.facebook.orca",
        "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms",
        "com.google.android.dialer", "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.android.dialer", "com.android.incallui", "com.viber.voip", "com.imo.android.imoim",
        "com.skype.raider", "us.zoom.videomeetings", "com.google.android.apps.tachyon",
    )
    private val browserPkgs = setOf(
        "com.android.chrome", "com.sec.android.app.sbrowser", "org.mozilla.firefox",
        "com.opera.browser", "com.microsoft.emmx", "com.brave.browser", "com.mi.globalbrowser",
    )
    private val videoPkgs = setOf(
        "com.google.android.youtube", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.netflix.mediaclient", "com.shahid.android", "com.osn.go",
    )

    /** يحسب ملف الاستخدام. يشتغل في خلفية لأنه ممكن ياخذ ثانية */
    fun analyze(ctx: Context): UsageProfile {
        val pm = ctx.packageManager
        val now = System.currentTimeMillis()
        val day = 24L * 3600 * 1000
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        // تطبيقات الشاشة الرئيسية (نستبعدها من الفئات) وتطبيق الاتصال الافتراضي
        val launchers = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName }.toSet()
        val dialer = try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage
        } catch (e: Exception) {
            null
        }

        // ---------- عمر الاستخدام: أول تطبيق مستخدم انثبّت ----------
        val userApps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }.toSet()
            .mapNotNull { pkg ->
                try {
                    val info = pm.getPackageInfo(pkg, 0)
                    val sys = (info.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM != 0
                    if (sys || pkg == ctx.packageName) null else info.firstInstallTime
                } catch (e: Exception) {
                    null
                }
            }
        val earliestInstall = userApps.minOrNull()

        // ---------- السجل الطويل: شهري حتى 6 شهور ----------
        val longStats = usm.queryUsageStats(UsageStatsManager.INTERVAL_MONTHLY, now - 183 * day, now)
            .orEmpty().filter { it.totalTimeInForeground > 0 }
        val historyStart = longStats.minOfOrNull { it.firstTimeStamp }
        val historyDays = historyStart?.let { ((now - it) / day).toInt().coerceAtLeast(1) } ?: 0

        // ---------- آخر 7 أيام: يومي ----------
        val weekStats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7 * day, now).orEmpty()

        fun catOf(pkg: String): UsageCat? {
            if (pkg in launchers || pkg == ctx.packageName) return null
            if (pkg in callsPkgs || pkg == dialer) return UsageCat.CALLS
            if (pkg in browserPkgs) return UsageCat.BROWSING
            if (pkg in videoPkgs) return UsageCat.VIDEO
            val ai = try {
                pm.getApplicationInfo(pkg, 0)
            } catch (e: Exception) {
                return UsageCat.OTHER
            }
            if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return UsageCat.GAMES
            return when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> UsageCat.GAMES
                ApplicationInfo.CATEGORY_VIDEO -> UsageCat.VIDEO
                ApplicationInfo.CATEGORY_SOCIAL -> UsageCat.SOCIAL
                ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_IMAGE -> UsageCat.MEDIA
                ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_MAPS, ApplicationInfo.CATEGORY_NEWS -> UsageCat.WORK
                else -> UsageCat.OTHER
            }
        }

        // الفئات من السجل الطويل لو موجود، وإلا من آخر أسبوع
        val source = if (longStats.isNotEmpty()) longStats else weekStats
        val byCat = mutableMapOf<UsageCat, Long>()
        var totalMs = 0L
        for (st in source) {
            val c = catOf(st.packageName) ?: continue
            byCat[c] = (byCat[c] ?: 0L) + st.totalTimeInForeground
            totalMs += st.totalTimeInForeground
        }
        val shares = if (totalMs > 0) {
            byCat.entries.map { it.key to (it.value * 100.0 / totalMs).roundToInt() }
                .filter { it.second > 0 }.sortedByDescending { it.second }
        } else emptyList()
        val gamingPerDay = if (historyDays > 0) ((byCat[UsageCat.GAMES] ?: 0L) / 60000 / historyDays).toInt() else 0

        // ---------- متوسط وقت الشاشة اليومي ----------
        var avgDaily: Int? = null
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val ev = usm.queryEventStats(UsageStatsManager.INTERVAL_DAILY, now - 7 * day, now).orEmpty()
                    .filter { it.eventType == UsageEvents.Event.SCREEN_INTERACTIVE }
                val ms = ev.sumOf { it.totalTime }
                val days = ev.size.coerceAtLeast(1)
                if (ms > 0) avgDaily = (ms / 60000 / days).toInt()
            } catch (e: Exception) {
                // غير مدعوم
            }
        }
        if (avgDaily == null) {
            val ms = weekStats.filter { catOf(it.packageName) != null }.sumOf { it.totalTimeInForeground }
            val days = minOf(7, historyDays.coerceAtLeast(1))
            if (ms > 0) avgDaily = (ms / 60000 / days).toInt()
        }
        val longAvg = if (historyDays > 0 && totalMs > 0 && longStats.isNotEmpty()) (totalMs / 60000 / historyDays).toInt() else null

        val inUseDays = earliestInstall?.let { ((now - it) / day).toInt() }
        val recentReset = (inUseDays != null && inUseDays < 7 && historyDays < 7) || (totalMs == 0L)

        return UsageProfile(
            inUseDays = inUseDays,
            recentReset = recentReset,
            avgDailyMin = avgDaily,
            longAvgDailyMin = longAvg,
            historyDays = historyDays,
            shares = shares,
            gamingMinPerDay = gamingPerDay,
        )
    }
}
