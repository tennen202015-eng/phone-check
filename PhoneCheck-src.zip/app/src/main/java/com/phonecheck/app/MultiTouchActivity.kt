package com.phonecheck.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * اختبار اللمس المتعدد: حط 4 أصابع أو أكثر على الشاشة مع بعض.
 * الشاشة اللي فيها عطل في طبقة اللمس غالباً ما تتعرف على أكثر من إصبع أو إصبعين.
 */
class MultiTouchActivity : AppCompatActivity() {

    private val NEEDED = 4
    private lateinit var status: TextView
    private var best = 0
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        val d = resources.displayMetrics.density
        val frame = FrameLayout(this).apply { setBackgroundColor(BG) }
        frame.addView(Pad(this) { count ->
            if (count > best) best = count
            status.text = statusText(count)
            if (!done && best >= NEEDED) {
                done = true
                status.setTextColor(GREEN)
                status.postDelayed({
                    Results.details[Test.MULTITOUCH] = tr("تعرّف على $best أصابع", "$best fingers detected")
                    setResult(Activity.RESULT_OK)
                    finish()
                }, 900)
            }
        }, FrameLayout.LayoutParams(-1, -1))

        status = TextView(this).apply {
            text = statusText(0)
            textSize = 17f
            typeface = Fonts.bold
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
        }
        frame.addView(status, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = (60 * d).toInt() })

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = Lang.dir
        }
        buttons.addView(chip(tr("ما يتعرف على كل الأصابع", "Not all fingers detected"), 0xDD14272C.toInt()) {
            Results.details[Test.MULTITOUCH] = tr("أقصى عدد أصابع: $best", "Max fingers: $best")
            setResult(RESULT_FIRST_USER)
            finish()
        })
        buttons.addView(View(this), LinearLayout.LayoutParams((10 * d).toInt(), 1))
        buttons.addView(chip(tr("تخطّي", "Skip"), 0x998A989B.toInt()) {
            setResult(RESULT_UNDETERMINED)
            finish()
        })
        frame.addView(buttons, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = (40 * d).toInt() })
        setContentView(frame)
        goFullscreen()
    }

    private fun statusText(now: Int) = tr(
        "حط $NEEDED أصابع على الشاشة مع بعض\nالآن: $now · الأعلى: $best",
        "Place $NEEDED fingers on the screen at once\nNow: $now · Best: $best"
    )

    private fun chip(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        val d = resources.displayMetrics.density
        text = label
        textSize = 14f
        typeface = Fonts.bold
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding((18 * d).toInt(), (12 * d).toInt(), (18 * d).toInt(), (12 * d).toInt())
        background = GradientDrawable().apply {
            cornerRadius = 24 * d
            setColor(color)
        }
        setOnClickListener { onClick() }
    }

    /** يرسم دائرة تحت كل إصبع */
    private class Pad(ctx: Context, val onCount: (Int) -> Unit) : View(ctx) {
        private val colors = intArrayOf(PETROL, GREEN, 0xFFC98A1B.toInt(), 0xFF2F7DD1.toInt(), 0xFF7A4BC2.toInt(), RED)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pts = mutableMapOf<Int, Pair<Float, Float>>()
        private val radius = 42f * ctx.resources.displayMetrics.density

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pts.clear()
                MotionEvent.ACTION_POINTER_UP -> pts.remove(e.getPointerId(e.actionIndex))
                else -> for (i in 0 until e.pointerCount) pts[e.getPointerId(i)] = e.getX(i) to e.getY(i)
            }
            if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) {
                for (i in 0 until e.pointerCount) if (i != e.actionIndex) pts[e.getPointerId(i)] = e.getX(i) to e.getY(i)
            }
            onCount(pts.size)
            invalidate()
            return true
        }

        override fun onDraw(canvas: Canvas) {
            for ((id, xy) in pts) {
                p.color = colors[id % colors.size]
                canvas.drawCircle(xy.first, xy.second, radius, p)
            }
        }
    }
}
