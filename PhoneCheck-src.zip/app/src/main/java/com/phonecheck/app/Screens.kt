package com.phonecheck.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

// شاشات التبويبات: الرئيسية، الاختبارات، التقرير، الجهاز، المزيد

private fun MainActivity.body(): LinearLayout {
    val b = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(4), dp(16), dp(28))
    }
    root.addView(b)
    return b
}

/** ترويسة الشاشات الفرعية */
private fun MainActivity.pageHeader(title: String, sub: String?) {
    val r = dp(28).toFloat()
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(20))
        background = GradientDrawable().apply {
            setColor(PETROL)
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        }
    }
    box.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT))
    box.addView(text(title, 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
    if (!sub.isNullOrBlank()) box.addView(text(sub, 14f, Fonts.regular, LIGHT).apply { setPadding(0, dp(4), 0, 0) })
    root.addView(box)
}

// ---------------- القفل (الترخيص) ----------------
internal fun MainActivity.activationScreen() {
    val code = License.deviceCode(this)
    pageHeader(tr("الفحص الكامل", "Full inspection"), tr(
        "البطارية الحقيقية، والتهنيج، والأعطال المخفية، وقفل الحسابات، والعمر، وتقرير PDF.",
        "Real battery health, lag, hidden faults, account locks, age, and a PDF report."
    ))
    val b = body()
    b.addView(pill(tr("→ رجوع", "← Back"), PETROL, PETROL, filled = false) {
        activationOpen = false
        render()
    }, LinearLayout.LayoutParams(-2, dp(42)).apply { topMargin = dp(14); bottomMargin = dp(4) })

    // ---- فحص كامل لمرة واحدة (للأفراد) ----
    b.addView(sectionHeading(tr("فحص كامل لجوالك (مرة واحدة)", "One-time full check for your phone"), null))
    val passBox = surface().apply { setPadding(dp(18), dp(16), dp(18), dp(18)) }
    if (Pass.valid) {
        passBox.addView(text("⭐ " + tr("الفحص الكامل مفعّل · باقي ${Pass.hoursLeft} ساعة", "Full inspection active · ${Pass.hoursLeft} h left"), 16f, Fonts.bold, GREEN))
    } else {
        passBox.addView(text(tr(
            "1) أرسل كود جهازك للمسؤول واطلب \"فحص كامل\".\n2) بعد الدفع يوصلك رمز، الصقه هنا.\nالرمز يشتغل على هذا الجوال بس، لمدة 24 ساعة.",
            "1) Send your device code to the administrator and request a \"full check\".\n2) After payment you get a code; paste it here.\nThe code works on this phone only, for 24 hours."
        ), 13.5f, Fonts.regular, SLATE).apply { setLineSpacing(0f, 1.3f) })
        passBox.addView(text(code, 24f, Fonts.bold, PETROL).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.1f
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
            setPadding(0, dp(12), 0, 0)
        })
        passBox.addView(pill(tr("أرسل كود جهازي واطلب الفحص الكامل", "Send my device code & request"), PETROL, PETROL, filled = false) {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, tr("أبي فحص كامل لجوالي في تطبيق فاحص الجوال. كود جهازي: ", "I'd like a full check in Phone Check. My device code: ") + code)
                }, tr("طلب الفحص الكامل", "Request full check")))
            } catch (e: Exception) {
                toast(code)
            }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) })
        val passInput = EditText(this).apply {
            hint = tr("الصق رمز الفحص الكامل هنا", "Paste the full-check code here")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            textSize = 13f
            setTextColor(TEXT)
            setHintTextColor(GRAY)
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), LINE)
            }
        }
        passBox.addView(passInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        passBox.addView(pill(tr("تفعيل الفحص الكامل", "Activate full check"), PETROL, Color.WHITE, filled = true) {
            val err = Pass.activate(this, passInput.text.toString())
            if (err == null) {
                activationOpen = false
                toast(tr("تم ✓ الفحص الكامل مفعّل لمدة ${Pass.hoursLeft} ساعة", "Done ✓ Full check active for ${Pass.hoursLeft} h"))
                render()
            } else {
                toast(err)
            }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
    }
    b.addView(passBox, blockParams())

    // ---- حالة الترخيص (المحل) ----
    b.addView(sectionHeading(tr("حالة المحل", "Shop status"), null))
    val status = surface().apply { setPadding(dp(18), dp(18), dp(18), dp(18)) }
    val (title, msg) = when (License.state) {
        License.State.CHECKING -> tr("جاري التحقق…", "Checking…") to tr("لحظة، نتأكد من الترخيص.", "One moment, checking the license.")
        License.State.EXPIRED -> tr("انتهى الاشتراك", "Subscription ended") to tr(
            "اشتراك المحل انتهى. تواصل مع المسؤول لتجديده.",
            "The shop subscription has ended. Contact the administrator to renew."
        )
        License.State.TEMP_ENDED -> tr("انتهى التفعيل المؤقت", "Temporary activation ended") to tr(
            "تفعيل هذا الجوال كان لمدة 24 ساعة للفحص. لو تبي تفحصه مرة ثانية، امسح رمز المحل من جديد.",
            "This phone was activated for 24 hours for inspection. To inspect it again, scan the shop code again."
        )
        License.State.BAD_KEY -> tr("مفتاح المحل غير صحيح", "Invalid shop key") to tr(
            "المفتاح مكتوب غلط أو تغيّر. اطلب من المحل يوريك رمز التفعيل من جديد.",
            "The key is wrong or was changed. Ask the shop to show the activation code again."
        )
        License.State.NEED_INTERNET -> tr("محتاج إنترنت", "Internet needed") to tr(
            "شغّل الإنترنت عشان نتحقق من الترخيص، وبعدين اضغط \"تحقق مرة ثانية\".",
            "Turn on the internet so we can check the license, then tap \"Check again\"."
        )
        License.State.VALID -> tr("مفعّل ✓", "Activated ✓") to (
            tr("صادر من: ", "Issued by: ") + License.holder.ifBlank { "-" } + " · " + licenseText()
        )
        else -> tr("الجوال غير مفعّل", "This phone is not activated") to tr(
            "لو هذا جوال زبون للفحص: امسح رمز التفعيل من جوال المحل.\nلو هذا جوال المحل نفسه: أرسل كود الجهاز للمسؤول.",
            "If this is a customer's phone to inspect: scan the activation code from the shop's phone.\nIf this is the shop's own phone: send the device code to the administrator."
        )
    }
    val bad = License.state == License.State.EXPIRED || License.state == License.State.BAD_KEY
    status.addView(text(title, 20f, Fonts.bold, if (bad) RED else TEXT))
    status.addView(text(msg, 14f, Fonts.regular, SLATE).apply {
        setLineSpacing(0f, 1.25f)
        setPadding(0, dp(6), 0, 0)
    })
    status.addView(pill(tr("تحقق مرة ثانية", "Check again"), PETROL, PETROL, filled = false) {
        toast(tr("جاري التحقق…", "Checking…"))
        License.refresh(this) { render() }
    }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(14) })
    b.addView(status, blockParams())

    // ---- جوال زبون: مفتاح المحل ----
    b.addView(sectionHeading(tr("جوال زبون؟ فعّله بمفتاح المحل", "Customer phone? Activate with the shop key"), null))
    val keyBox = surface().apply { setPadding(dp(18), dp(16), dp(18), dp(18)) }
    keyBox.addView(text(
        tr("التفعيل يدوم 24 ساعة، يكفي لفحص الجوال وإصدار تقريره.", "Activation lasts 24 hours, enough to inspect the phone and issue its report."),
        13.5f, Fonts.regular, SLATE
    ))
    keyBox.addView(pill(tr("امسح رمز التفعيل من جوال المحل", "Scan the activation code from the shop's phone"), PETROL, Color.WHITE, filled = true) {
        scanShopKey()
    }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
    val keyInput = EditText(this).apply {
        hint = tr("أو اكتب المفتاح: XXXX-XXXX", "Or type the key: XXXX-XXXX")
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        filters = arrayOf<InputFilter>(InputFilter.LengthFilter(9))
        textSize = 16f
        typeface = Fonts.medium
        setTextColor(TEXT)
        setHintTextColor(GRAY)
        textDirection = View.TEXT_DIRECTION_LTR
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), LINE)
        }
    }
    keyBox.addView(keyInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    keyBox.addView(pill(tr("تفعيل بالمفتاح", "Activate with key"), PETROL, PETROL, filled = false) {
        val k = License.normKey(keyInput.text.toString())
        if (k.length != 8) {
            toast(tr("المفتاح 8 حروف، مثل K7Q2-M9XD", "The key is 8 characters, like K7Q2-M9XD"))
        } else {
            toast(tr("جاري التفعيل…", "Activating…"))
            License.activateKey(this, k) {
            if (License.unlocked) {
                activationOpen = false
                toast(tr("تم التفعيل ✓ صادر من: ", "Activated ✓ Issued by: ") + License.holder)
            }
            render()
        }
        }
    }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
    b.addView(keyBox, blockParams())

    // ---- جوال المحل: كود الجهاز ----
    b.addView(sectionHeading(tr("جوال المحل؟ أرسل كود الجهاز للمسؤول", "Shop's own phone? Send the device code to the administrator"), null))
    val codeBox = surface().apply { setPadding(dp(18), dp(14), dp(18), dp(18)) }
    codeBox.addView(text(code, 28f, Fonts.bold, PETROL).apply {
        gravity = Gravity.CENTER
        letterSpacing = 0.1f
        textDirection = View.TEXT_DIRECTION_LTR
        setTextIsSelectable(true)
    })
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(12), 0, 0)
    }
    row.addView(pill(tr("نسخ", "Copy"), PETROL, PETROL, filled = false) {
        val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("code", code))
        toast(tr("تم نسخ الكود", "Code copied"))
    }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
    row.addView(pill(tr("إرسال", "Send"), PETROL, PETROL, filled = false) {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, tr("كود جهازي في تطبيق فاحص الجوال: ", "My Phone Check device code: ") + code)
            }, tr("إرسال الكود", "Send code")))
        } catch (e: Exception) {
            toast(code)
        }
    }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
    codeBox.addView(row)
    b.addView(codeBox, blockParams())
}

/** نص مدة الترخيص المتبقية */
internal fun licenseText(): String {
    if (License.mode == License.Mode.KEY) return tr("تفعيل مؤقت · باقي ${License.hoursLeft} ساعة", "Temporary · ${License.hoursLeft} h left")
    val d = License.daysLeft
    return when {
        d > 36500 -> tr("دائم", "Permanent")
        d <= 0 -> tr("منتهي", "Ended")
        else -> tr("باقي $d يوم", "$d days left")
    }
}

/** رمز QR كصورة */
internal fun qrBitmap(text: String, sizePx: Int): android.graphics.Bitmap? {
    val m = ReportTrust.qr(text) ?: return null
    val bmp = android.graphics.Bitmap.createBitmap(sizePx, sizePx, android.graphics.Bitmap.Config.RGB_565)
    val c = android.graphics.Canvas(bmp)
    c.drawColor(Color.WHITE)
    val cell = sizePx.toFloat() / m.width
    val p = android.graphics.Paint().apply { color = Color.BLACK }
    for (y in 0 until m.height) for (x in 0 until m.width) {
        if (m.get(x, y)) c.drawRect(x * cell, y * cell, (x + 1) * cell, (y + 1) * cell, p)
    }
    return bmp
}

/**
 * فحص جوال زبون (من جوال المحل):
 * 1) الزبون يمسح رمز التحميل بكاميرا جواله وينزّل التطبيق.
 * 2) يفتح التطبيق ويمسح رمز التفعيل من جوال المحل، ويشتغل 24 ساعة.
 */
internal fun MainActivity.showCustomerActivation() {
    if (License.mode != License.Mode.DEVICE || License.shopKey.isBlank()) {
        PcDialog(this, track = false)
            .setTitle(tr("فحص جوال زبون", "Inspect a customer's phone"))
            .setMessage(tr(
                "حسابك ما فيه مفتاح محل للحين. اطلب من المسؤول يضيف لك مفتاح من لوحة الإدارة.",
                "Your account has no shop key yet. Ask the administrator to add one from the dashboard."
            ))
            .setPositiveButton(tr("تمام", "OK"), null)
            .show()
        return
    }
    val size = (resources.displayMetrics.widthPixels * 0.55f).toInt()
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(22), dp(6), dp(22), dp(8))
        gravity = Gravity.CENTER_HORIZONTAL
    }
    fun step(n: String, title: String, sub: String, qrText: String) {
        col.addView(text("$n  $title", 15f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, dp(2)) }, LinearLayout.LayoutParams(-1, -2))
        col.addView(text(sub, 13f, Fonts.regular, SLATE), LinearLayout.LayoutParams(-1, -2))
        qrBitmap(qrText, size)?.let { bmp ->
            col.addView(android.widget.ImageView(this).apply { setImageBitmap(bmp) }, LinearLayout.LayoutParams(size, size).apply { topMargin = dp(8) })
        }
    }
    step(
        "1", tr("ثبّت التطبيق على جوال الزبون", "Install the app on the customer's phone"),
        tr("يمسح هذا الرمز بكاميرا جواله، وينزّل التطبيق ويثبّته (يسمح بالتثبيت من مصادر غير معروفة).", "Scan with the phone camera, download and install (allow installing unknown apps)."),
        APK_URL
    )
    step(
        "2", tr("فعّله لمدة 24 ساعة", "Activate it for 24 hours"),
        tr("يفتح التطبيق ويضغط \"امسح رمز التفعيل من جوال المحل\" ويمسح هذا الرمز.", "Open the app, tap \"Scan the activation code\" and scan this code.") +
            "\n" + tr("المفتاح: ", "Key: ") + License.prettyKey(License.shopKey),
        KEY_QR_PREFIX + License.shopKey
    )
    col.addView(text(
        tr(
            "3  بعد الفحص: الزبون يضغط \"إرسال التقرير لجوال المحل\" في تبويب التقرير. على جوالك اختر \"فاحص الجوال\" من المشاركة السريعة، أو لو وصلك واتساب: اضغط على الملف ← مشاركة ← فاحص الجوال. ويتحفظ في سجلك.",
            "3  After the inspection: the customer taps \"Send the report to the shop's phone\" in the Report tab. On your phone choose \"Phone Check\" in Quick Share, or if it arrives on WhatsApp: tap the file → Share → Phone Check. It is saved in your history."
        ),
        12.5f, Fonts.regular, SLATE
    ).apply { setPadding(0, dp(14), 0, 0) }, LinearLayout.LayoutParams(-1, -2))
    PcDialog(this, track = false)
        .setTitle(tr("فحص جوال زبون", "Inspect a customer's phone"))
        .setView(android.widget.ScrollView(this).apply { addView(col) })
        .setPositiveButton(tr("تم", "Done"), null)
        .show()
}

// ---------------- الرئيسية ----------------
internal fun MainActivity.homeTab() {
    root.addView(hero(snapshot))
    val b = body()
    // تنبيه قرب انتهاء الاشتراك
    if (!Access.full) {
        // مجاني: نعرض الطرق لفتح الفحص الكامل
        val card = surface().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
        card.addView(text("🔒  " + tr("افتح الفحص الكامل", "Unlock the full inspection"), 15.5f, Fonts.bold, TEXT))
        card.addView(text(tr(
            "صحة البطارية الحقيقية، والتهنيج، والرام والتخزين، وقفل الحسابات، والعمر والقدرة، وتقرير PDF.\nافحص في محل معتمد (امسح رمز المحل)، أو اطلب فحص كامل لمرة واحدة لجوالك.",
            "Real battery health, lag, RAM and storage, account locks, age & capability, and a PDF report.\nInspect at a certified shop (scan the shop code), or request a one-time full inspection for your phone."
        ), 13.5f, Fonts.regular, SLATE).apply { setPadding(0, dp(4), 0, 0); setLineSpacing(0f, 1.2f) })
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        r.addView(pill(tr("امسح رمز المحل", "Scan shop code"), PETROL, Color.WHITE, filled = true) { scanShopKey() },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) })
        r.addView(pill(tr("فحص كامل لجوالي", "Full check for my phone"), PETROL, PETROL, filled = false) { showUpgrade() },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(6) })
        card.addView(r)
        b.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(4) })
    } else if (!License.unlocked && Pass.valid) {
        b.addView(text(
            tr("⭐ الفحص الكامل مفعّل · باقي ${Pass.hoursLeft} ساعة", "⭐ Full inspection active · ${Pass.hoursLeft} h left"),
            14f, Fonts.medium, PETROL
        ).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(0xFFE3EEF0.toInt())
                cornerRadius = dp(16).toFloat()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(4) })
    } else if (License.mode == License.Mode.KEY) {
        b.addView(text(
            tr("🔑 تفعيل مؤقت من ${License.holder.ifBlank { "المحل" }} · باقي ${License.hoursLeft} ساعة", "🔑 Temporary activation by ${License.holder.ifBlank { "the shop" }} · ${License.hoursLeft} h left"),
            14f, Fonts.medium, PETROL
        ).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(0xFFE3EEF0.toInt())
                cornerRadius = dp(16).toFloat()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(4) })
    } else if (License.daysLeft in 1..3) {
        b.addView(text(
            tr("⏳ الاشتراك ينتهي خلال ${License.daysLeft} يوم. تواصل مع المسؤول للتجديد.", "⏳ Subscription ends in ${License.daysLeft} day(s). Contact the administrator to renew."),
            14f, Fonts.medium, 0xFFA86B0C.toInt()
        ).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(0xFFFDF1DC.toInt())
                cornerRadius = dp(16).toFloat()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(4) })
    }
    val flags = RedFlags.compute(snapshot)
    if (flags.isNotEmpty()) b.addView(flagsBlock(flags), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    b.addView(sectionHeading(tr("أدوات الفحص", "Inspection tools"), null))

    val bat = Results.battery
    val usage = Results.usage
    val tiles = listOf(
        Triple(
            tr("صحة البطارية", "Battery health"),
            bat?.summary ?: tr("فحص عميق 10-20 دقيقة", "10-20 min deep test"),
        ) { startSingle(Test.BATTERY) },
        Triple(
            tr("المعالج والتهنيج", "Processor & lag"),
            Results.perf?.let { p ->
                (if (p.passed) tr("سليم · ", "OK · ") else tr("فيه مشكلة · ", "Issue · ")) + p.summary
            } ?: tr("اختبار ضغط دقيقة ونص", "90-second stress test"),
        ) { startSingle(Test.CPU) },
        Triple(
            tr("الرام والتخزين", "RAM & storage"),
            listOfNotNull(
                Results.map[Test.RAM]?.let { tr("الرام ", "RAM ") + if (it) "✓" else "✗" },
                Results.map[Test.STORAGE]?.let { tr("التخزين ", "Storage ") + if (it) "✓" else "✗" },
            ).joinToString(" · ").ifBlank { tr("فحص الأعطال الخفية", "Find hidden faults") },
        ) { checkMemory() },
        Triple(
            tr("الحسابات وقفل جوجل", "Accounts & Google lock"),
            when (Results.map[Test.ACCOUNTS]) {
                true -> tr("الحسابات محذوفة ✓", "Accounts removed ✓")
                false -> tr("فيه حساب مسجل ✗", "Account signed in ✗")
                null -> tr("تأكد قبل الشراء", "Check before buying")
            },
        ) { startSingle(Test.ACCOUNTS) },
        Triple(
            tr("ملف الاستخدام", "Usage profile"),
            when {
                usage != null -> usage.intensityText
                UsageAnalyzer.hasAccess(this) -> tr("جاري التحليل…", "Analyzing…")
                else -> tr("يحتاج تفعيل", "Needs access")
            },
        ) { goTab(MainActivity.Tab.REPORT) },
        if (License.mode == License.Mode.DEVICE) {
            Triple(tr("فحص جوال زبون", "Customer's phone"), tr("ثبّت وفعّل 24 ساعة", "Install & activate 24 h")) {
                showCustomerActivation()
            }
        } else {
            Triple(tr("سجل الفحوصات", "Inspection history"), tr("${History.all(this).size} تقرير محفوظ", "${History.all(this).size} saved")) {
                startActivity(Intent(this, HistoryActivity::class.java))
            }
        },
    )
    for (i in tiles.indices step 2) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (j in i until minOf(i + 2, tiles.size)) {
            val (t0, sub0, onClick0) = tiles[j]
            // أول 5 مربعات (البطارية، المعالج، الرام والتخزين، الحسابات، الاستخدام) للفحص الكامل
            val lockedTile = !Access.full && j < 5
            val t = if (lockedTile) "🔒 $t0" else t0
            val sub = if (lockedTile) tr("متاح في الفحص الكامل", "In the full inspection") else sub0
            val onClick: () -> Unit = if (lockedTile) ({ showUpgrade() }) else onClick0
            row.addView(tile(t, sub, onClick), LinearLayout.LayoutParams(0, -1, 1f).apply {
                if (j % 2 == 1) marginStart = dp(10)
            })
        }
        b.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
}

private fun MainActivity.tile(title: String, sub: String, onClick: () -> Unit): View {
    val box = surface().apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        minimumHeight = dp(96)
        foreground = getDrawable(rippleRes())
        isClickable = true
        setOnClickListener { onClick() }
    }
    box.addView(text(title, 15f, Fonts.bold, TEXT))
    box.addView(text(sub, 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(4), 0, 0) })
    return box
}

/** صندوق "تنبيهات مهمة" */
private fun MainActivity.flagsBlock(flags: List<RedFlag>): View {
    val severe = flags.any { it.severe }
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(if (severe) FAIL_BG else 0xFFFDF1DC.toInt())
            cornerRadius = dp(20).toFloat()
        }
    }
    box.addView(text("⚠  " + tr("تنبيهات مهمة", "Important warnings"), 16f, Fonts.bold, if (severe) RED else 0xFFA86B0C.toInt()))
    for (f in flags.take(8)) {
        box.addView(text("•  " + f.text, 14f, Fonts.regular, if (f.severe) RED else TEXT).apply {
            setPadding(0, dp(6), 0, 0)
        })
    }
    if (flags.size > 8) {
        box.addView(text(tr("+${flags.size - 8} في التقرير", "+${flags.size - 8} more in the report"), 13f, Fonts.regular, SLATE).apply {
            setPadding(0, dp(6), 0, 0)
        })
    }
    return box
}

private fun MainActivity.hero(snap: DeviceSnapshot?): View {
    val r = dp(28).toFloat()
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(20), dp(14), dp(20), dp(24))
        background = GradientDrawable().apply {
            setColor(PETROL)
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        }
    }

    val top = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    top.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(0, -2, 1f))
    top.addView(chip(if (Lang.en) "العربية" else "English") { switchLanguage() })
    box.addView(top, LinearLayout.LayoutParams(-1, -2))

    box.addView(
        text(snap?.deviceName ?: "", 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(6), 0, 0) },
        LinearLayout.LayoutParams(-1, -2)
    )

    val sc = snap?.let { Scoring.compute(it, Results.map) }

    // الحلقة والرقم في وسطها
    val ringBox = FrameLayout(this)
    val ring = ScoreRing(this).apply { segments = orderedTests.map { Results.map[it] } }
    ringBox.addView(ring, FrameLayout.LayoutParams(-1, -1))
    val center = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
    }
    center.addView(text(sc?.percent?.toString() ?: "—", 64f, Fonts.bold, Color.WHITE).apply {
        gravity = Gravity.CENTER
        includeFontPadding = false
    })
    center.addView(text(tr("من 100", "out of 100"), 14f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER })
    ringBox.addView(center, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
    box.addView(ringBox, LinearLayout.LayoutParams(dp(224), dp(224)).apply { topMargin = dp(12) })
    if (!ringAnimated) {
        ringAnimated = true
        ring.animateIn()
    }

    if (sc != null) {
        box.addView(
            text(sc.grade, 20f, Fonts.bold, Scoring.ringGradeColor(sc.percent)).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = -dp(34) }
        )
        val note = when {
            sc.tested == 0 -> tr("التقييم الحالي من الفحص التلقائي فقط.\nاختر نوع الفحص تحت.", "Current score is from the automatic check only.\nChoose an inspection type below.")
            sc.tested < sc.total -> Results.reportMode.label + " · " + tr("مبني على ${sc.tested} من ${sc.total} اختبار", "based on ${sc.tested} of ${sc.total} tests")
            else -> Results.reportMode.label + " · " + tr("اكتملت كل الاختبارات", "all tests completed")
        }
        box.addView(
            text(note, 13f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) }
        )
        // التقييم الثاني: العمر والقدرة (منفصل عن الحالة)
        snap?.age?.let { a ->
            box.addView(
                text(tr("الحالة ", "Condition ") + "${sc.percent}" + "   ·   " + tr("العمر والقدرة: ", "Age & capability: ") + (if (Access.full) a.summary else "🔒"), 13.5f, Fonts.medium, Color.WHITE).apply {
                    if (!Access.full) setOnClickListener { showUpgrade() }
                    gravity = Gravity.CENTER
                    setPadding(dp(14), dp(7), dp(14), dp(8))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(18).toFloat()
                        setColor(0x22FFFFFF)
                    }
                },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) }
            )
        }
    }
    box.addView(modeButtons(onDark = true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
    return box
}

/**
 * أزرار الفحص السريع والكامل، وتتحول لزر "إيقاف الفحص" وقت التشغيل.
 * السريع: 5-7 دقائق بدون البطارية العميقة والـ GPS. الكامل: كل الاختبارات.
 */
private fun MainActivity.modeButtons(onDark: Boolean): View {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (running()) {
        box.addView(
            pill(
                tr("إيقاف الفحص", "Stop inspection"),
                if (onDark) Color.WHITE else RED, if (onDark) Color.WHITE else RED, filled = false
            ) { stopRun() },
            LinearLayout.LayoutParams(-1, dp(52))
        )
        return box
    }
    val modes = if (Access.full) listOf(Mode.QUICK, Mode.FULL) else listOf(Mode.FREE)
    for (m in modes) {
        val left = m.tests.count { it !in Results.map }
        val label = if (m == Mode.FREE) when {
            left == 0 -> tr("أعد الفحص المجاني", "Redo free check")
            Results.mode == m && left < m.tests.size -> tr("أكمل الفحص المجاني ($left متبقية)", "Continue free check ($left left)")
            else -> tr("ابدأ الفحص المجاني · ${m.tests.size} اختبار", "Start free check · ${m.tests.size} tests")
        } else when {
            left == 0 -> if (m == Mode.QUICK) tr("أعد الفحص السريع", "Redo quick inspection") else tr("أعد الفحص الكامل", "Redo full inspection")
            Results.mode == m && left < m.tests.size ->
                if (m == Mode.QUICK) tr("أكمل الفحص السريع ($left متبقية)", "Continue quick ($left left)")
                else tr("أكمل الفحص الكامل ($left متبقية)", "Continue full ($left left)")
            m == Mode.QUICK -> tr("فحص سريع · 5-7 دقائق", "Quick inspection · 5-7 min")
            else -> tr("فحص كامل · 30-40 دقيقة", "Full inspection · 30-40 min")
        }
        val primary = m == Mode.QUICK || m == Mode.FREE
        // إعادة الفحص تمسح النتائج الحالية، فنتأكد قبلها
        val go: () -> Unit = {
            if (Results.map.isNotEmpty() && (left == 0 || Mode.FULL.tests.all { it in Results.map })) {
                PcDialog(this, track = false)
                    .setTitle(m.label)
                    .setMessage(tr(
                        "بتنمسح نتائج الفحص الحالية ويبدأ فحص جديد من الأول.\nلو تبي تحتفظ فيها، اعمل التقرير أول (من تبويب التقرير).",
                        "Current results will be cleared and a new inspection starts from scratch.\nTo keep them, create the report first (Report tab)."
                    ))
                    .setPositiveButton(tr("ابدأ من جديد", "Start over")) { _, _ ->
                        Results.clearTests()
                        runMode(m)
                    }
                    .setNegativeButton(tr("إلغاء", "Cancel"), null)
                    .show()
            } else {
                runMode(m)
            }
        }
        val btn = when {
            onDark && primary -> pill(label, Color.WHITE, PETROL, filled = true) { go() }
            onDark -> pill(label, Color.WHITE, Color.WHITE, filled = false) { go() }
            primary -> pill(label, PETROL, Color.WHITE, filled = true) { go() }
            else -> pill(label, PETROL, PETROL, filled = false) { go() }
        }
        box.addView(btn, LinearLayout.LayoutParams(-1, dp(52)).apply { if (!primary) topMargin = dp(10) })
    }
    if (!Access.full) {
        val up = if (onDark) pill("🔒  " + tr("الفحص الكامل: البطارية والمعالج والأعطال المخفية", "Full inspection: battery, processor & hidden faults"), Color.WHITE, Color.WHITE, filled = false) { showUpgrade() }
        else pill("🔒  " + tr("الفحص الكامل: البطارية والمعالج والأعطال المخفية", "Full inspection: battery, processor & hidden faults"), PETROL, PETROL, filled = false) { showUpgrade() }
        up.textSize = 13.5f
        box.addView(up, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
    }
    box.addView(
        text(
            if (!Access.full) tr(
                "المجاني يفحص الشاشة والصوت والكاميرات والأزرار والاتصال. الكامل يكشف العيوب المخفية: صحة البطارية الحقيقية، والتهنيج، والرام والتخزين، وقفل الحسابات، ويطلع تقرير PDF.",
                "The free check covers screen, audio, cameras, buttons and connectivity. The full inspection reveals hidden faults: real battery health, lag, RAM and storage, account locks, and gives a PDF report."
            ) else tr(
                "السريع يكشف الأعطال الواضحة. الكامل يضيف فحص البطارية العميق (على الشاحن) والـ GPS والحساسات.",
                "Quick finds obvious faults. Full adds the deep battery test (on the charger), GPS and sensors."
            ),
            12.5f, Fonts.regular, if (onDark) LIGHT else SLATE
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), 0)
        }
    )
    return box
}

// ---------------- الاختبارات ----------------
internal fun MainActivity.testsTab() {
    pageHeader(
        tr("الاختبارات", "Tests"),
        tr("${Results.map.size} من ${Test.values().size} مكتملة · اضغط أي اختبار لتشغيله لحاله", "${Results.map.size} of ${Test.values().size} done · tap any test to run it alone")
    )
    val b = body()
    b.addView(modeButtons(onDark = false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
    val quick = Mode.QUICK.tests
    for (g in TEST_GROUPS) {
        b.addView(sectionHeading(g.name, "${g.tests.count { it in Results.map }}/${g.tests.size}"))
        val box = surface()
        g.tests.forEachIndexed { i, t ->
            if (i > 0) box.addView(divider(dp(56)))
            box.addView(testRow(t, Access.full && t !in quick))
        }
        b.addView(box, blockParams())
    }
}

private fun MainActivity.testRow(t: Test, fullOnly: Boolean): View {
    val r = Results.map[t]
    val locked = Access.locked(t)
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(13), dp(16), dp(13))
        setBackgroundResource(rippleRes())
        setOnClickListener { if (locked) showUpgrade() else startSingle(t) }
    }
    row.addView(statusMark(r), LinearLayout.LayoutParams(dp(28), dp(28)))
    val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    titles.addView(text(t.title, 15f, Fonts.medium, TEXT))
    val sub = listOfNotNull(
        Results.details[t],
        if (fullOnly && r == null) tr("في الفحص الكامل فقط", "Full inspection only") else null,
        if (locked) tr("🔒 متاح في الفحص الكامل", "🔒 Available in the full inspection") else null,
    ).joinToString(" · ")
    if (sub.isNotBlank()) titles.addView(text(sub, 12f, Fonts.regular, SLATE))
    row.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
    row.addView(
        when {
            locked -> text("🔒", 16f, Fonts.bold, SLATE)
            r == null -> text(tr("ابدأ", "Start"), 14f, Fonts.bold, PETROL)
            else -> text(tr("إعادة", "Retest"), 14f, Fonts.medium, SLATE)
        }
    )
    return row
}

// ---------------- التقرير ----------------
internal fun MainActivity.reportTab() {
    pageHeader(tr("التقرير", "Report"), tr("رقم الجهاز، الحالة الخارجية، ملف الاستخدام، وإنشاء التقرير", "IMEI, condition, usage profile and report"))
    val b = body()
    val flags = RedFlags.compute(snapshot)
    if (flags.isNotEmpty()) b.addView(flagsBlock(flags), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
    if (!Access.full) {
        // المجاني: النتائج على الشاشة فقط، والتقرير في الفحص الكامل
        val card = surface().apply { setPadding(dp(18), dp(16), dp(18), dp(18)) }
        card.addView(text("🔒  " + tr("تقرير PDF في الفحص الكامل", "PDF report with the full inspection"), 16f, Fonts.bold, TEXT))
        card.addView(text(tr(
            "نتائج الفحص المجاني تظهر في تبويب الاختبارات. التقرير الكامل (PDF) فيه البطارية والمعالج والأعطال المخفية والعمر ومواصفات الجهاز كاملة ورمز تحقق.",
            "Free check results appear in the Tests tab. The full PDF report includes battery, processor, hidden faults, age, full device specs and a verification code."
        ), 13.5f, Fonts.regular, SLATE).apply { setPadding(0, dp(6), 0, 0); setLineSpacing(0f, 1.2f) })
        card.addView(pill(tr("افتح الفحص الكامل", "Unlock the full inspection"), PETROL, Color.WHITE, filled = true) { showUpgrade() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(14) })
        b.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        return
    }
    b.addView(sectionHeading(tr("إنشاء التقرير", "Create report"), null))
    b.addView(reportBlock(), blockParams())
    b.addView(sectionHeading(tr("رقم IMEI", "IMEI number"), null))
    b.addView(imeiBlock(), blockParams())
    b.addView(sectionHeading(tr("الحالة الخارجية", "Cosmetic condition"), null))
    b.addView(conditionBlock(), blockParams())
    b.addView(sectionHeading(tr("ملف الاستخدام", "Usage profile"), null))
    b.addView(usageBlock(), blockParams())
}

private fun MainActivity.reportBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
    box.addView(
        text(
            tr(
                "ملف PDF بشعار الشركة، فيه رقم تقرير والتقييم ونتيجة كل اختبار والحالة الخارجية ومواصفات الجهاز، ورمز QR موقّع رقمياً يقدر أي أحد يمسحه ويتأكد إن التقرير أصلي وما انعدّل. ينحفظ في السجل تلقائياً.",
                "A branded PDF with a report number, score, every test result, cosmetic condition and device specs, plus a digitally signed QR code anyone can scan to confirm the report is genuine and unaltered. Saved to History automatically."
            ),
            14f, Fonts.regular, SLATE
        ).apply { setLineSpacing(0f, 1.25f) }
    )
    val btns = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(14), 0, 0)
    }
    btns.addView(
        pill(tr("عرض التقرير", "View report"), PETROL, Color.WHITE, filled = true) { openReport(false) },
        LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
    )
    btns.addView(
        pill(tr("مشاركة", "Share"), PETROL, PETROL, filled = false) { openReport(true) },
        LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
    )
    box.addView(btns)
    if (License.mode == License.Mode.KEY && License.unlocked) {
        box.addView(pill(
            tr("إرسال التقرير لجوال المحل", "Send the report to the shop's phone"), PETROL, Color.WHITE, filled = true
        ) { sendReportToShop() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
        box.addView(text(tr(
            "اختر \"فاحص الجوال\" على جوال المحل (مشاركة سريعة) أو أرسله واتساب، ويتحفظ في سجل المحل.",
            "Choose \"Phone Check\" on the shop's phone (Quick Share) or send via WhatsApp; it is saved in the shop's history."
        ), 12.5f, Fonts.regular, SLATE).apply { setPadding(0, dp(8), 0, 0) })
    } else if (!License.unlocked) {
        box.addView(text(tr(
            "⚠ التقرير الحالي \"فحص ذاتي\" غير معتمد. للتقرير المعتمد افحص الجوال في محل مشترك.",
            "⚠ This report is an uncertified \"self-check\". For a certified report, inspect the phone at a subscribed shop."
        ), 12.5f, Fonts.medium, 0xFFA86B0C.toInt()).apply { setPadding(0, dp(10), 0, 0) })
    }
    return box
}

/** رقم IMEI: يربط التقرير بالجوال نفسه (أندرويد ما يسمح للتطبيقات تقراه، فيندخل يدوياً) */
private fun MainActivity.imeiBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
    box.addView(text(
        tr(
            "اكتب رقم IMEI عشان التقرير يرتبط بهذا الجوال بالذات. اطلب الرمز *#06# من شاشة الاتصال ويطلع لك الرقم.",
            "Enter the IMEI so the report is tied to this exact phone. Dial *#06# to show it."
        ),
        13f, Fonts.regular, SLATE
    ).apply { setLineSpacing(0f, 1.25f) })

    val status = text("", 13f, Fonts.medium, SLATE).apply { setPadding(0, dp(6), 0, 0) }
    fun showStatus(v: String) {
        when {
            v.isEmpty() -> {
                status.text = tr("غير مُدخل", "Not entered")
                status.setTextColor(SLATE)
            }
            ReportTrust.validImei(v) -> {
                status.text = tr("رقم صحيح ✓", "Valid number ✓")
                status.setTextColor(GREEN)
            }
            v.length < 15 -> {
                status.text = tr("${v.length} من 15 رقم", "${v.length} of 15 digits")
                status.setTextColor(SLATE)
            }
            else -> {
                status.text = tr("الرقم غير صحيح، راجعه", "Invalid number, check it")
                status.setTextColor(RED)
            }
        }
    }

    val input = EditText(this).apply {
        setText(Results.imei)
        hint = "35xxxxxxxxxxxxx"
        inputType = InputType.TYPE_CLASS_NUMBER
        filters = arrayOf<InputFilter>(InputFilter.LengthFilter(15))
        textSize = 17f
        typeface = Fonts.medium
        letterSpacing = 0.06f
        setTextColor(TEXT)
        setHintTextColor(GRAY)
        textDirection = View.TEXT_DIRECTION_LTR
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), LINE)
        }
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString().orEmpty().filter { it.isDigit() }
                Results.imei = v
                showStatus(v)
            }
        })
    }
    box.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    box.addView(status)
    showStatus(Results.imei)
    box.addView(pill(tr("اعرض رقم IMEI (*#06#)", "Show IMEI (*#06#)"), PETROL, PETROL, filled = false) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode("*#06#"))))
        } catch (e: Exception) {
            toast(tr("افتح الاتصال واكتب *#06#", "Open the dialer and type *#06#"))
        }
    }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) })
    return box
}

/** الحالة الخارجية: الهيكل والشاشة وملاحظات، تدخل في التقرير */
private fun MainActivity.conditionBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
    box.addView(text(tr("حدّد حالة الجوال من الخارج بعينك، وتظهر في التقرير.", "Rate the outside of the phone by eye. It appears in the report."), 13f, Fonts.regular, SLATE))

    fun condRow(title: String, current: Cond?, set: (Cond?) -> Unit) {
        box.addView(text(title, 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(14), 0, dp(8)) })
        val wrap = FlowRow(this)
        for (c in Cond.values()) {
            val selected = c == current
            val chipView = TextView(this)
            chipView.text = c.label
            chipView.textSize = 13f
            chipView.typeface = if (selected) Fonts.bold else Fonts.medium
            chipView.setTextColor(if (selected) Color.WHITE else TEXT)
            chipView.setPadding(dp(14), dp(8), dp(14), dp(8))
            chipView.background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                if (selected) setColor(PETROL) else setStroke(dp(1), LINE)
            }
            chipView.setOnClickListener {
                set(if (selected) null else c)
                render()
            }
            wrap.addView(chipView)
        }
        box.addView(wrap, LinearLayout.LayoutParams(-1, -2))
    }
    condRow(tr("الهيكل والإطار", "Body & frame"), Results.body) { Results.body = it }
    condRow(tr("زجاج الشاشة", "Screen glass"), Results.screen) { Results.screen = it }

    box.addView(text(tr("ملاحظات", "Notes"), 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(14), 0, dp(8)) })
    val notes = EditText(this).apply {
        setText(Results.notes)
        hint = tr("مثلاً: البطارية مغيّرة، فيه ضمان لين 2027، الكرتون موجود…", "e.g. battery replaced, warranty until 2027, box included…")
        textSize = 14f
        typeface = Fonts.regular
        setTextColor(TEXT)
        setHintTextColor(GRAY)
        minLines = 2
        gravity = Gravity.TOP or Gravity.START
        textDirection = Lang.textDir
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), LINE)
        }
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Results.notes = s?.toString().orEmpty().take(400)
            }
        })
    }
    box.addView(notes, LinearLayout.LayoutParams(-1, -2))
    return box
}

private fun MainActivity.usageBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
    if (!UsageAnalyzer.hasAccess(this)) {
        box.addView(text(tr(
            "يقرأ سجل استخدام الجوال: من متى مستخدم، ومتوسط الشاشة يومياً، ومستوى الاستخدام، وتوزيعه (ألعاب، فيديو، تواصل…). يعرض فئات ونسب فقط بدون أسماء تطبيقات.",
            "Reads the phone's usage history: how long it has been in use, average daily screen time, usage level and breakdown (games, video, social…). Shows categories and shares only, no app names."
        ), 14f, Fonts.regular, SLATE).apply { setLineSpacing(0f, 1.25f) })
        box.addView(text(tr(
            "ملاحظة: ضبط المصنع يمسح هذا السجل، فأفضل وقت للفحص قبل مسح الجوال.",
            "Note: a factory reset erases this history, so run it before the phone is wiped."
        ), 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(8), 0, 0) })
        box.addView(pill(tr("تفعيل الوصول لبيانات الاستخدام", "Allow usage access"), PETROL, Color.WHITE, filled = true) {
            try {
                startActivity(UsageAnalyzer.settingsIntent())
                toast(tr("اختر \"فاحص الجوال\" وفعّل السماح، ثم ارجع", "Select \"Phone Check\", allow access, then come back"))
            } catch (e: Exception) {
                toast(tr("افتح الإعدادات ← التطبيقات ← الوصول الخاص ← الوصول لبيانات الاستخدام", "Open Settings → Apps → Special access → Usage access"))
            }
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
        return box
    }
    val u = Results.usage
    if (u == null) {
        box.addView(text(tr("جاري تحليل سجل الاستخدام…", "Analyzing usage history…"), 14f, Fonts.medium, SLATE))
        return box
    }
    box.addView(text(u.summary, 16f, Fonts.bold, TEXT).apply { setLineSpacing(0f, 1.25f) })
    if (!u.recentReset) {
        box.addView(statRow(tr("مستخدم منذ", "In use for"), u.inUseText))
        u.avgDailyMin?.let { box.addView(statRow(tr("متوسط الشاشة يومياً", "Daily screen time"), hm(it))) }
        box.addView(statRow(tr("مستوى الاستخدام", "Usage level"), u.intensityText))
        if (u.historyDays > 0) box.addView(statRow(tr("السجل يغطي", "History covers"), tr("${u.historyDays} يوم", "${u.historyDays} days")))
        if (u.shares.isNotEmpty()) {
            box.addView(text(tr("توزيع الاستخدام", "Usage breakdown"), 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(12), 0, dp(6)) })
            for ((cat, pct) in u.shares.take(6)) box.addView(barRow(cat.label, pct, cat.color))
        }
    }
    // إضافة للتقرير
    val inc = Results.usageInReport
    val toggle = text((if (inc) "✓  " else "") + tr("يظهر في التقرير", "Included in report"), 14f, Fonts.bold, if (inc) Color.WHITE else TEXT)
    toggle.gravity = Gravity.CENTER
    toggle.setPadding(dp(14), dp(10), dp(14), dp(10))
    toggle.background = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat()
        if (inc) setColor(PETROL) else setStroke(dp(1), LINE)
    }
    toggle.setOnClickListener {
        Results.usageInReport = !Results.usageInReport
        render()
    }
    box.addView(toggle, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
    return box
}

// ---------------- الجهاز ----------------
internal fun MainActivity.deviceTab() {
    val snap = snapshot
    pageHeader(snap?.deviceName ?: tr("الجهاز", "Device"), tr("مواصفات الجهاز وقراءاته الحالية", "Device specs and current readings"))
    val b = body()
    if (snap == null) {
        b.addView(text(tr("تعذّر قراءة معلومات الجهاز.", "Could not read device info."), 14f, Fonts.regular, SLATE).apply { setPadding(dp(4), dp(16), dp(4), 0) })
        return
    }
    b.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
    val specs = surface()
    // أقسام البطارية والثبات والعمر وسلامة النظام للفحص الكامل
    val lockedTitles = if (Access.full) emptySet() else setOf(
        tr("البطارية", "Battery"), tr("الثبات", "Stability"), tr("العمر والدعم", "Age & support"), tr("سلامة النظام", "System integrity")
    )
    snap.sections.forEachIndexed { i, s ->
        if (s.title in lockedTitles) specs.addView(lockedSection(s.title, i > 0))
        else specs.addView(specSection(s, i > 0))
    }
    b.addView(specs, blockParams())
}

private fun MainActivity.lockedSection(title: String, withDivider: Boolean): View {
    val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (withDivider) wrap.addView(divider(dp(16)))
    val head = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundResource(rippleRes())
        setOnClickListener { showUpgrade() }
    }
    head.addView(text("🔒 $title", 15f, Fonts.medium, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text(tr("الفحص الكامل", "Full inspection"), 13f, Fonts.regular, PETROL))
    wrap.addView(head)
    return wrap
}

private fun MainActivity.specSection(s: InfoSection, withDivider: Boolean): View {
    val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (withDivider) wrap.addView(divider(dp(16)))
    val open = s.title in expanded
    val head = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundResource(rippleRes())
        setOnClickListener {
            if (open) expanded.remove(s.title) else expanded.add(s.title)
            render()
        }
    }
    head.addView(text(s.title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text(if (open) tr("إخفاء", "Hide") else tr("${s.items.size} بنود", "${s.items.size} items"), 13f, Fonts.regular, SLATE))
    head.addView(text(if (open) "▴" else "▾", 14f, Fonts.regular, SLATE).apply { setPaddingRelative(dp(8), 0, 0, 0) })
    wrap.addView(head)
    if (open) {
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(10))
        }
        for (item in s.items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            row.addView(text(item.label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(item.value, 14f, Fonts.medium, TEXT).apply { gravity = Gravity.END })
            list.addView(row)
        }
        wrap.addView(list)
    }
    return wrap
}

// ---------------- المزيد ----------------
internal fun MainActivity.moreTab() {
    pageHeader(tr("المزيد", "More"), null)
    val b = body()
    b.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
    val box = surface()
    fun item(title: String, value: String, onClick: () -> Unit) {
        if (box.childCount > 0) box.addView(divider(dp(16)))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundResource(rippleRes())
            setOnClickListener { onClick() }
        }
        row.addView(text(title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 14f, Fonts.regular, SLATE))
        box.addView(row)
    }
    item(
        tr("التقرير المعتمد", "Certified report"),
        if (License.unlocked) listOf(License.holder, licenseText()).filter { it.isNotBlank() }.joinToString(" · ")
        else tr("غير مفعّل · فحص ذاتي", "Not activated · self-check")
    ) {
        activationOpen = true
        render()
    }
    if (License.mode == License.Mode.DEVICE) {
        item(tr("فحص جوال زبون", "Inspect a customer's phone"), tr("تفعيل 24 ساعة", "24-h activation")) { showCustomerActivation() }
    }
    item(tr("اللغة", "Language"), if (Lang.en) "English" else "العربية") { switchLanguage() }
    item(tr("سجل الفحوصات", "Inspection history"), History.all(this).size.toString()) {
        startActivity(Intent(this, HistoryActivity::class.java))
    }
    item(tr("التحقق من تقرير", "Verify a report"), "") { openUrl(VERIFY_URL + if (Lang.en) "?lang=en" else "") }
    item(tr("سياسة الخصوصية", "Privacy policy"), "") { openUrl(PRIVACY_URL + if (Lang.en) "?lang=en" else "") }
    item(tr("الإصدار", "Version"), versionName()) {}
    b.addView(box, blockParams())
}

private fun MainActivity.versionName(): String = try {
    packageManager.getPackageInfo(packageName, 0).versionName ?: ""
} catch (e: Exception) {
    ""
}
