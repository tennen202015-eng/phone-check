package com.phonecheck.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

// شاشات التبويبات: الرئيسية، الاختبارات، التقرير، الجهاز، المزيد

private fun MainActivity.body(): LinearLayout {
    val b = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(4), dp(16), dp(28))
    }
    root.addView(b)
    return b
}

/** ترويسة الشاشات الفرعية */
private fun MainActivity.pageHeader(title: String, sub: String?) {
    val r = dp(28).toFloat()
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(20))
        background = GradientDrawable().apply {
            setColor(PETROL)
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        }
    }
    box.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT))
    box.addView(text(title, 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
    if (!sub.isNullOrBlank()) box.addView(text(sub, 14f, Fonts.regular, LIGHT).apply { setPadding(0, dp(4), 0, 0) })
    root.addView(box)
}

// ---------------- الرئيسية ----------------
internal fun MainActivity.homeTab() {
    root.addView(hero(snapshot))
    val b = body()
    val flags = RedFlags.compute(snapshot)
    if (flags.isNotEmpty()) b.addView(flagsBlock(flags), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    b.addView(sectionHeading(tr("أدوات الفحص", "Inspection tools"), null))

    val bat = Results.battery
    val usage = Results.usage
    val tiles = listOf(
        Triple(
            tr("صحة البطارية", "Battery health"),
            bat?.summary ?: tr("فحص عميق 10-20 دقيقة", "10-20 min deep test"),
        ) { startSingle(Test.BATTERY) },
        Triple(
            tr("المعالج والتهنيج", "Processor & lag"),
            Results.perf?.let { p ->
                (if (p.passed) tr("سليم · ", "OK · ") else tr("فيه مشكلة · ", "Issue · ")) + p.summary
            } ?: tr("اختبار ضغط دقيقة ونص", "90-second stress test"),
        ) { startSingle(Test.CPU) },
        Triple(
            tr("الرام والتخزين", "RAM & storage"),
            listOfNotNull(
                Results.map[Test.RAM]?.let { tr("الرام ", "RAM ") + if (it) "✓" else "✗" },
                Results.map[Test.STORAGE]?.let { tr("التخزين ", "Storage ") + if (it) "✓" else "✗" },
            ).joinToString(" · ").ifBlank { tr("فحص الأعطال الخفية", "Find hidden faults") },
        ) { checkMemory() },
        Triple(
            tr("الحسابات وقفل جوجل", "Accounts & Google lock"),
            when (Results.map[Test.ACCOUNTS]) {
                true -> tr("الحسابات محذوفة ✓", "Accounts removed ✓")
                false -> tr("فيه حساب مسجل ✗", "Account signed in ✗")
                null -> tr("تأكد قبل الشراء", "Check before buying")
            },
        ) { startSingle(Test.ACCOUNTS) },
        Triple(
            tr("ملف الاستخدام", "Usage profile"),
            when {
                usage != null -> usage.intensityText
                UsageAnalyzer.hasAccess(this) -> tr("جاري التحليل…", "Analyzing…")
                else -> tr("يحتاج تفعيل", "Needs access")
            },
        ) { goTab(MainActivity.Tab.REPORT) },
        Triple(tr("فحص جوال ثاني", "Inspect another phone"), tr("آيفون أو أندرويد", "iPhone or Android")) {
            startActivity(Intent(this, RemoteActivity::class.java))
        },
    )
    for (i in tiles.indices step 2) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (j in i until minOf(i + 2, tiles.size)) {
            val (t, sub, onClick) = tiles[j]
            row.addView(tile(t, sub, onClick), LinearLayout.LayoutParams(0, -1, 1f).apply {
                if (j % 2 == 1) marginStart = dp(10)
            })
        }
        b.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
}

private fun MainActivity.tile(title: String, sub: String, onClick: () -> Unit): View {
    val box = surface().apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        minimumHeight = dp(96)
        foreground = getDrawable(rippleRes())
        isClickable = true
        setOnClickListener { onClick() }
    }
    box.addView(text(title, 15f, Fonts.bold, TEXT))
    box.addView(text(sub, 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(4), 0, 0) })
    return box
}

/** صندوق "تنبيهات مهمة" */
private fun MainActivity.flagsBlock(flags: List<RedFlag>): View {
    val severe = flags.any { it.severe }
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(if (severe) FAIL_BG else 0xFFFDF1DC.toInt())
            cornerRadius = dp(20).toFloat()
        }
    }
    box.addView(text("⚠  " + tr("تنبيهات مهمة", "Important warnings"), 16f, Fonts.bold, if (severe) RED else 0xFFA86B0C.toInt()))
    for (f in flags.take(8)) {
        box.addView(text("•  " + f.text, 14f, Fonts.regular, if (f.severe) RED else TEXT).apply {
            setPadding(0, dp(6), 0, 0)
        })
    }
    if (flags.size > 8) {
        box.addView(text(tr("+${flags.size - 8} في التقرير", "+${flags.size - 8} more in the report"), 13f, Fonts.regular, SLATE).apply {
            setPadding(0, dp(6), 0, 0)
        })
    }
    return box
}

private fun MainActivity.hero(snap: DeviceSnapshot?): View {
    val r = dp(28).toFloat()
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(20), dp(14), dp(20), dp(24))
        background = GradientDrawable().apply {
            setColor(PETROL)
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        }
    }

    val top = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    top.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(0, -2, 1f))
    top.addView(chip(if (Lang.en) "العربية" else "English") { switchLanguage() })
    box.addView(top, LinearLayout.LayoutParams(-1, -2))

    box.addView(
        text(snap?.deviceName ?: "", 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(6), 0, 0) },
        LinearLayout.LayoutParams(-1, -2)
    )

    val sc = snap?.let { Scoring.compute(it, Results.map) }

    // الحلقة والرقم في وسطها
    val ringBox = FrameLayout(this)
    val ring = ScoreRing(this).apply { segments = orderedTests.map { Results.map[it] } }
    ringBox.addView(ring, FrameLayout.LayoutParams(-1, -1))
    val center = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
    }
    center.addView(text(sc?.percent?.toString() ?: "—", 64f, Fonts.bold, Color.WHITE).apply {
        gravity = Gravity.CENTER
        includeFontPadding = false
    })
    center.addView(text(tr("من 100", "out of 100"), 14f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER })
    ringBox.addView(center, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
    box.addView(ringBox, LinearLayout.LayoutParams(dp(224), dp(224)).apply { topMargin = dp(12) })
    if (!ringAnimated) {
        ringAnimated = true
        ring.animateIn()
    }

    if (sc != null) {
        box.addView(
            text(sc.grade, 20f, Fonts.bold, Scoring.ringGradeColor(sc.percent)).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = -dp(34) }
        )
        val note = when {
            sc.tested == 0 -> tr("التقييم الحالي من الفحص التلقائي فقط.\nاختر نوع الفحص تحت.", "Current score is from the automatic check only.\nChoose an inspection type below.")
            sc.tested < sc.total -> Results.reportMode.label + " · " + tr("مبني على ${sc.tested} من ${sc.total} اختبار", "based on ${sc.tested} of ${sc.total} tests")
            else -> Results.reportMode.label + " · " + tr("اكتملت كل الاختبارات", "all tests completed")
        }
        box.addView(
            text(note, 13f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) }
        )
        // التقييم الثاني: العمر والقدرة (منفصل عن الحالة)
        snap?.age?.let { a ->
            box.addView(
                text(tr("الحالة ", "Condition ") + "${sc.percent}" + "   ·   " + tr("العمر والقدرة: ", "Age & capability: ") + a.summary, 13.5f, Fonts.medium, Color.WHITE).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(14), dp(7), dp(14), dp(8))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(18).toFloat()
                        setColor(0x22FFFFFF)
                    }
                },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) }
            )
        }
    }
    box.addView(modeButtons(onDark = true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
    return box
}

/**
 * أزرار الفحص السريع والكامل، وتتحول لزر "إيقاف الفحص" وقت التشغيل.
 * السريع: 5-7 دقائق بدون البطارية العميقة والـ GPS. الكامل: كل الاختبارات.
 */
private fun MainActivity.modeButtons(onDark: Boolean): View {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (running()) {
        box.addView(
            pill(
                tr("إيقاف الفحص", "Stop inspection"),
                if (onDark) Color.WHITE else RED, if (onDark) Color.WHITE else RED, filled = false
            ) { stopRun() },
            LinearLayout.LayoutParams(-1, dp(52))
        )
        return box
    }
    for (m in listOf(Mode.QUICK, Mode.FULL)) {
        val left = m.tests.count { it !in Results.map }
        val label = when {
            left == 0 -> if (m == Mode.QUICK) tr("أعد الفحص السريع", "Redo quick inspection") else tr("أعد الفحص الكامل", "Redo full inspection")
            Results.mode == m && left < m.tests.size ->
                if (m == Mode.QUICK) tr("أكمل الفحص السريع ($left متبقية)", "Continue quick ($left left)")
                else tr("أكمل الفحص الكامل ($left متبقية)", "Continue full ($left left)")
            m == Mode.QUICK -> tr("فحص سريع · 5-7 دقائق", "Quick inspection · 5-7 min")
            else -> tr("فحص كامل · 30-40 دقيقة", "Full inspection · 30-40 min")
        }
        val primary = m == Mode.QUICK
        // إعادة الفحص تمسح النتائج الحالية، فنتأكد قبلها
        val go: () -> Unit = {
            if (Results.map.isNotEmpty() && (left == 0 || Mode.FULL.tests.all { it in Results.map })) {
                PcDialog(this, track = false)
                    .setTitle(m.label)
                    .setMessage(tr(
                        "بتنمسح نتائج الفحص الحالية ويبدأ فحص جديد من الأول.\nلو تبي تحتفظ فيها، اعمل التقرير أول (من تبويب التقرير).",
                        "Current results will be cleared and a new inspection starts from scratch.\nTo keep them, create the report first (Report tab)."
                    ))
                    .setPositiveButton(tr("ابدأ من جديد", "Start over")) { _, _ ->
                        Results.clearTests()
                        runMode(m)
                    }
                    .setNegativeButton(tr("إلغاء", "Cancel"), null)
                    .show()
            } else {
                runMode(m)
            }
        }
        val btn = when {
            onDark && primary -> pill(label, Color.WHITE, PETROL, filled = true) { go() }
            onDark -> pill(label, Color.WHITE, Color.WHITE, filled = false) { go() }
            primary -> pill(label, PETROL, Color.WHITE, filled = true) { go() }
            else -> pill(label, PETROL, PETROL, filled = false) { go() }
        }
        box.addView(btn, LinearLayout.LayoutParams(-1, dp(52)).apply { if (!primary) topMargin = dp(10) })
    }
    box.addView(
        text(
            tr(
                "السريع يكشف الأعطال الواضحة. الكامل يضيف فحص البطارية العميق (على الشاحن) والـ GPS والحساسات، ويطلع تقرير معتمد.",
                "Quick finds obvious faults. Full adds the deep battery test (on the charger), GPS and sensors for a complete report."
            ),
            12.5f, Fonts.regular, if (onDark) LIGHT else SLATE
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), 0)
        }
    )
    return box
}

// ---------------- الاختبارات ----------------
internal fun MainActivity.testsTab() {
    pageHeader(
        tr("الاختبارات", "Tests"),
        tr("${Results.map.size} من ${Test.values().size} مكتملة · اضغط أي اختبار لتشغيله لحاله", "${Results.map.size} of ${Test.values().size} done · tap any test to run it alone")
    )
    val b = body()
    b.addView(modeButtons(onDark = false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
    val quick = Mode.QUICK.tests
    for (g in TEST_GROUPS) {
        b.addView(sectionHeading(g.name, "${g.tests.count { it in Results.map }}/${g.tests.size}"))
        val box = surface()
        g.tests.forEachIndexed { i, t ->
            if (i > 0) box.addView(divider(dp(56)))
            box.addView(testRow(t, t !in quick))
        }
        b.addView(box, blockParams())
    }
}

private fun MainActivity.testRow(t: Test, fullOnly: Boolean): View {
    val r = Results.map[t]
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(13), dp(16), dp(13))
        setBackgroundResource(rippleRes())
        setOnClickListener { startSingle(t) }
    }
    row.addView(statusMark(r), LinearLayout.LayoutParams(dp(28), dp(28)))
    val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    titles.addView(text(t.title, 15f, Fonts.medium, TEXT))
    val sub = listOfNotNull(
        Results.details[t],
        if (fullOnly && r == null) tr("في الفحص الكامل فقط", "Full inspection only") else null,
    ).joinToString(" · ")
    if (sub.isNotBlank()) titles.addView(text(sub, 12f, Fonts.regular, SLATE))
    row.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
    row.addView(
        if (r == null) text(tr("ابدأ", "Start"), 14f, Fonts.bold, PETROL)
        else text(tr("إعادة", "Retest"), 14f, Fonts.medium, SLATE)
    )
    return row
}

// ---------------- التقرير ----------------
internal fun MainActivity.reportTab() {
    pageHeader(tr("التقرير", "Report"), tr("رقم الجهاز، الحالة الخارجية، ملف الاستخدام، وإنشاء التقرير", "IMEI, condition, usage profile and report"))
    val b = body()
    val flags = RedFlags.compute(snapshot)
    if (flags.isNotEmpty()) b.addView(flagsBlock(flags), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
    b.addView(sectionHeading(tr("إنشاء التقرير", "Create report"), null))
    b.addView(reportBlock(), blockParams())
    b.addView(sectionHeading(tr("رقم IMEI", "IMEI number"), null))
    b.addView(imeiBlock(), blockParams())
    b.addView(sectionHeading(tr("الحالة الخارجية", "Cosmetic condition"), null))
    b.addView(conditionBlock(), blockParams())
    b.addView(sectionHeading(tr("ملف الاستخدام", "Usage profile"), null))
    b.addView(usageBlock(), blockParams())
}

private fun MainActivity.reportBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
    box.addView(
        text(
            tr(
                "ملف PDF بشعار الشركة، فيه رقم تقرير والتقييم ونتيجة كل اختبار والحالة الخارجية ومواصفات الجهاز، ورمز QR موقّع رقمياً يقدر أي أحد يمسحه ويتأكد إن التقرير أصلي وما انعدّل. ينحفظ في السجل تلقائياً.",
                "A branded PDF with a report number, score, every test result, cosmetic condition and device specs, plus a digitally signed QR code anyone can scan to confirm the report is genuine and unaltered. Saved to History automatically."
            ),
            14f, Fonts.regular, SLATE
        ).apply { setLineSpacing(0f, 1.25f) }
    )
    val btns = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(14), 0, 0)
    }
    btns.addView(
        pill(tr("عرض التقرير", "View report"), PETROL, Color.WHITE, filled = true) { openReport(false) },
        LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
    )
    btns.addView(
        pill(tr("مشاركة", "Share"), PETROL, PETROL, filled = false) { openReport(true) },
        LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
    )
    box.addView(btns)
    return box
}

/** رقم IMEI: يربط التقرير بالجوال نفسه (أندرويد ما يسمح للتطبيقات تقراه، فيندخل يدوياً) */
private fun MainActivity.imeiBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
    box.addView(text(
        tr(
            "اكتب رقم IMEI عشان التقرير يرتبط بهذا الجوال بالذات. اطلب الرمز *#06# من شاشة الاتصال ويطلع لك الرقم.",
            "Enter the IMEI so the report is tied to this exact phone. Dial *#06# to show it."
        ),
        13f, Fonts.regular, SLATE
    ).apply { setLineSpacing(0f, 1.25f) })

    val status = text("", 13f, Fonts.medium, SLATE).apply { setPadding(0, dp(6), 0, 0) }
    fun showStatus(v: String) {
        when {
            v.isEmpty() -> {
                status.text = tr("غير مُدخل", "Not entered")
                status.setTextColor(SLATE)
            }
            ReportTrust.validImei(v) -> {
                status.text = tr("رقم صحيح ✓", "Valid number ✓")
                status.setTextColor(GREEN)
            }
            v.length < 15 -> {
                status.text = tr("${v.length} من 15 رقم", "${v.length} of 15 digits")
                status.setTextColor(SLATE)
            }
            else -> {
                status.text = tr("الرقم غير صحيح، راجعه", "Invalid number, check it")
                status.setTextColor(RED)
            }
        }
    }

    val input = EditText(this).apply {
        setText(Results.imei)
        hint = "35xxxxxxxxxxxxx"
        inputType = InputType.TYPE_CLASS_NUMBER
        filters = arrayOf<InputFilter>(InputFilter.LengthFilter(15))
        textSize = 17f
        typeface = Fonts.medium
        letterSpacing = 0.06f
        setTextColor(TEXT)
        setHintTextColor(GRAY)
        textDirection = View.TEXT_DIRECTION_LTR
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), LINE)
        }
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString().orEmpty().filter { it.isDigit() }
                Results.imei = v
                showStatus(v)
            }
        })
    }
    box.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    box.addView(status)
    showStatus(Results.imei)
    box.addView(pill(tr("اعرض رقم IMEI (*#06#)", "Show IMEI (*#06#)"), PETROL, PETROL, filled = false) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode("*#06#"))))
        } catch (e: Exception) {
            toast(tr("افتح الاتصال واكتب *#06#", "Open the dialer and type *#06#"))
        }
    }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) })
    return box
}

/** الحالة الخارجية: الهيكل والشاشة وملاحظات، تدخل في التقرير */
private fun MainActivity.conditionBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
    box.addView(text(tr("حدّد حالة الجوال من الخارج بعينك، وتظهر في التقرير.", "Rate the outside of the phone by eye. It appears in the report."), 13f, Fonts.regular, SLATE))

    fun condRow(title: String, current: Cond?, set: (Cond?) -> Unit) {
        box.addView(text(title, 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(14), 0, dp(8)) })
        val wrap = FlowRow(this)
        for (c in Cond.values()) {
            val selected = c == current
            val chipView = TextView(this)
            chipView.text = c.label
            chipView.textSize = 13f
            chipView.typeface = if (selected) Fonts.bold else Fonts.medium
            chipView.setTextColor(if (selected) Color.WHITE else TEXT)
            chipView.setPadding(dp(14), dp(8), dp(14), dp(8))
            chipView.background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                if (selected) setColor(PETROL) else setStroke(dp(1), LINE)
            }
            chipView.setOnClickListener {
                set(if (selected) null else c)
                render()
            }
            wrap.addView(chipView)
        }
        box.addView(wrap, LinearLayout.LayoutParams(-1, -2))
    }
    condRow(tr("الهيكل والإطار", "Body & frame"), Results.body) { Results.body = it }
    condRow(tr("زجاج الشاشة", "Screen glass"), Results.screen) { Results.screen = it }

    box.addView(text(tr("ملاحظات", "Notes"), 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(14), 0, dp(8)) })
    val notes = EditText(this).apply {
        setText(Results.notes)
        hint = tr("مثلاً: البطارية مغيّرة، فيه ضمان لين 2027، الكرتون موجود…", "e.g. battery replaced, warranty until 2027, box included…")
        textSize = 14f
        typeface = Fonts.regular
        setTextColor(TEXT)
        setHintTextColor(GRAY)
        minLines = 2
        gravity = Gravity.TOP or Gravity.START
        textDirection = Lang.textDir
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), LINE)
        }
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Results.notes = s?.toString().orEmpty().take(400)
            }
        })
    }
    box.addView(notes, LinearLayout.LayoutParams(-1, -2))
    return box
}

private fun MainActivity.usageBlock(): View {
    val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
    if (!UsageAnalyzer.hasAccess(this)) {
        box.addView(text(tr(
            "يقرأ سجل استخدام الجوال: من متى مستخدم، ومتوسط الشاشة يومياً، ومستوى الاستخدام، وتوزيعه (ألعاب، فيديو، تواصل…). يعرض فئات ونسب فقط بدون أسماء تطبيقات.",
            "Reads the phone's usage history: how long it has been in use, average daily screen time, usage level and breakdown (games, video, social…). Shows categories and shares only, no app names."
        ), 14f, Fonts.regular, SLATE).apply { setLineSpacing(0f, 1.25f) })
        box.addView(text(tr(
            "ملاحظة: ضبط المصنع يمسح هذا السجل، فأفضل وقت للفحص قبل مسح الجوال.",
            "Note: a factory reset erases this history, so run it before the phone is wiped."
        ), 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(8), 0, 0) })
        box.addView(pill(tr("تفعيل الوصول لبيانات الاستخدام", "Allow usage access"), PETROL, Color.WHITE, filled = true) {
            try {
                startActivity(UsageAnalyzer.settingsIntent())
                toast(tr("اختر \"فاحص الجوال\" وفعّل السماح، ثم ارجع", "Select \"Phone Check\", allow access, then come back"))
            } catch (e: Exception) {
                toast(tr("افتح الإعدادات ← التطبيقات ← الوصول الخاص ← الوصول لبيانات الاستخدام", "Open Settings → Apps → Special access → Usage access"))
            }
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
        return box
    }
    val u = Results.usage
    if (u == null) {
        box.addView(text(tr("جاري تحليل سجل الاستخدام…", "Analyzing usage history…"), 14f, Fonts.medium, SLATE))
        return box
    }
    box.addView(text(u.summary, 16f, Fonts.bold, TEXT).apply { setLineSpacing(0f, 1.25f) })
    if (!u.recentReset) {
        box.addView(statRow(tr("مستخدم منذ", "In use for"), u.inUseText))
        u.avgDailyMin?.let { box.addView(statRow(tr("متوسط الشاشة يومياً", "Daily screen time"), hm(it))) }
        box.addView(statRow(tr("مستوى الاستخدام", "Usage level"), u.intensityText))
        if (u.historyDays > 0) box.addView(statRow(tr("السجل يغطي", "History covers"), tr("${u.historyDays} يوم", "${u.historyDays} days")))
        if (u.shares.isNotEmpty()) {
            box.addView(text(tr("توزيع الاستخدام", "Usage breakdown"), 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(12), 0, dp(6)) })
            for ((cat, pct) in u.shares.take(6)) box.addView(barRow(cat.label, pct, cat.color))
        }
    }
    // إضافة للتقرير
    val inc = Results.usageInReport
    val toggle = text((if (inc) "✓  " else "") + tr("يظهر في التقرير", "Included in report"), 14f, Fonts.bold, if (inc) Color.WHITE else TEXT)
    toggle.gravity = Gravity.CENTER
    toggle.setPadding(dp(14), dp(10), dp(14), dp(10))
    toggle.background = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat()
        if (inc) setColor(PETROL) else setStroke(dp(1), LINE)
    }
    toggle.setOnClickListener {
        Results.usageInReport = !Results.usageInReport
        render()
    }
    box.addView(toggle, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
    return box
}

// ---------------- الجهاز ----------------
internal fun MainActivity.deviceTab() {
    val snap = snapshot
    pageHeader(snap?.deviceName ?: tr("الجهاز", "Device"), tr("مواصفات الجهاز وقراءاته الحالية", "Device specs and current readings"))
    val b = body()
    if (snap == null) {
        b.addView(text(tr("تعذّر قراءة معلومات الجهاز.", "Could not read device info."), 14f, Fonts.regular, SLATE).apply { setPadding(dp(4), dp(16), dp(4), 0) })
        return
    }
    b.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
    val specs = surface()
    snap.sections.forEachIndexed { i, s -> specs.addView(specSection(s, i > 0)) }
    b.addView(specs, blockParams())
}

private fun MainActivity.specSection(s: InfoSection, withDivider: Boolean): View {
    val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (withDivider) wrap.addView(divider(dp(16)))
    val open = s.title in expanded
    val head = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundResource(rippleRes())
        setOnClickListener {
            if (open) expanded.remove(s.title) else expanded.add(s.title)
            render()
        }
    }
    head.addView(text(s.title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text(if (open) tr("إخفاء", "Hide") else tr("${s.items.size} بنود", "${s.items.size} items"), 13f, Fonts.regular, SLATE))
    head.addView(text(if (open) "▴" else "▾", 14f, Fonts.regular, SLATE).apply { setPaddingRelative(dp(8), 0, 0, 0) })
    wrap.addView(head)
    if (open) {
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(10))
        }
        for (item in s.items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            row.addView(text(item.label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(item.value, 14f, Fonts.medium, TEXT).apply { gravity = Gravity.END })
            list.addView(row)
        }
        wrap.addView(list)
    }
    return wrap
}

// ---------------- المزيد ----------------
internal fun MainActivity.moreTab() {
    pageHeader(tr("المزيد", "More"), null)
    val b = body()
    b.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
    val box = surface()
    fun item(title: String, value: String, onClick: () -> Unit) {
        if (box.childCount > 0) box.addView(divider(dp(16)))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundResource(rippleRes())
            setOnClickListener { onClick() }
        }
        row.addView(text(title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 14f, Fonts.regular, SLATE))
        box.addView(row)
    }
    item(tr("اللغة", "Language"), if (Lang.en) "English" else "العربية") { switchLanguage() }
    item(tr("فحص جوال ثاني", "Inspect another phone"), "") {
        startActivity(Intent(this, RemoteActivity::class.java))
    }
    item(tr("سجل الفحوصات", "Inspection history"), History.all(this).size.toString()) {
        startActivity(Intent(this, HistoryActivity::class.java))
    }
    item(tr("التحقق من تقرير", "Verify a report"), "") { openUrl(VERIFY_URL + if (Lang.en) "?lang=en" else "") }
    item(tr("سياسة الخصوصية", "Privacy policy"), "") { openUrl(PRIVACY_URL + if (Lang.en) "?lang=en" else "") }
    item(tr("الإصدار", "Version"), versionName()) {}
    b.addView(box, blockParams())
}

private fun MainActivity.versionName(): String = try {
    packageManager.getPackageInfo(packageName, 0).versionName ?: ""
} catch (e: Exception) {
    ""
}
