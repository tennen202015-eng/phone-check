package com.phonecheck.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToInt
import kotlin.math.sin

/** نتيجة اختبار الأداء */
data class PerfReport(
    val singleScore: Int,          // نقاط النواة الواحدة
    val multiStart: Int,           // نقاط كل الأنوية أول الاختبار
    val multiEnd: Int,             // نقاط كل الأنوية آخر الاختبار
    val throttlePct: Int,          // كم نزل الأداء مع الحرارة %
    val tempStart: Float,
    val tempMax: Float,
    val thermalWorst: Int,         // أسوأ حالة حرارية من النظام (-1 غير متاح)
    val avgFps: Int,
    val refreshHz: Int,
    val jankPct: Int,              // نسبة الإطارات المتأخرة
    val freezes: Int,              // تعليقات أطول من 250ms
    val quick: Boolean = false,    // نسخة الفحص السريع (20 ثانية ضغط بدل دقيقة)
) {
    /** قواعد الحكم */
    val issues: List<String>
        get() = buildList {
            if (throttlePct > 40) add(tr("الأداء ينهار ${throttlePct}% مع الحرارة (خنق حراري قوي)", "Performance collapses ${throttlePct}% under heat (heavy throttling)"))
            if (jankPct > 10) add(tr("تقطيع في الحركة: ${jankPct}% من الإطارات متأخرة", "Stutter: ${jankPct}% of frames late"))
            if (freezes > 0) add(tr("تعليق في الشاشة $freezes مرة", "Screen froze $freezes time(s)"))
            if (tempMax > 52f) add(tr("سخونة عالية تحت الضغط (${tempMax.roundToInt()}°)", "Runs very hot under load (${tempMax.roundToInt()}°)"))
            if (thermalWorst >= 4) add(tr("النظام دخل حالة حرارة حرجة", "System reached a critical thermal state"))
        }

    val passed: Boolean get() = issues.isEmpty()

    val summary: String
        get() = tr("تقطيع $jankPct% · انخفاض $throttlePct%", "Jank $jankPct% · drop $throttlePct%") +
            if (quick) tr(" · سريع", " · quick") else ""
}

/**
 * اختبار المعالج والتهنيج:
 * 1) سرعة النواة الواحدة 3 ثواني
 * 2) ضغط على كل الأنوية 60 ثانية ونراقب انهيار الأداء مع الحرارة (أشهر سبب للتهنيج)
 * 3) نعومة الشاشة: حركة 8 ثواني ونعد الإطارات المتأخرة والتعليقات
 */
class PerfTestActivity : AppCompatActivity() {

    private enum class Phase { READY, SINGLE, MULTI, COOL, UI, DONE }

    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var phase = Phase.READY
    private var phaseStart = 0L

    private val running = AtomicBoolean(false)
    private val counter = AtomicLong(0)
    private var singleScore = 0
    private val windows = mutableListOf<Int>()
    private var lastCount = 0L
    private var tempStart = 0f
    private var tempMax = 0f
    private var thermalWorst = -1

    private val frames = mutableListOf<Long>()
    private var lastFrame = 0L
    private var refreshHz = 60
    private var anim: AnimView? = null
    private var report: PerfReport? = null

    private var MULTI_MS = 60_000L
    private var quick = false
    private val WINDOW_MS = 5_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = PETROL
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(ScrollView(this).apply {
            layoutDirection = Lang.dir
            setBackgroundColor(BG)
            addView(root)
        })
        quick = intent.getBooleanExtra("quick", false)
        if (quick) MULTI_MS = 20_000L
        @Suppress("DEPRECATION")
        refreshHz = windowManager.defaultDisplay.refreshRate.roundToInt().coerceIn(30, 165)
        render()
    }

    override fun onPause() {
        super.onPause()
        // لو طلع من التطبيق، القياس يخرب، فنرجع للبداية
        if (phase != Phase.READY && phase != Phase.DONE) {
            stopAll()
            phase = Phase.READY
            render()
        }
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun stopAll() {
        running.set(false)
        handler.removeCallbacksAndMessages(null)
        frameCb?.let { Choreographer.getInstance().removeFrameCallback(it) }
    }

    private fun temp(): Float {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private fun thermal(): Int = if (Build.VERSION.SDK_INT >= 29) {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
    } else -1

    /** حمل ثابت ومتنوع: حساب صحيح وعشري وذاكرة */
    private fun work(n: Int): Double {
        var x = 0.0
        var h = 17L
        val arr = IntArray(256)
        for (i in 1..n) {
            x += Math.sqrt(i.toDouble()) * 1.0000001
            h = h * 31 + i
            arr[i and 255] = (h xor (h ushr 7)).toInt()
        }
        return x + arr[3]
    }

    private fun start() {
        windows.clear()
        frames.clear()
        tempStart = temp()
        tempMax = tempStart
        thermalWorst = thermal()
        runSingle()
    }

    private fun runSingle() {
        phase = Phase.SINGLE
        phaseStart = SystemClock.elapsedRealtime()
        counter.set(0)
        running.set(true)
        Thread {
            val end = SystemClock.elapsedRealtime() + 3000
            while (running.get() && SystemClock.elapsedRealtime() < end) {
                work(5000)
                counter.incrementAndGet()
            }
            val c = counter.get()
            runOnUiThread {
                if (phase != Phase.SINGLE) return@runOnUiThread
                singleScore = (c / 3).toInt()
                runMulti()
            }
        }.start()
        tickUi()
    }

    private fun runMulti() {
        phase = Phase.MULTI
        phaseStart = SystemClock.elapsedRealtime()
        counter.set(0)
        lastCount = 0
        running.set(true)
        repeat(Runtime.getRuntime().availableProcessors()) {
            Thread {
                while (running.get()) {
                    work(5000)
                    counter.incrementAndGet()
                }
            }.start()
        }
        val windowTick = object : Runnable {
            override fun run() {
                if (phase != Phase.MULTI) return
                val c = counter.get()
                windows += ((c - lastCount) * 1000 / WINDOW_MS).toInt()
                lastCount = c
                val t = temp()
                if (t > tempMax) tempMax = t
                val th = thermal()
                if (th > thermalWorst) thermalWorst = th
                if (SystemClock.elapsedRealtime() - phaseStart >= MULTI_MS) {
                    running.set(false)
                    phase = Phase.COOL
                    phaseStart = SystemClock.elapsedRealtime()
                    handler.postDelayed({ runUi() }, 2000)
                }
                render()
                if (phase == Phase.MULTI) handler.postDelayed(this, WINDOW_MS)
            }
        }
        handler.postDelayed(windowTick, WINDOW_MS)
    }

    private var frameCb: Choreographer.FrameCallback? = null

    private fun runUi() {
        phase = Phase.UI
        phaseStart = SystemClock.elapsedRealtime()
        frames.clear()
        lastFrame = 0L
        render()
        val cb = object : Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                if (phase != Phase.UI) return
                if (lastFrame != 0L) frames += (t - lastFrame)
                lastFrame = t
                anim?.invalidate()
                if (SystemClock.elapsedRealtime() - phaseStart < 8000) {
                    Choreographer.getInstance().postFrameCallback(this)
                } else {
                    finish3()
                }
            }
        }
        frameCb = cb
        Choreographer.getInstance().postFrameCallback(cb)
    }

    private fun finish3() {
        phase = Phase.DONE
        val expected = 1_000_000_000.0 / refreshHz
        val janky = frames.count { it > expected * 1.5 }
        val freezes = frames.count { it > 250_000_000L }
        val avgFps = if (frames.isEmpty()) 0 else (1_000_000_000.0 / frames.average()).roundToInt()
        val first = windows.take(2).maxOrNull() ?: 0
        val lastAvg = windows.takeLast(3).let { if (it.isEmpty()) 0.0 else it.average() }
        val throttle = if (first > 0) ((1 - lastAvg / first) * 100).roundToInt().coerceIn(0, 100) else 0
        report = PerfReport(
            singleScore = singleScore,
            multiStart = first,
            multiEnd = lastAvg.roundToInt(),
            throttlePct = throttle,
            tempStart = tempStart,
            tempMax = tempMax,
            thermalWorst = thermalWorst,
            avgFps = avgFps,
            refreshHz = refreshHz,
            jankPct = if (frames.isEmpty()) 0 else janky * 100 / frames.size,
            freezes = freezes,
            quick = quick,
        )
        render()
    }

    private fun tickUi() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (phase == Phase.SINGLE || phase == Phase.MULTI) {
                    render()
                    handler.postDelayed(this, 1000)
                }
            }
        }, 1000)
    }

    private fun save() {
        val r = report ?: return
        Results.perf = r
        Results.details[Test.CPU] = r.summary
        setResult(if (r.passed) RESULT_OK else RESULT_FIRST_USER)
        finish()
    }

    // ---------- الواجهة ----------
    private fun render() {
        root.removeAllViews()
        val r0 = dp(28).toFloat()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(22))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r0, r0, r0, r0)
            }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text("✕  " + tr("إيقاف", "Stop"), 14f, Fonts.bold, Color.WHITE).apply {
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), LIGHT)
            }
            setOnClickListener { finish() }
        })
        head.addView(top)
        head.addView(text(Test.CPU.title, 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
        root.addView(head)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(36))
        }
        root.addView(body)
        val c = card(body)

        when (phase) {
            Phase.READY -> {
                c.addView(title(tr("وش بنختبر؟", "What we test")))
                val len = if (quick) tr("20 ثانية", "20 seconds") else tr("دقيقة", "one minute")
                val total = if (quick) tr("حوالي 35 ثانية", "about 35 seconds") else tr("حوالي دقيقة ونص", "about a minute and a half")
                c.addView(para(tr(
                    "1) سرعة المعالج.\n2) ضغط كامل لمدة $len: الجوال اللي يهنّج غالباً أداؤه ينهار لما يسخن.\n3) نعومة الشاشة: نعد الإطارات المتأخرة والتعليقات.\n\nياخذ $total. الجوال بيسخن شوي، هذا طبيعي. لا تطلع من التطبيق أثناء الاختبار.",
                    "1) Processor speed.\n2) Full load for $len: phones that lag usually collapse when hot.\n3) Screen smoothness: we count late frames and freezes.\n\nTakes $total. The phone will warm up; that's normal. Don't leave the app during the test."
                )))
                c.addView(pill(tr("ابدأ", "Start"), PETROL, Color.WHITE) { start() },
                    LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
            }
            Phase.SINGLE -> {
                c.addView(title(tr("سرعة النواة الواحدة…", "Single-core speed…")))
                c.addView(para(progress(3000)))
            }
            Phase.MULTI -> {
                c.addView(title(tr("ضغط على كل الأنوية…", "Full load on all cores…")))
                c.addView(para(progress(MULTI_MS)))
                c.addView(stat(tr("الحرارة", "Temperature"), String.format(Locale.US, "%.1f°C", tempMax)))
                if (windows.isNotEmpty()) {
                    c.addView(stat(tr("الأداء أول الاختبار", "Score at start"), "${windows.take(2).maxOrNull()}"))
                    c.addView(stat(tr("الأداء الحين", "Score now"), "${windows.last()}"))
                    c.addView(Bars(this, windows.toList()), LinearLayout.LayoutParams(-1, dp(90)).apply { topMargin = dp(10) })
                }
            }
            Phase.COOL -> c.addView(title(tr("لحظة…", "One moment…")))
            Phase.UI -> {
                c.addView(title(tr("نعومة الشاشة… راقب الحركة", "Screen smoothness… watch the motion")))
                val a = AnimView(this)
                anim = a
                c.addView(a, LinearLayout.LayoutParams(-1, dp(160)).apply { topMargin = dp(12) })
            }
            Phase.DONE -> {
                val r = report ?: return
                c.addView(text(
                    if (r.passed) tr("الأداء سليم ✓", "Performance OK ✓") else tr("فيه مشكلة في الأداء ✗", "Performance issue ✗"),
                    22f, Fonts.bold, if (r.passed) GREEN else RED
                ))
                for (i in r.issues) c.addView(para("•  $i").apply { setTextColor(RED) })
                c.addView(stat(tr("سرعة النواة الواحدة", "Single-core score"), "${r.singleScore}"))
                c.addView(stat(tr("كل الأنوية: البداية ← النهاية", "All cores: start → end"), "${r.multiStart} → ${r.multiEnd}"))
                c.addView(stat(tr("انخفاض الأداء مع الحرارة", "Drop under heat"), "${r.throttlePct}%"))
                c.addView(stat(tr("الحرارة: البداية ← الأعلى", "Temp: start → max"), String.format(Locale.US, "%.0f° → %.0f°", r.tempStart, r.tempMax)))
                c.addView(stat(tr("الإطارات في الثانية", "Frames per second"), "${r.avgFps} / ${r.refreshHz}"))
                c.addView(stat(tr("الإطارات المتأخرة", "Late frames"), "${r.jankPct}%"))
                c.addView(stat(tr("تعليقات الشاشة", "Screen freezes"), "${r.freezes}"))
                c.addView(para(tr(
                    "الحكم: انخفاض أكثر من 40%، أو تأخر أكثر من 10% من الإطارات، أو أي تعليق، أو حرارة فوق 52° = مشكلة.",
                    "Rules: a drop above 40%, over 10% late frames, any freeze, or over 52°C counts as an issue."
                )))
                c.addView(pill(tr("حفظ النتيجة", "Save result"), PETROL, Color.WHITE) { save() },
                    LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
                c.addView(pill(tr("إعادة الاختبار", "Retest"), PETROL, PETROL, filled = false) {
                    phase = Phase.READY
                    render()
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
            }
        }
    }

    private fun progress(total: Long): String {
        val el = SystemClock.elapsedRealtime() - phaseStart
        val pct = (el * 100 / total).coerceIn(0, 100)
        return tr("التقدم: $pct%", "Progress: $pct%")
    }

    /** دائرة تتحرك عشان نقيس نعومة الرسم */
    private class AnimView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PETROL }
        private val start = SystemClock.uptimeMillis()
        override fun onDraw(canvas: Canvas) {
            val t = (SystemClock.uptimeMillis() - start) / 1000.0
            val r = height / 5f
            val x = (width / 2f) + (width / 2f - r) * sin(t * 2.2).toFloat()
            val y = height / 2f + (height / 4f) * sin(t * 3.7).toFloat()
            canvas.drawCircle(x, y, r, p)
        }
    }

    /** أعمدة بسيطة للأداء خلال الدقيقة */
    private class Bars(ctx: Context, private val values: List<Int>) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PETROL }
        override fun onDraw(canvas: Canvas) {
            if (values.isEmpty()) return
            val max = (values.maxOrNull() ?: 1).coerceAtLeast(1)
            val n = 12
            val gap = 4f
            val w = (width - gap * (n - 1)) / n
            values.take(n).forEachIndexed { i, v ->
                val h = height * v / max.toFloat()
                val x = if (layoutDirection == View.LAYOUT_DIRECTION_RTL) width - (i + 1) * w - i * gap else i * (w + gap)
                canvas.drawRoundRect(x, height - h, x + w, height.toFloat(), 4f, 4f, p)
            }
        }
    }

    // ---------- عناصر ----------
    private fun card(body: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
        }
        body.addView(c, LinearLayout.LayoutParams(-1, -2))
        return c
    }

    private fun title(s: String) = text(s, 18f, Fonts.bold, TEXT)

    private fun para(s: String) = text(s, 14f, Fonts.regular, SLATE).apply {
        setLineSpacing(0f, 1.3f)
        setPadding(0, dp(6), 0, 0)
    }

    private fun stat(label: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, dp(7))
        }
        row.addView(text(label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 14f, Fonts.bold, TEXT).apply { gravity = Gravity.END })
        return row
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun pill(label: String, bg: Int, fg: Int, filled: Boolean = true, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            textSize = 15f
            typeface = Fonts.bold
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                if (filled) setColor(bg) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), bg)
                }
            }
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
