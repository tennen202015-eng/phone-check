package com.phonecheck.app

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** ملف التراخيص: تعدّله من لوحة الإدارة (admin.html) أو من GitHub */
const val LICENSE_URL = "https://tennen202015-eng.github.io/phone-check-web/licenses.json"

/** رابط تحميل آخر نسخة من التطبيق (لجوال الزبون) */
const val APK_URL = "https://github.com/tennen202015-eng/phone-check/releases/latest/download/PhoneCheck.apk"

/** بداية رمز التفعيل اللي يعرضه جوال المحل */
const val KEY_QR_PREFIX = "PCKEY1:"

/**
 * الترخيص بطريقتين:
 * 1) جوال المحل نفسه: بكود الجهاز (code) في licenses.json، ويشتغل لين نهاية الاشتراك.
 * 2) جوال الزبون اللي ينفحص: بمفتاح المحل (key)، يمسحه من جوال المحل ويشتغل 24 ساعة بس.
 *
 * التاريخ يتأخذ من خادم GitHub مو من الجوال. وبدون إنترنت يشتغل 3 أيام من آخر تحقق (جوال المحل فقط).
 */
object License {
    private const val PREFS = "license"
    private const val GRACE_MS = 3L * 24 * 3600 * 1000
    const val TEMP_MS = 24L * 3600 * 1000

    enum class State { CHECKING, VALID, EXPIRED, NOT_FOUND, NEED_INTERNET, TEMP_ENDED, BAD_KEY }
    enum class Mode { NONE, DEVICE, KEY }

    @Volatile var state: State = State.CHECKING
        private set
    var mode: Mode = Mode.NONE
        private set
    var holder: String = ""        // اسم المحل
        private set
    var untilMs: Long = 0L         // نهاية الاشتراك (أو نهاية التفعيل المؤقت)
        private set
    var shopKey: String = ""       // مفتاح المحل (يظهر في جوال المحل لتفعيل جوالات الزبائن)
        private set
    private var checking = false

    /** كود الجهاز: 8 حروف، مثل 4F2A-9C1B */
    @SuppressLint("HardwareIds")
    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = MessageDigest.getInstance("SHA-256").digest(("phonecheck-license:" + id).toByteArray())
        val hex = h.take(4).joinToString("") { String.format("%02X", it) }
        return hex.substring(0, 4) + "-" + hex.substring(4, 8)
    }

    /** المفتاح بدون شرطات ومسافات وبحروف كبيرة */
    fun normKey(s: String): String = s.uppercase(Locale.US).filter { it.isLetterOrDigit() }

    fun prettyKey(s: String): String = normKey(s).let { if (it.length == 8) it.substring(0, 4) + "-" + it.substring(4) else it }

    val daysLeft: Int
        get() = if (untilMs <= 0) 0 else ((untilMs - System.currentTimeMillis()) / 86_400_000L).toInt().coerceAtLeast(0) + 1

    val hoursLeft: Int
        get() = if (untilMs <= 0) 0 else ((untilMs - System.currentTimeMillis()) / 3_600_000L).toInt().coerceAtLeast(0) + 1

    val unlocked: Boolean get() = state == State.VALID

    /** يقرأ آخر حالة محفوظة (فوري بدون انتظار) */
    fun loadCached(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        holder = p.getString("holder", "") ?: ""
        untilMs = p.getLong("until", 0L)
        shopKey = p.getString("shopKey", "") ?: ""
        mode = try { Mode.valueOf(p.getString("mode", "NONE") ?: "NONE") } catch (e: Exception) { Mode.NONE }
        val lastOk = p.getLong("lastOk", 0L)
        val lastSeen = p.getLong("lastSeen", 0L)
        val now = System.currentTimeMillis()
        state = when {
            untilMs == 0L -> State.CHECKING
            now < lastSeen - 60_000 -> State.NEED_INTERNET          // تاريخ الجوال رجع لورا
            now > untilMs -> if (mode == Mode.KEY) State.TEMP_ENDED else State.EXPIRED
            // جوال الزبون ما له مهلة بدون إنترنت أطول من التفعيل نفسه، وجوال المحل له 3 أيام
            now - lastOk > GRACE_MS -> State.NEED_INTERNET
            else -> State.VALID
        }
        if (now > lastSeen) p.edit().putLong("lastSeen", now).apply()
    }

    /** تفعيل جوال زبون بمفتاح المحل (من رمز QR أو كتابة) */
    fun activateKey(ctx: Context, key: String, done: () -> Unit) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("key", normKey(key)).putLong("keyAt", 0L).apply()
        refresh(ctx, done)
    }

    /** يتحقق من الملف على الإنترنت، ويرجع على الشاشة الرئيسية */
    fun refresh(ctx: Context, done: () -> Unit) {
        if (checking) return
        checking = true
        val app = ctx.applicationContext
        val code = deviceCode(app)
        Thread {
            try {
                val conn = URL("$LICENSE_URL?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                conn.useCaches = false
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                // وقت الخادم أصدق من ساعة الجوال
                val serverNow = conn.date.takeIf { it > 0 } ?: System.currentTimeMillis()
                conn.disconnect()
                val arr = JSONObject(body).getJSONArray("licenses")
                val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val myKey = p.getString("key", "") ?: ""
                var byCode: JSONObject? = null
                var byKey: JSONObject? = null
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("code").trim().equals(code, ignoreCase = true)) byCode = o
                    if (myKey.isNotBlank() && normKey(o.optString("key")) == myKey) byKey = o
                }
                val now = System.currentTimeMillis()
                val e = p.edit().putLong("lastOk", now).putLong("lastSeen", now)
                when {
                    byCode != null -> {
                        // جوال المحل
                        val until = parseUntil(byCode.optString("until", ""))
                        holder = byCode.optString("name", "")
                        shopKey = normKey(byCode.optString("key", ""))
                        untilMs = until
                        mode = Mode.DEVICE
                        state = if (serverNow > until) State.EXPIRED else State.VALID
                    }
                    byKey != null -> {
                        // جوال زبون: 24 ساعة من أول تفعيل (بوقت الخادم)، وما يتعدى نهاية اشتراك المحل
                        var keyAt = p.getLong("keyAt", 0L)
                        if (keyAt == 0L) {
                            keyAt = serverNow
                            e.putLong("keyAt", keyAt)
                        }
                        val shopUntil = parseUntil(byKey.optString("until", ""))
                        val end = minOf(keyAt + TEMP_MS, shopUntil)
                        holder = byKey.optString("name", "")
                        shopKey = ""
                        // نحوّل النهاية لساعة الجوال عشان العدّاد يشتغل بدون إنترنت
                        untilMs = end - serverNow + now
                        mode = Mode.KEY
                        state = when {
                            serverNow > shopUntil -> State.EXPIRED
                            serverNow > end -> State.TEMP_ENDED
                            else -> State.VALID
                        }
                    }
                    myKey.isNotBlank() -> {
                        // المفتاح مكتوب غلط أو المسؤول غيّره
                        e.remove("key").remove("keyAt")
                        holder = ""; shopKey = ""; untilMs = 0L; mode = Mode.NONE
                        state = State.BAD_KEY
                    }
                    else -> {
                        holder = ""; shopKey = ""; untilMs = 0L; mode = Mode.NONE
                        state = State.NOT_FOUND
                    }
                }
                e.putLong("until", untilMs).putString("holder", holder)
                    .putString("shopKey", shopKey).putString("mode", mode.name).apply()
            } catch (e: Exception) {
                // ما فيه إنترنت أو الملف فيه خطأ: نعتمد على آخر حالة محفوظة
                loadCached(app)
                if (state == State.CHECKING) state = State.NEED_INTERNET
            }
            checking = false
            android.os.Handler(android.os.Looper.getMainLooper()).post { done() }
        }.start()
    }

    /** نهاية اليوم المكتوب بتوقيت السعودية، أو "forever" */
    private fun parseUntil(s: String): Long {
        if (s == "forever") return Long.MAX_VALUE / 4
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Riyadh") }
            (fmt.parse(s)?.time ?: 0L) + 86_400_000L - 1
        } catch (e: Exception) {
            0L
        }
    }
}
