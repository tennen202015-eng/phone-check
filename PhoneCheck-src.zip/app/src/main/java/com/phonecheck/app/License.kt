package com.phonecheck.app

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** ملف التراخيص: تعدّله أنت من GitHub (مستودع phone-check-web) */
const val LICENSE_URL = "https://tennen202015-eng.github.io/phone-check-web/licenses.json"

/**
 * الترخيص: التطبيق يشتغل بس على الأجهزة المكتوبة في licenses.json ولين التاريخ المكتوب.
 * - كل جوال له "كود جهاز" ثابت (ما يتغير لو انحذف التطبيق وانثبت من جديد).
 * - التاريخ نأخذه من خادم GitHub مو من الجوال، عشان ما ينفع أحد يرجّع تاريخ جواله.
 * - بدون إنترنت: يشتغل 3 أيام من آخر تحقق ناجح، بعدها يطلب إنترنت.
 */
object License {
    private const val PREFS = "license"
    private const val GRACE_MS = 3L * 24 * 3600 * 1000

    enum class State { CHECKING, VALID, EXPIRED, NOT_FOUND, NEED_INTERNET }

    @Volatile var state: State = State.CHECKING
        private set
    var holder: String = ""        // اسم المحل
        private set
    var untilMs: Long = 0L         // نهاية الاشتراك
        private set
    private var checking = false

    /** كود الجهاز: 8 حروف، مثل 4F2A-9C1B */
    @SuppressLint("HardwareIds")
    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = MessageDigest.getInstance("SHA-256").digest(("phonecheck-license:" + id).toByteArray())
        val hex = h.take(4).joinToString("") { String.format("%02X", it) }
        return hex.substring(0, 4) + "-" + hex.substring(4, 8)
    }

    val daysLeft: Int
        get() = if (untilMs <= 0) 0 else ((untilMs - System.currentTimeMillis()) / 86_400_000L).toInt().coerceAtLeast(0) + 1

    /** يقرأ آخر حالة محفوظة (يشتغل فوراً بدون انتظار) */
    fun loadCached(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        holder = p.getString("holder", "") ?: ""
        untilMs = p.getLong("until", 0L)
        val lastOk = p.getLong("lastOk", 0L)
        val lastSeen = p.getLong("lastSeen", 0L)
        val now = System.currentTimeMillis()
        state = when {
            untilMs == 0L -> State.CHECKING
            now < lastSeen - 60_000 -> State.NEED_INTERNET          // تاريخ الجوال رجع لورا: نطلب تحقق
            now - lastOk > GRACE_MS -> State.NEED_INTERNET
            now > untilMs -> State.EXPIRED
            else -> State.VALID
        }
        if (now > lastSeen) p.edit().putLong("lastSeen", now).apply()
    }

    /** يتحقق من الملف على الإنترنت، ويرجع النتيجة على الشاشة الرئيسية */
    fun refresh(ctx: Context, done: () -> Unit) {
        if (checking) return
        checking = true
        val app = ctx.applicationContext
        val code = deviceCode(app)
        Thread {
            try {
                val conn = URL("$LICENSE_URL?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                conn.useCaches = false
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                // وقت الخادم أصدق من ساعة الجوال
                val serverNow = conn.date.takeIf { it > 0 } ?: System.currentTimeMillis()
                conn.disconnect()
                val arr = JSONObject(body).getJSONArray("licenses")
                var found: JSONObject? = null
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("code").trim().equals(code, ignoreCase = true)) found = o
                }
                val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                if (found == null) {
                    p.putLong("until", 0L).putString("holder", "").apply()
                    holder = ""
                    untilMs = 0L
                    state = State.NOT_FOUND
                } else {
                    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Riyadh") }
                    val untilStr = found.optString("until", "")
                    // نهاية اليوم المكتوب
                    val until = if (untilStr == "forever") Long.MAX_VALUE / 2
                    else (fmt.parse(untilStr)?.time ?: 0L) + 86_400_000L - 1
                    holder = found.optString("name", "")
                    untilMs = until
                    val now = System.currentTimeMillis()
                    p.putLong("until", until).putString("holder", holder)
                        .putLong("lastOk", now).putLong("lastSeen", now).apply()
                    state = if (serverNow > until) State.EXPIRED else State.VALID
                }
            } catch (e: Exception) {
                // ما فيه إنترنت أو الملف فيه خطأ: نعتمد على آخر حالة محفوظة (مهلة 3 أيام)
                loadCached(app)
                if (state == State.CHECKING) state = State.NEED_INTERNET
            }
            checking = false
            android.os.Handler(android.os.Looper.getMainLooper()).post { done() }
        }.start()
    }

    val unlocked: Boolean get() = state == State.VALID
}
