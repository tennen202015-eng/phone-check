package com.phonecheck.app

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// عناصر الواجهة المشتركة في الشاشة الرئيسية

internal fun MainActivity.text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
    text = s
    textSize = size
    typeface = face
    setTextColor(color)
}

internal fun MainActivity.pill(label: String, bg: Int, fg: Int, filled: Boolean, onClick: () -> Unit): Button =
    Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(fg)
        textSize = 15f
        typeface = Fonts.bold
        background = GradientDrawable().apply {
            cornerRadius = dp(26).toFloat()
            if (filled) setColor(bg) else {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), bg)
            }
        }
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

/** بطاقة بيضاء بزوايا دائرية */
internal fun MainActivity.surface(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = GradientDrawable().apply {
        setColor(Color.WHITE)
        cornerRadius = dp(20).toFloat()
    }
    clipToOutline = true
}

internal fun MainActivity.blockParams() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }

internal fun MainActivity.divider(insetStart: Int): View = View(this).apply {
    setBackgroundColor(LINE)
    layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { marginStart = insetStart }
}

internal fun MainActivity.rippleRes(): Int {
    val tv = TypedValue()
    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
    return tv.resourceId
}

/** زر صغير شفاف فوق الخلفية البترولية */
internal fun MainActivity.chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    textSize = 13f
    typeface = Fonts.medium
    setTextColor(Color.WHITE)
    setPadding(dp(14), dp(7), dp(14), dp(7))
    background = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), LIGHT)
    }
    setOnClickListener { onClick() }
}

internal fun MainActivity.sectionHeading(title: String, trailing: String?): View {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.BOTTOM
        setPadding(dp(4), dp(26), dp(4), dp(10))
    }
    row.addView(text(title, 18f, Fonts.bold, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
    if (trailing != null) row.addView(text(trailing, 13f, Fonts.medium, SLATE))
    return row
}

internal fun MainActivity.statRow(label: String, value: String): View {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(7), 0, dp(7))
    }
    row.addView(text(label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
    row.addView(text(value, 14f, Fonts.bold, TEXT).apply { gravity = Gravity.END })
    return row
}

internal fun MainActivity.barRow(label: String, pct: Int, color: Int): View {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(5), 0, dp(5))
    }
    row.addView(text(label, 13f, Fonts.regular, SLATE), LinearLayout.LayoutParams(dp(112), -2))
    val track = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        background = GradientDrawable().apply {
            setColor(0xFFE9EEED.toInt())
            cornerRadius = dp(4).toFloat()
        }
        clipToOutline = true
    }
    val p = pct.coerceIn(0, 100)
    track.addView(View(this).apply {
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(4).toFloat()
        }
    }, LinearLayout.LayoutParams(0, -1, p.toFloat().coerceAtLeast(0.5f)))
    track.addView(View(this), LinearLayout.LayoutParams(0, -1, (100 - p).toFloat().coerceAtLeast(0.01f)))
    row.addView(track, LinearLayout.LayoutParams(0, dp(8), 1f))
    row.addView(text("$p%", 13f, Fonts.bold, TEXT).apply {
        gravity = Gravity.END
    }, LinearLayout.LayoutParams(dp(44), -2))
    return row
}

/** علامة الحالة: ✓ أو ✕ أو دائرة فاضية */
internal fun MainActivity.statusMark(r: Boolean?): View = TextView(this).apply {
    gravity = Gravity.CENTER
    textSize = 14f
    typeface = Fonts.bold
    includeFontPadding = false
    background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        when (r) {
            true -> setColor(PASS_BG)
            false -> setColor(FAIL_BG)
            null -> {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), LINE)
            }
        }
    }
    when (r) {
        true -> {
            text = "✓"
            setTextColor(GREEN)
        }
        false -> {
            text = "✕"
            setTextColor(RED)
        }
        null -> text = ""
    }
}

internal fun hm(min: Int): String =
    if (min >= 60) tr("${min / 60} ساعة ${min % 60} د", "${min / 60}h ${min % 60}m") else tr("$min دقيقة", "$min min")
