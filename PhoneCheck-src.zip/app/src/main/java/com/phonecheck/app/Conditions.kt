package com.phonecheck.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import kotlin.math.roundToInt

/**
 * ظروف الفحص: حالة الجوال وقت الاختبار.
 * نتائج المعالج والبطارية تتأثر بالحرارة ووضع توفير الطاقة والرام والتخزين،
 * فنتحقق منها قبل الاختبارات التقيلة ونكتبها في التقرير.
 */
data class TestConditions(
    val tempC: Float,
    val powerSave: Boolean,
    val charging: Boolean,
    val freeStoragePct: Int,
    val freeStorageGb: Double,
    val availRamPct: Int,
    val availRamMb: Int,
    val thermal: Int,          // حالة الحرارة من النظام (-1 غير متاح)
    val ts: Long = System.currentTimeMillis(),
) {
    /** أشياء لازم تتصلح قبل اختبار المعالج (تخرب النتيجة) */
    val blockers: List<String>
        get() = buildList {
            if (powerSave) add(tr("وضع توفير الطاقة شغّال: يبطّئ المعالج عمداً", "Battery saver is on: it slows the processor on purpose"))
            if (tempC > 40f) add(tr("الجوال سخن (${tempC.roundToInt()}°): استنى لين يبرد تحت 40°", "Phone is hot (${tempC.roundToInt()}°): wait until it cools below 40°"))
            if (thermal >= 3) add(tr("النظام في وضع حرارة عالية", "System is in a high thermal state"))
        }

    /** أشياء تأثر لكن ما تمنع */
    val warnings: List<String>
        get() = buildList {
            if (availRamPct in 0..14) add(tr("الرام المتاحة قليلة ($availRamPct%): سكّر التطبيقات المفتوحة", "Low available RAM ($availRamPct%): close open apps"))
            if (freeStoragePct in 0..9) add(tr("التخزين شبه مليان (فاضي $freeStoragePct%): يسبب تهنيج", "Storage almost full ($freeStoragePct% free): causes lag"))
            if (charging) add(tr("الجوال على الشاحن: يسخّن أسرع أثناء اختبار المعالج", "Phone is charging: it heats up faster during the processor test"))
        }

    val ideal: Boolean get() = blockers.isEmpty() && warnings.isEmpty()
}

object ConditionsProbe {

    fun read(ctx: Context): TestConditions {
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = (bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else -1

        var freePct = -1
        var freeGb = 0.0
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            if (st.totalBytes > 0) {
                freePct = (st.availableBytes * 100 / st.totalBytes).toInt()
                freeGb = st.availableBytes / 1_073_741_824.0
            }
        } catch (e: Exception) {
            // تجاهل
        }

        var ramPct = -1
        var ramMb = 0
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            if (mi.totalMem > 0) {
                ramPct = (mi.availMem * 100 / mi.totalMem).toInt()
                ramMb = (mi.availMem / 1_048_576).toInt()
            }
        } catch (e: Exception) {
            // تجاهل
        }

        return TestConditions(
            tempC = temp,
            powerSave = pm.isPowerSaveMode,
            charging = plugged || status == BatteryManager.BATTERY_STATUS_CHARGING,
            freeStoragePct = freePct,
            freeStorageGb = freeGb,
            availRamPct = ramPct,
            availRamMb = ramMb,
            thermal = thermal,
        )
    }

    /** يفتح إعدادات توفير الطاقة */
    fun batterySaverIntent(): Intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
}
