package com.phonecheck.app

import android.content.Context
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * نافذة موحّدة لكل التطبيق: زوايا 28dp، خط IBM Plex Sans Arabic،
 * زر رئيسي ممتلئ، واتجاه النص حسب لغة التطبيق.
 */
class PcDialog(ctx: Context) : MaterialAlertDialogBuilder(ctx, R.style.PcDialog) {

    override fun create(): AlertDialog {
        val dialog = super.create()
        dialog.window?.decorView?.layoutDirection = Lang.dir
        dialog.setOnShowListener { style(dialog) }
        return dialog
    }

    private fun style(d: AlertDialog) {
        val ctx = d.context
        Fonts.init(ctx)
        d.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.apply {
            typeface = Fonts.bold
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(TEXT)
            textDirection = Lang.textDir
        }
        d.findViewById<TextView>(android.R.id.message)?.apply {
            typeface = Fonts.regular
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(SLATE)
            setLineSpacing(0f, 1.35f)
            textDirection = Lang.textDir
        }
        listOf(AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL).forEach { which ->
            d.getButton(which)?.let { b: Button ->
                b.typeface = Fonts.bold
                b.isAllCaps = false
                b.letterSpacing = 0f
                b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            }
        }
    }
}
