package com.phonecheck.app

import android.content.Context
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * التحكم في إيقاف الفحص: الشاشة الرئيسية تسجّل دالة الإيقاف وقت ما يكون فيه فحص شغّال،
 * وكل نافذة اختبار تعرض زر ✕ وزر الرجوع يسأل "إيقاف الفحص؟".
 */
object RunControl {
    var onStop: (() -> Unit)? = null
    var current: AlertDialog? = null

    fun confirmStop(ctx: Context) {
        val target = current
        PcDialog(ctx, track = false)
            .setTitle(tr("إيقاف الفحص؟", "Stop inspection?"))
            .setMessage(tr(
                "بيوقف الفحص الحالي وترجع للشاشة الرئيسية. نتائج الاختبارات اللي خلصت تبقى محفوظة.",
                "The current inspection stops and you return to the home screen. Results of finished tests are kept."
            ))
            .setPositiveButton(tr("إيقاف", "Stop")) { _, _ ->
                target?.dismiss()
                onStop?.invoke()
            }
            .setNegativeButton(tr("متابعة", "Continue"), null)
            .show()
    }
}

/**
 * نافذة موحّدة لكل التطبيق: زوايا 28dp، خط IBM Plex Sans Arabic،
 * زر رئيسي ممتلئ، واتجاه النص حسب لغة التطبيق، وزر ✕ لإيقاف الفحص.
 */
class PcDialog(ctx: Context, private val track: Boolean = true) : MaterialAlertDialogBuilder(ctx, R.style.PcDialog) {

    override fun create(): AlertDialog {
        val dialog = super.create()
        dialog.window?.decorView?.layoutDirection = Lang.dir
        dialog.setOnShowListener {
            style(dialog)
            if (track) {
                RunControl.current = dialog
                if (RunControl.onStop != null) addClose(dialog)
            }
        }
        if (track) {
            dialog.setOnDismissListener { if (RunControl.current === dialog) RunControl.current = null }
            // زر الرجوع = إيقاف الفحص
            dialog.setOnKeyListener { _, code, ev ->
                if (code == KeyEvent.KEYCODE_BACK && RunControl.onStop != null) {
                    if (ev.action == KeyEvent.ACTION_UP) RunControl.confirmStop(dialog.context)
                    true
                } else {
                    false
                }
            }
        }
        return dialog
    }

    /** زر ✕ بجانب عنوان النافذة */
    private fun addClose(d: AlertDialog) {
        val title = d.findViewById<TextView>(androidx.appcompat.R.id.alertTitle) ?: return
        val parent = title.parent as? LinearLayout ?: return
        if (parent.findViewWithTag<View>("pc_close") != null) return
        (title.layoutParams as? LinearLayout.LayoutParams)?.let {
            it.width = 0
            it.weight = 1f
            title.layoutParams = it
        }
        val density = d.context.resources.displayMetrics.density
        val close = TextView(d.context).apply {
            tag = "pc_close"
            text = "✕"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(SLATE)
            contentDescription = tr("إيقاف الفحص", "Stop inspection")
            val pad = (10 * density).toInt()
            setPadding(pad, 0, pad, 0)
            setOnClickListener { RunControl.confirmStop(d.context) }
        }
        parent.gravity = Gravity.CENTER_VERTICAL
        parent.addView(close, LinearLayout.LayoutParams((44 * density).toInt(), (44 * density).toInt()))
    }

    private fun style(d: AlertDialog) {
        val ctx = d.context
        Fonts.init(ctx)
        d.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.apply {
            typeface = Fonts.bold
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(TEXT)
            textDirection = Lang.textDir
        }
        d.findViewById<TextView>(android.R.id.message)?.apply {
            typeface = Fonts.regular
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(SLATE)
            setLineSpacing(0f, 1.35f)
            textDirection = Lang.textDir
        }
        listOf(AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL).forEach { which ->
            d.getButton(which)?.let { b: Button ->
                b.typeface = Fonts.bold
                b.isAllCaps = false
                b.letterSpacing = 0f
                b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            }
        }
    }
}
