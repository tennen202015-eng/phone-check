package com.phonecheck.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** فتح أو مشاركة ملف PDF */
fun Activity.openPdf(file: File, share: Boolean) {
    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    val intent = if (share) {
        Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("report", uri)
        }
    } else {
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
    }
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        startActivity(
            if (share) Intent.createChooser(intent, tr("مشاركة التقرير", "Share report")).apply {
                // ما نبي التطبيق نفسه يظهر كخيار مشاركة على نفس الجوال
                putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(android.content.ComponentName(this@openPdf, ImportActivity::class.java)))
            } else intent
        )
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(
            this,
            tr("ما فيه تطبيق يفتح PDF، استخدم زر المشاركة", "No app can open PDFs. Use Share instead."),
            Toast.LENGTH_LONG
        ).show()
    }
}

/** فتح رابط في المتصفح */
fun Activity.openUrl(url: String) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, url, Toast.LENGTH_LONG).show()
    }
}
