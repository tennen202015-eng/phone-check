package com.phonecheck.app

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** سجل الفحوصات السابقة: تفتح أي تقرير أو تشاركه أو تحذفه */
class HistoryActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setEdgeContent(ScrollView(this).apply {
            layoutDirection = Lang.dir
            setBackgroundColor(BG)
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        root.removeAllViews()
        val entries = History.all(this)

        // الترويسة
        val r = dp(28).toFloat()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(22))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        head.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT))
        head.addView(text(tr("سجل الفحوصات", "Inspection history"), 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
        head.addView(text(tr("${entries.size} تقرير محفوظ في هذا الجوال", "${entries.size} reports saved on this phone"), 14f, Fonts.regular, LIGHT).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(head)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(36))
        }
        root.addView(body)

        if (entries.isEmpty()) {
            val empty = surface().apply { setPadding(dp(20), dp(24), dp(20), dp(24)) }
            empty.addView(text(tr("ما فيه تقارير للحين", "No reports yet"), 16f, Fonts.bold, TEXT))
            empty.addView(text(
                tr("افحص جوال واضغط \"عرض التقرير\"، وبيظهر هنا تلقائياً.", "Inspect a phone and tap \"View report\". It will show up here automatically."),
                14f, Fonts.regular, SLATE
            ).apply { setPadding(0, dp(6), 0, 0) })
            body.addView(empty, LinearLayout.LayoutParams(-1, -2))
            return
        }

        val list = surface()
        val fmt = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US)
        entries.forEachIndexed { i, e ->
            if (i > 0) list.addView(View(this).apply {
                setBackgroundColor(LINE)
                layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { marginStart = dp(72) }
            })
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                setBackgroundResource(ripple())
                setOnClickListener { openPdf(File(e.path), false) }
                setOnLongClickListener {
                    actions(e)
                    true
                }
            }
            // دائرة التقييم
            row.addView(TextView(this).apply {
                text = e.score.toString()
                textSize = 16f
                typeface = Fonts.bold
                gravity = Gravity.CENTER
                includeFontPadding = false
                setTextColor(Scoring.gradeColor(e.score))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(2), Scoring.gradeColor(e.score))
                }
            }, LinearLayout.LayoutParams(dp(44), dp(44)))

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            top.addView(text(e.device, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
            // علامة نوع الفحص
            val badge = when (e.mode) {
                "q" -> tr("سريع", "Quick") to 0xFFA86B0C.toInt()
                "f" -> tr("كامل", "Full") to GREEN
                else -> null
            }
            badge?.let { (label, color) ->
                top.addView(text(label, 11.5f, Fonts.bold, color).apply {
                    setPadding(dp(9), dp(2), dp(9), dp(3))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setStroke(dp(1), color)
                    }
                }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            }
            col.addView(top, LinearLayout.LayoutParams(-1, -2))
            val meta = fmt.format(Date(e.ts)) + "  ·  " + e.id +
                if (e.remote) "  ·  " + tr("عن بُعد", "Remote") else ""
            col.addView(text(meta, 12f, Fonts.regular, SLATE).apply { textDirection = View.TEXT_DIRECTION_LOCALE })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })

            row.addView(text(tr("مشاركة", "Share"), 14f, Fonts.bold, PETROL).apply {
                setPadding(dp(10), dp(8), 0, dp(8))
                setOnClickListener { openPdf(File(e.path), true) }
            })
            list.addView(row)
        }
        body.addView(list, LinearLayout.LayoutParams(-1, -2))

        body.addView(text(tr("اضغط مطولاً على أي تقرير لحذفه.", "Long-press a report to delete it."), 13f, Fonts.regular, SLATE).apply {
            setPadding(dp(4), dp(12), dp(4), 0)
        })
        body.addView(text(tr("حذف كل السجل", "Delete all history"), 14f, Fonts.bold, RED).apply {
            setPadding(dp(4), dp(16), dp(4), dp(8))
            setOnClickListener {
                PcDialog(this@HistoryActivity)
                    .setTitle(tr("حذف كل السجل؟", "Delete all history?"))
                    .setMessage(tr("بتنحذف كل التقارير المحفوظة من هذا الجوال، وما يمكن استرجاعها.", "All saved reports will be deleted from this phone. This cannot be undone."))
                    .setPositiveButton(tr("حذف الكل", "Delete all")) { _, _ ->
                        History.clear(this@HistoryActivity)
                        render()
                    }
                    .setNegativeButton(tr("إلغاء", "Cancel"), null)
                    .show()
            }
        })
    }

    private fun actions(e: HistoryEntry) {
        PcDialog(this)
            .setTitle(e.device)
            .setMessage(e.id)
            .setPositiveButton(tr("فتح", "Open")) { _, _ -> openPdf(File(e.path), false) }
            .setNeutralButton(tr("حذف", "Delete")) { _, _ ->
                History.delete(this, e.id)
                render()
            }
            .setNegativeButton(tr("إلغاء", "Cancel"), null)
            .show()
    }

    private fun surface(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(20).toFloat()
        }
        clipToOutline = true
    }

    private fun ripple(): Int {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
