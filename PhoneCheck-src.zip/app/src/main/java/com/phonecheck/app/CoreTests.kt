package com.phonecheck.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs

// الاختبارات الأساسية: الصوت والاهتزاز والفلاش والكاميرا والمايك والأزرار

/** سؤال نعم/لا بعد تشغيل شي (نغمة، اهتزاز، فلاش). after = التنظيف */
internal fun MainActivity.ask(t: Test, q: String, after: () -> Unit = {}) {
    cleanup = after
    PcDialog(this)
        .setTitle(t.title)
        .setMessage(q)
        .setCancelable(false)
        .setPositiveButton(tr("نعم", "Yes")) { _, _ -> after(); record(t, true) }
        .setNegativeButton(tr("لا", "No")) { _, _ -> after(); record(t, false) }
        .show()
}

internal fun MainActivity.testSpeaker() {
    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val prev = am.getStreamVolume(AudioManager.STREAM_MUSIC)
    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    try {
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.8).toInt(), 0)
    } catch (e: Exception) {
        // وضع عدم الإزعاج قد يمنع تغيير الصوت
    }
    val tg = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 100)
    } catch (e: Exception) {
        null
    }
    tg?.startTone(ToneGenerator.TONE_DTMF_6, 2500)
    ask(Test.SPEAKER, tr("شغّلنا نغمة من السماعة الآن.\nهل سمعتها بوضوح وبدون تشويش؟", "A tone is playing from the speaker.\nDid you hear it clearly, without distortion?")) {
        tg?.release()
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, prev, 0)
        } catch (e: Exception) {
            // تجاهل
        }
    }
}

internal fun MainActivity.testVibration() {
    val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
        (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    if (!vib.hasVibrator()) {
        toast(tr("الجهاز ما فيه محرك اهتزاز", "This device has no vibration motor"))
        record(Test.VIBRATION, false)
        return
    }
    vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 600), -1))
    ask(Test.VIBRATION, tr("هل حسّيت بالاهتزاز؟", "Did you feel the vibration?")) { vib.cancel() }
}

internal fun MainActivity.testFlash() {
    val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
    val id = try {
        cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (e: Exception) {
        null
    }
    if (id == null) {
        toast(tr("ما لقينا فلاش في الجهاز", "No flash found on this device"))
        record(Test.FLASH, false)
        return
    }
    try {
        cm.setTorchMode(id, true)
    } catch (e: Exception) {
        toast(tr("تعذّر تشغيل الفلاش", "Could not turn on the flash"))
        record(Test.FLASH, false)
        return
    }
    ask(Test.FLASH, tr("شغّلنا الفلاش الخلفي.\nهل هو شغّال؟", "The rear flash is on.\nIs it lit?")) {
        try {
            cm.setTorchMode(id, false)
        } catch (e: Exception) {
            // تجاهل
        }
    }
}

internal fun MainActivity.showPhoto(t: Test, bmp: Bitmap) {
    // الصورة الطولية كانت تطوّل الحوار وتدفّ الأزرار برا الشاشة في الجوالات الصغيرة،
    // فنحدد ارتفاعها بثلث الشاشة تقريباً والصورة تتصغّر داخلها
    val maxH = (resources.displayMetrics.heightPixels * 0.32f).toInt()
    val iv = ImageView(this).apply {
        setImageBitmap(bmp)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = FrameLayout.LayoutParams(-1, maxH)
    }
    val frame = FrameLayout(this).apply {
        setPadding(dp(20), dp(8), dp(20), 0)
        addView(iv)
    }
    PcDialog(this)
        .setTitle(t.title)
        .setMessage(tr("هل الصورة واضحة وبدون بقع أو غباش؟", "Is the photo clear, without spots or blur?"))
        .setView(frame)
        .setCancelable(false)
        .setPositiveButton(tr("نعم", "Yes")) { _, _ -> record(t, true) }
        .setNegativeButton(tr("لا", "No")) { _, _ -> record(t, false) }
        .show()
}

internal fun MainActivity.cameraCancelled(t: Test) {
    PcDialog(this)
        .setTitle(t.title)
        .setMessage(tr("ما تم التقاط صورة. هل الكاميرا ما اشتغلت؟", "No photo was taken. Did the camera fail to work?"))
        .setCancelable(false)
        .setPositiveButton(tr("الكاميرا ما تشتغل", "Camera not working")) { _, _ -> record(t, false) }
        .setNegativeButton(tr("تخطّي", "Skip")) { _, _ -> skip() }
        .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> start(t) }
        .show()
}

@SuppressLint("MissingPermission")
internal fun MainActivity.runMicTest() {
    var cancelled = false
    cleanup = { cancelled = true }
    val dlg = PcDialog(this)
        .setTitle(Test.MIC.title)
        .setMessage(tr("تكلّم بصوت واضح قرب أسفل الجوال لمدة 3 ثوانٍ…", "Speak clearly near the bottom of the phone for 3 seconds…"))
        .setCancelable(false)
        .show()
    Thread {
        var peak = 0
        try {
            val rate = 44100
            val minBuf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192)
            )
            val buf = ShortArray(2048)
            rec.startRecording()
            val end = System.currentTimeMillis() + 3000
            while (System.currentTimeMillis() < end) {
                val n = rec.read(buf, 0, buf.size)
                for (i in 0 until n) {
                    val a = abs(buf[i].toInt())
                    if (a > peak) peak = a
                }
            }
            rec.stop()
            rec.release()
        } catch (e: Exception) {
            peak = -1
        }
        runOnUiThread {
            if (!isFinishing && !cancelled) {
                dlg.dismiss()
                micResult(peak)
            }
        }
    }.start()
}

private fun MainActivity.micResult(peak: Int) {
    val ok = peak > 1500
    val msg = when {
        peak < 0 -> tr("تعذّر تشغيل المايك.", "Could not start the microphone.")
        ok -> tr("المايك يلتقط الصوت بشكل جيد ✓\n(مستوى الصوت: $peak)", "The microphone picks up sound well ✓\n(level: $peak)")
        else -> tr("الصوت الملتقط ضعيف جداً (المستوى: $peak).\nتأكد إنك تكلمت قرب المايك، أو أعد الاختبار.", "Very weak sound (level: $peak).\nMake sure you spoke near the mic, or retest.")
    }
    PcDialog(this)
        .setTitle(Test.MIC.title)
        .setMessage(msg)
        .setCancelable(false)
        .setPositiveButton(tr("تمام", "OK")) { _, _ -> record(Test.MIC, ok) }
        .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> runMicTest() }
        .show()
}

internal fun MainActivity.testButtons() {
    var up = false
    var down = false
    fun status() = tr("اضغط زر رفع الصوت ثم زر خفض الصوت.\n\n", "Press volume up, then volume down.\n\n") +
        tr("رفع الصوت: ", "Volume up: ") + (if (up) "✓" else "…") + "\n" +
        tr("خفض الصوت: ", "Volume down: ") + (if (down) "✓" else "…")

    val dlg = PcDialog(this)
        .setTitle(Test.BUTTONS.title)
        .setMessage(status())
        .setCancelable(false)
        .setNegativeButton(tr("زر ما يشتغل", "A button fails")) { _, _ -> record(Test.BUTTONS, false) }
        .create()
    dlg.setOnKeyListener { d, keyCode, event ->
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) RunControl.confirmStop(this)
            return@setOnKeyListener true
        }
        val isVolume = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (isVolume && event.action == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) up = true else down = true
            dlg.setMessage(status())
            if (up && down) {
                d.dismiss()
                record(Test.BUTTONS, true)
            }
        }
        isVolume
    }
    dlg.show()
}
