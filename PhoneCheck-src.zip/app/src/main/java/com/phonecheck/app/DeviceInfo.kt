package com.phonecheck.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.util.Locale
import kotlin.math.sqrt

data class InfoItem(val label: String, val value: String)
data class InfoSection(val title: String, val items: List<InfoItem>)

class DeviceSnapshot(
    val deviceName: String,
    val sections: List<InfoSection>,
    val batteryHealthCode: Int,
    val batteryTempC: Float,
    val batteryEstimatePct: Int?,
    val cycleCount: Int?,
    val sensorsFound: Int,
    val sensorsExpected: Int,
    val rooted: Boolean,
    val remote: Boolean = false,
)

object DeviceInfo {

    fun collect(ctx: Context): DeviceSnapshot {
        val sections = mutableListOf<InfoSection>()

        // ---------- الجهاز ----------
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.titlecase(Locale.US) }
        val deviceName =
            if (Build.MODEL.startsWith(Build.MANUFACTURER, ignoreCase = true)) Build.MODEL
            else "$manufacturer ${Build.MODEL}"
        val rooted = isRooted()
        sections += InfoSection(
            "الجهاز", listOf(
                InfoItem("الشركة", manufacturer),
                InfoItem("الموديل", Build.MODEL),
                InfoItem("الاسم الداخلي", Build.DEVICE),
                InfoItem("إصدار أندرويد", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"),
                InfoItem("آخر تحديث أمني", Build.VERSION.SECURITY_PATCH.ifBlank { "غير معروف" }),
                InfoItem("مدة التشغيل", formatUptime(SystemClock.elapsedRealtime())),
                InfoItem("صلاحيات الروت", if (rooted) "موجودة ⚠" else "غير موجودة"),
            )
        )

        // ---------- المعالج ----------
        val cores = Runtime.getRuntime().availableProcessors()
        val cpuItems = mutableListOf<InfoItem>()
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != Build.UNKNOWN) {
            cpuItems += InfoItem("المعالج", "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}")
        }
        cpuItems += InfoItem("العتاد", Build.HARDWARE)
        cpuItems += InfoItem("عدد الأنوية", "$cores")
        maxCpuFreqMhz(cores)?.let {
            cpuItems += InfoItem("أعلى سرعة", String.format(Locale.US, "%.2f GHz", it / 1000.0))
        }
        cpuItems += InfoItem("المعمارية", Build.SUPPORTED_ABIS.firstOrNull() ?: "-")
        sections += InfoSection("المعالج", cpuItems)

        // ---------- الذاكرة والتخزين ----------
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        val freePct = if (total > 0) free * 100 / total else 0
        sections += InfoSection(
            "الذاكرة والتخزين", listOf(
                InfoItem("الرام", gb(mi.totalMem)),
                InfoItem("الرام المتاحة الآن", gb(mi.availMem)),
                InfoItem("التخزين الكلي", gb(total)),
                InfoItem("التخزين الفاضي", "${gb(free)} ($freePct%)"),
            )
        )

        // ---------- البطارية ----------
        // تسجيل بدون مستقبل = قراءة آخر حالة للبطارية فقط
        val bi: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val volt = bi?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val health = bi?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val tech = bi?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() } ?: "-"
        val plugged = (bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val cycles: Int? =
            if (Build.VERSION.SDK_INT >= 34) bi?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)?.takeIf { it > 0 }
            else null
        val design = designCapacityMah(ctx)
        val estimate = estimateHealth(bm, pct, design)

        val batItems = mutableListOf(
            InfoItem("حالة البطارية", healthText(health)),
            InfoItem("نسبة الشحن", if (pct >= 0) "$pct%" else "-"),
            InfoItem("الحرارة", String.format(Locale.US, "%.1f°C", temp)),
            InfoItem("الجهد", String.format(Locale.US, "%.2f V", volt / 1000.0)),
            InfoItem("النوع", tech),
            InfoItem("الشاحن", if (plugged) "موصول" else "غير موصول"),
        )
        design?.let { batItems += InfoItem("السعة الأصلية", "${it.toInt()} mAh") }
        estimate?.let { batItems += InfoItem("صحة البطارية (تقديري)", "$it%") }
        cycles?.let { batItems += InfoItem("دورات الشحن", "$it") }
        sections += InfoSection("البطارية", batItems)

        // ---------- الشاشة ----------
        sections += InfoSection("الشاشة", displayItems(ctx))

        // ---------- الحساسات ----------
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val expected = listOf(
            Sensor.TYPE_ACCELEROMETER to "حساس الحركة",
            Sensor.TYPE_GYROSCOPE to "الجيروسكوب",
            Sensor.TYPE_MAGNETIC_FIELD to "البوصلة",
            Sensor.TYPE_PROXIMITY to "حساس القرب",
            Sensor.TYPE_LIGHT to "حساس الإضاءة",
        )
        val extra = listOf(
            Sensor.TYPE_PRESSURE to "البارومتر",
            Sensor.TYPE_STEP_COUNTER to "عدّاد الخطوات",
        )
        var found = 0
        val sensorItems = mutableListOf<InfoItem>()
        for ((type, name) in expected) {
            val ok = sm.getDefaultSensor(type) != null
            if (ok) found++
            sensorItems += InfoItem(name, if (ok) "موجود ✓" else "غير موجود ✗")
        }
        for ((type, name) in extra) {
            sensorItems += InfoItem(name, if (sm.getDefaultSensor(type) != null) "موجود" else "غير موجود")
        }
        sections += InfoSection("الحساسات", sensorItems)

        // ---------- الاتصال والمزايا ----------
        val pm = ctx.packageManager
        fun has(f: String) = if (pm.hasSystemFeature(f)) "موجود" else "غير موجود"
        val camCount = try {
            (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).cameraIdList.size
        } catch (e: Exception) {
            0
        }
        sections += InfoSection(
            "الاتصال والمزايا", listOf(
                InfoItem("الواي فاي", has(PackageManager.FEATURE_WIFI)),
                InfoItem("البلوتوث", has(PackageManager.FEATURE_BLUETOOTH)),
                InfoItem("NFC", has(PackageManager.FEATURE_NFC)),
                InfoItem("GPS", has(PackageManager.FEATURE_LOCATION_GPS)),
                InfoItem("شبكة الجوال", has(PackageManager.FEATURE_TELEPHONY)),
                InfoItem("البصمة", has(PackageManager.FEATURE_FINGERPRINT)),
                InfoItem("عدد الكاميرات", "$camCount"),
            )
        )

        return DeviceSnapshot(
            deviceName = deviceName,
            sections = sections,
            batteryHealthCode = health,
            batteryTempC = temp,
            batteryEstimatePct = estimate,
            cycleCount = cycles,
            sensorsFound = found,
            sensorsExpected = expected.size,
            rooted = rooted,
        )
    }

    @Suppress("DEPRECATION")
    private fun displayItems(ctx: Context): List<InfoItem> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = wm.defaultDisplay
        val dm = DisplayMetrics()
        d.getRealMetrics(dm)
        val wIn = dm.widthPixels / dm.xdpi
        val hIn = dm.heightPixels / dm.ydpi
        val inches = sqrt((wIn * wIn + hIn * hIn).toDouble())
        val maxHz = d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
        return listOf(
            InfoItem("الدقة", "${dm.widthPixels} x ${dm.heightPixels}"),
            InfoItem("الحجم التقريبي", String.format(Locale.US, "%.1f inch", inches)),
            InfoItem("كثافة البكسل", "${dm.densityDpi} dpi"),
            InfoItem("أعلى معدل تحديث", String.format(Locale.US, "%.0f Hz", maxHz)),
        )
    }

    private fun estimateHealth(bm: BatteryManager, pct: Int, design: Double?): Int? {
        if (design == null || pct < 15) return null
        val cc = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) // µAh
        if (cc <= 0) return null
        val fullMah = cc / 1000.0 / (pct / 100.0)
        val est = (fullMah / design * 100).toInt()
        return if (est in 40..120) est.coerceAtMost(100) else null
    }

    /** السعة الأصلية للبطارية من ملف الطاقة الداخلي (قد لا يتوفر في كل الأجهزة) */
    private fun designCapacityMah(ctx: Context): Double? = try {
        val cls = Class.forName("com.android.internal.os.PowerProfile")
        val obj = cls.getConstructor(Context::class.java).newInstance(ctx)
        val v = cls.getMethod("getBatteryCapacity").invoke(obj) as Double
        if (v > 500) v else null
    } catch (e: Throwable) {
        null
    }

    private fun maxCpuFreqMhz(cores: Int): Int? {
        var max = 0
        for (i in 0 until cores) {
            try {
                val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toInt()
                if (f > max) max = f
            } catch (e: Exception) {
                // غير متاح
            }
        }
        return if (max > 0) max / 1000 else null
    }

    private fun isRooted(): Boolean {
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/data/adb/magisk",
        )
        if (paths.any { File(it).exists() }) return true
        return Build.TAGS?.contains("test-keys") == true
    }

    private fun healthText(h: Int): String = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة ✓"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "سخونة زائدة ⚠"
        BatteryManager.BATTERY_HEALTH_DEAD -> "تالفة ✗"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد ⚠"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "عطل ✗"
        BatteryManager.BATTERY_HEALTH_COLD -> "باردة جداً"
        else -> "غير معروف"
    }

    private fun gb(bytes: Long): String = String.format(Locale.US, "%.1f GB", bytes / 1_000_000_000.0)

    private fun formatUptime(ms: Long): String {
        val totalMin = ms / 60_000
        val hours = totalMin / 60
        val days = hours / 24
        return if (days > 0) "$days يوم و ${hours % 24} ساعة" else "$hours ساعة و ${totalMin % 60} دقيقة"
    }
}
