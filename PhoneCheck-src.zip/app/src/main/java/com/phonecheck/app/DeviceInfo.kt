package com.phonecheck.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.util.Locale
import kotlin.math.sqrt

data class InfoItem(val label: String, val value: String)
data class InfoSection(val title: String, val items: List<InfoItem>)

class DeviceSnapshot(
    val deviceName: String,
    val sections: List<InfoSection>,
    val batteryHealthCode: Int,
    val batteryTempC: Float,
    val batteryEstimatePct: Int?,
    val cycleCount: Int?,
    val sensorsFound: Int,
    val sensorsExpected: Int,
    val rooted: Boolean,
    val remote: Boolean = false,
    val bootCount: Int? = null,
    val bootsPerDay: Double? = null,
    val bootloaderUnlocked: Boolean? = null,
    val knoxTripped: Boolean? = null,
    val age: AgeProfile? = null,
)

object DeviceInfo {

    fun collect(ctx: Context): DeviceSnapshot {
        val sections = mutableListOf<InfoSection>()

        // ---------- الجهاز ----------
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.titlecase(Locale.US) }
        val deviceName =
            if (Build.MODEL.startsWith(Build.MANUFACTURER, ignoreCase = true)) Build.MODEL
            else "$manufacturer ${Build.MODEL}"
        val rooted = isRooted()
        sections += InfoSection(
            tr("الجهاز", "Device"), listOf(
                InfoItem(tr("الشركة", "Brand"), manufacturer),
                InfoItem(tr("الموديل", "Model"), Build.MODEL),
                InfoItem(tr("الاسم الداخلي", "Codename"), Build.DEVICE),
                InfoItem(tr("إصدار أندرويد", "Android version"), "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"),
                InfoItem(tr("آخر تحديث أمني", "Security patch"), Build.VERSION.SECURITY_PATCH.ifBlank { tr("غير معروف", "Unknown") }),
                InfoItem(tr("مدة التشغيل", "Uptime"), formatUptime(SystemClock.elapsedRealtime())),
                InfoItem(tr("صلاحيات الروت", "Root access"), if (rooted) tr("موجودة ⚠", "Detected ⚠") else tr("غير موجودة", "Not detected")),
            )
        )

        // ---------- المعالج ----------
        val cores = Runtime.getRuntime().availableProcessors()
        val cpuItems = mutableListOf<InfoItem>()
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != Build.UNKNOWN) {
            cpuItems += InfoItem(tr("المعالج", "Chipset"), "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}")
        }
        cpuItems += InfoItem(tr("العتاد", "Hardware"), Build.HARDWARE)
        cpuItems += InfoItem(tr("عدد الأنوية", "CPU cores"), "$cores")
        maxCpuFreqMhz(cores)?.let {
            cpuItems += InfoItem(tr("أعلى سرعة", "Max frequency"), String.format(Locale.US, "%.2f GHz", it / 1000.0))
        }
        cpuItems += InfoItem(tr("المعمارية", "Architecture"), Build.SUPPORTED_ABIS.firstOrNull() ?: "-")
        sections += InfoSection(tr("المعالج", "Processor"), cpuItems)

        // ---------- الذاكرة والتخزين ----------
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        val freePct = if (total > 0) free * 100 / total else 0
        sections += InfoSection(
            tr("الذاكرة والتخزين", "Memory & storage"), listOf(
                InfoItem(tr("الرام", "RAM"), gb(mi.totalMem)),
                InfoItem(tr("الرام المتاحة الآن", "Available RAM"), gb(mi.availMem)),
                InfoItem(tr("التخزين الكلي", "Total storage"), gb(total)),
                InfoItem(tr("التخزين الفاضي", "Free storage"), "${gb(free)} ($freePct%)"),
            )
        )

        // ---------- البطارية ----------
        // تسجيل بدون مستقبل = قراءة آخر حالة للبطارية فقط
        val bi: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val volt = bi?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val health = bi?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val tech = bi?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() } ?: "-"
        val plugged = (bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val cycles: Int? =
            if (Build.VERSION.SDK_INT >= 34) bi?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)?.takeIf { it > 0 }
            else null
        val design = designCapacityMah(ctx)
        val estimate = estimateHealth(bm, pct, design)

        val batItems = mutableListOf(
            InfoItem(tr("حالة البطارية", "Battery health"), healthText(health)),
            InfoItem(tr("نسبة الشحن", "Charge level"), if (pct >= 0) "$pct%" else "-"),
            InfoItem(tr("الحرارة", "Temperature"), String.format(Locale.US, "%.1f°C", temp)),
            InfoItem(tr("الجهد", "Voltage"), String.format(Locale.US, "%.2f V", volt / 1000.0)),
            InfoItem(tr("النوع", "Technology"), tech),
            InfoItem(tr("الشاحن", "Charger"), if (plugged) tr("موصول", "Connected") else tr("غير موصول", "Not connected")),
        )
        design?.let { batItems += InfoItem(tr("السعة الأصلية", "Design capacity"), "${it.toInt()} mAh") }
        estimate?.let { batItems += InfoItem(tr("صحة البطارية (تقديري)", "Estimated health"), "$it%") }
        cycles?.let { batItems += InfoItem(tr("دورات الشحن", "Charge cycles"), "$it") }
        sections += InfoSection(tr("البطارية", "Battery"), batItems)

        // ---------- الشاشة ----------
        sections += InfoSection(tr("الشاشة", "Display"), displayItems(ctx))

        // ---------- الثبات ----------
        // عدد مرات إعادة التشغيل منذ آخر ضبط مصنع. الجوال اللي يطفي ويعيد التشغيل لحاله يرفع هذا الرقم بسرعة
        val bootCount = try {
            android.provider.Settings.Global.getInt(ctx.contentResolver, android.provider.Settings.Global.BOOT_COUNT)
        } catch (e: Exception) {
            null
        }
        val days = daysInUse(ctx)
        val perDay = if (bootCount != null && days != null && days >= 7) bootCount.toDouble() / days else null
        val stab = mutableListOf<InfoItem>()
        stab += InfoItem(tr("مرات إعادة التشغيل", "Restarts"), bootCount?.let { "$it" } ?: tr("غير متاح", "Not available"))
        days?.let { stab += InfoItem(tr("مدة الاستخدام منذ آخر ضبط مصنع", "In use since last reset"), tr("$it يوم تقريباً", "about $it days")) }
        perDay?.let {
            stab += InfoItem(
                tr("معدل إعادة التشغيل", "Restart rate"),
                String.format(Locale.US, "%.1f ", it) + tr("باليوم", "per day") +
                    if (it > 1.5) tr(" ⚠ كثير", " ⚠ high") else ""
            )
        }
        sections += InfoSection(tr("الثبات", "Stability"), stab)

        // ---------- العمر والدعم ----------
        val age = try {
            AgeAnalyzer.analyze(ctx)
        } catch (e: Exception) {
            null
        }
        age?.let { sections += InfoSection(tr("العمر والدعم", "Age & support"), AgeAnalyzer.items(it)) }

        // ---------- سلامة النظام ----------
        // حالة الإقلاع الموثّق: green = النظام أصلي والبوتلودر مقفل، orange = البوتلودر مفتوح (نظام معدّل أو قابل للتعديل)
        val vbState = prop("ro.boot.verifiedbootstate")
        val flashLocked = prop("ro.boot.flash.locked")
        val unlocked: Boolean? = when {
            vbState == "orange" || flashLocked == "0" -> true
            vbState == "green" || flashLocked == "1" -> false
            else -> null
        }
        // سامسونج: لو انكسر الـ Knox (تعديل سابق على النظام) يبقى 1 للأبد
        val warranty = prop("ro.boot.warranty_bit")
        val knox: Boolean? = when (warranty) {
            "1" -> true
            "0" -> false
            else -> null
        }
        val sys = mutableListOf<InfoItem>()
        sys += InfoItem(
            tr("البوتلودر", "Bootloader"),
            when (unlocked) {
                true -> tr("مفتوح ⚠", "Unlocked ⚠")
                false -> tr("مقفل ✓", "Locked ✓")
                null -> tr("غير معروف", "Unknown")
            }
        )
        vbState?.let {
            sys += InfoItem(
                tr("الإقلاع الموثّق", "Verified boot"),
                when (it) {
                    "green" -> tr("أصلي ✓", "Original ✓")
                    "yellow" -> tr("مفتاح مخصص ⚠", "Custom key ⚠")
                    "orange" -> tr("غير موثّق ⚠", "Not verified ⚠")
                    else -> it
                }
            )
        }
        knox?.let {
            sys += InfoItem("Samsung Knox", if (it) tr("مكسور ⚠ (تعديل سابق)", "Tripped ⚠ (modified before)") else tr("سليم ✓", "Intact ✓"))
        }
        sections += InfoSection(tr("سلامة النظام", "System integrity"), sys)

        // ---------- الحساسات ----------
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val expected = listOf(
            Sensor.TYPE_ACCELEROMETER to tr("حساس الحركة", "Accelerometer"),
            Sensor.TYPE_GYROSCOPE to tr("الجيروسكوب", "Gyroscope"),
            Sensor.TYPE_MAGNETIC_FIELD to tr("البوصلة", "Compass"),
            Sensor.TYPE_PROXIMITY to tr("حساس القرب", "Proximity"),
            Sensor.TYPE_LIGHT to tr("حساس الإضاءة", "Light sensor"),
        )
        val extra = listOf(
            Sensor.TYPE_PRESSURE to tr("البارومتر", "Barometer"),
            Sensor.TYPE_STEP_COUNTER to tr("عدّاد الخطوات", "Step counter"),
        )
        var found = 0
        val sensorItems = mutableListOf<InfoItem>()
        for ((type, name) in expected) {
            val ok = sm.getDefaultSensor(type) != null
            if (ok) found++
            sensorItems += InfoItem(name, if (ok) tr("موجود ✓", "Present ✓") else tr("غير موجود ✗", "Missing ✗"))
        }
        for ((type, name) in extra) {
            sensorItems += InfoItem(name, if (sm.getDefaultSensor(type) != null) tr("موجود", "Present") else tr("غير موجود", "Not present"))
        }
        sections += InfoSection(tr("الحساسات", "Sensors"), sensorItems)

        // ---------- الاتصال والمزايا ----------
        val pm = ctx.packageManager
        fun has(f: String) = if (pm.hasSystemFeature(f)) tr("موجود", "Yes") else tr("غير موجود", "No")
        val camCount = try {
            (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).cameraIdList.size
        } catch (e: Exception) {
            0
        }
        sections += InfoSection(
            tr("الاتصال والمزايا", "Connectivity & features"), listOf(
                InfoItem(tr("الواي فاي", "Wi-Fi"), has(PackageManager.FEATURE_WIFI)),
                InfoItem(tr("البلوتوث", "Bluetooth"), has(PackageManager.FEATURE_BLUETOOTH)),
                InfoItem("NFC", has(PackageManager.FEATURE_NFC)),
                InfoItem("GPS", has(PackageManager.FEATURE_LOCATION_GPS)),
                InfoItem(tr("شبكة الجوال", "Cellular"), has(PackageManager.FEATURE_TELEPHONY)),
                InfoItem(tr("البصمة", "Fingerprint"), has(PackageManager.FEATURE_FINGERPRINT)),
                InfoItem(tr("عدد الكاميرات", "Cameras"), "$camCount"),
            )
        )

        return DeviceSnapshot(
            deviceName = deviceName,
            sections = sections,
            batteryHealthCode = health,
            batteryTempC = temp,
            batteryEstimatePct = estimate,
            cycleCount = cycles,
            sensorsFound = found,
            sensorsExpected = expected.size,
            rooted = rooted,
            bootCount = bootCount,
            bootsPerDay = perDay,
            bootloaderUnlocked = unlocked,
            knoxTripped = knox,
            age = age,
        )
    }

    /** قراءة خاصية من النظام عن طريق getprop (ما تحتاج صلاحيات) */
    internal fun prop(name: String): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("getprop", name))
        val v = p.inputStream.bufferedReader().use { it.readText() }.trim()
        p.waitFor()
        v.ifBlank { null }
    } catch (e: Exception) {
        null
    }

    /** تقريباً كم يوم من أول تطبيق انثبّت (بعد آخر ضبط مصنع) */
    private fun daysInUse(ctx: Context): Int? = try {
        val pm = ctx.packageManager
        val earliest = pm.getInstalledPackages(0)
            .filter { it.applicationInfo != null && (it.applicationInfo!!.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 }
            .filter { it.packageName != ctx.packageName }
            .minOfOrNull { it.firstInstallTime }
        earliest?.let { ((System.currentTimeMillis() - it) / 86_400_000L).toInt().coerceAtLeast(0) }
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun displayItems(ctx: Context): List<InfoItem> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = wm.defaultDisplay
        val dm = DisplayMetrics()
        d.getRealMetrics(dm)
        val wIn = dm.widthPixels / dm.xdpi
        val hIn = dm.heightPixels / dm.ydpi
        val inches = sqrt((wIn * wIn + hIn * hIn).toDouble())
        val maxHz = d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
        return listOf(
            InfoItem(tr("الدقة", "Resolution"), "${dm.widthPixels} x ${dm.heightPixels}"),
            InfoItem(tr("الحجم التقريبي", "Approx. size"), String.format(Locale.US, "%.1f inch", inches)),
            InfoItem(tr("كثافة البكسل", "Pixel density"), "${dm.densityDpi} dpi"),
            InfoItem(tr("أعلى معدل تحديث", "Max refresh rate"), String.format(Locale.US, "%.0f Hz", maxHz)),
        )
    }

    private fun estimateHealth(bm: BatteryManager, pct: Int, design: Double?): Int? {
        if (design == null || pct < 15) return null
        val cc = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) // µAh
        if (cc <= 0) return null
        val fullMah = cc / 1000.0 / (pct / 100.0)
        val est = (fullMah / design * 100).toInt()
        return if (est in 40..120) est.coerceAtMost(100) else null
    }

    /** السعة الأصلية للبطارية من ملف الطاقة الداخلي (قد لا يتوفر في كل الأجهزة) */
    private fun designCapacityMah(ctx: Context): Double? = try {
        val cls = Class.forName("com.android.internal.os.PowerProfile")
        val obj = cls.getConstructor(Context::class.java).newInstance(ctx)
        val v = cls.getMethod("getBatteryCapacity").invoke(obj) as Double
        if (v > 500) v else null
    } catch (e: Throwable) {
        null
    }

    private fun maxCpuFreqMhz(cores: Int): Int? {
        var max = 0
        for (i in 0 until cores) {
            try {
                val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toInt()
                if (f > max) max = f
            } catch (e: Exception) {
                // غير متاح
            }
        }
        return if (max > 0) max / 1000 else null
    }

    private fun isRooted(): Boolean {
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/data/adb/magisk",
        )
        if (paths.any { File(it).exists() }) return true
        return Build.TAGS?.contains("test-keys") == true
    }

    private fun healthText(h: Int): String = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> tr("جيدة ✓", "Good ✓")
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> tr("سخونة زائدة ⚠", "Overheating ⚠")
        BatteryManager.BATTERY_HEALTH_DEAD -> tr("تالفة ✗", "Dead ✗")
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> tr("جهد زائد ⚠", "Over voltage ⚠")
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> tr("عطل ✗", "Failure ✗")
        BatteryManager.BATTERY_HEALTH_COLD -> tr("باردة جداً", "Too cold")
        else -> tr("غير معروف", "Unknown")
    }

    private fun gb(bytes: Long): String = String.format(Locale.US, "%.1f GB", bytes / 1_000_000_000.0)

    private fun formatUptime(ms: Long): String {
        val totalMin = ms / 60_000
        val hours = totalMin / 60
        val days = hours / 24
        return if (days > 0) tr("$days يوم و ${hours % 24} ساعة", "${days}d ${hours % 24}h")
        else tr("$hours ساعة و ${totalMin % 60} دقيقة", "${hours}h ${totalMin % 60}m")
    }
}
