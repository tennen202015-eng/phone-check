package com.phonecheck.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telephony.TelephonyManager
import androidx.appcompat.app.AlertDialog
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import kotlin.math.abs
import kotlin.math.sqrt

private val mainHandler = Handler(Looper.getMainLooper())

/** حوار عام: المستخدم يجهّز الشي ثم يضغط "تحقّق". check يرجع نص النجاح أو null */
internal fun MainActivity.checkDialog(t: Test, instruction: String, retry: Boolean = false, check: () -> String?) {
    val msg = if (retry) tr("ما زال الاختبار ما نجح.\n\n", "Not passed yet.\n\n") + instruction else instruction
    PcDialog(this)
        .setTitle(t.title)
        .setMessage(msg)
        .setCancelable(false)
        .setPositiveButton(tr("تحقّق", "Check")) { _, _ ->
            val ok = try {
                check()
            } catch (e: Exception) {
                null
            }
            if (ok != null) {
                toast(ok)
                record(t, true)
            } else {
                checkDialog(t, instruction, true, check)
            }
        }
        .setNegativeButton(tr("لا يعمل", "Not working")) { _, _ -> record(t, false) }
        .setNeutralButton(tr("تخطّي", "Skip")) { _, _ -> skip() }
        .show()
}

// ---------------- منفذ الشحن ----------------
internal fun MainActivity.testCharging() {
    val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    var active = true
    var plugTime = 0L
    var charging = false
    var plugName = ""
    val samples = mutableListOf<Int>()
    val startT = SystemClock.elapsedRealtime()
    lateinit var dlg: AlertDialog

    fun currentMa(): Int? {
        val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (v == Int.MIN_VALUE || v == 0) return null
        val a = abs(v)
        return if (a > 20000) a / 1000 else a // بعض الأجهزة ترجع µA وبعضها mA
    }

    fun finishTest() {
        active = false
        dlg.dismiss()
        val avg = if (samples.isEmpty()) null else samples.sum() / samples.size
        val ok = plugTime > 0 && charging
        val msg = when {
            plugTime == 0L -> tr("ما انكشف أي شاحن.\nتأكد من الكيبل والشاحن، أو المنفذ فيه مشكلة.", "No charger detected.\nCheck the cable and charger, or the port may be faulty.")
            !charging -> tr("الشاحن موصول لكن الجوال ما يشحن ✗\nممكن المشكلة في المنفذ أو الكيبل.", "Charger connected but the phone is not charging ✗\nThe port or cable may be faulty.")
            avg != null -> tr("الشحن شغّال ✓ ($plugName)\nسرعة الشحن التقريبية: $avg mA\n\nالسرعة تعتمد كمان على الشاحن والكيبل ونسبة البطارية.", "Charging works ✓ ($plugName)\nApprox. charging current: $avg mA\n\nSpeed also depends on the charger, cable and battery level.")
            else -> tr("الشحن شغّال ✓ ($plugName)\nقياس سرعة الشحن غير متاح في هذا الجهاز.", "Charging works ✓ ($plugName)\nCharging speed is not available on this device.")
        }
        PcDialog(this)
            .setTitle(Test.CHARGING.title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton(tr("تمام", "OK")) { _, _ ->
                if (ok && avg != null) Results.details[Test.CHARGING] = "$avg mA"
                record(Test.CHARGING, ok)
            }
            .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> testCharging() }
            .show()
    }

    dlg = PcDialog(this)
        .setTitle(Test.CHARGING.title)
        .setMessage(tr("وصّل الشاحن الآن…\n(إذا كان موصول، افصله ووصّله من جديد)", "Plug in the charger now…\n(If it is already plugged in, unplug and plug it back in)"))
        .setCancelable(false)
        .setNegativeButton(tr("إيقاف", "Stop")) { _, _ ->
            active = false
            finishTest()
        }
        .show()
    cleanup = { active = false }

    val tick = object : Runnable {
        override fun run() {
            if (!active) return
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val plug = bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
            val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val now = SystemClock.elapsedRealtime()
            if (plug != 0) {
                if (plugTime == 0L) plugTime = now
                plugName = when (plug) {
                    BatteryManager.BATTERY_PLUGGED_AC -> tr("شاحن جداري", "wall charger")
                    BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> tr("لاسلكي", "wireless")
                    else -> tr("شاحن", "charger")
                }
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                // نتجاهل أول ثانيتين لين يستقر التيار
                if (now - plugTime > 2000) currentMa()?.let { samples += it }
                dlg.setMessage(tr("✓ الشاحن موصول ($plugName)\nجاري قياس سرعة الشحن…", "✓ Charger connected ($plugName)\nMeasuring charging speed…"))
                if (now - plugTime > 8000) {
                    finishTest()
                    return
                }
            } else if (plugTime > 0) {
                // انفصل أثناء القياس
                plugTime = 0L
                samples.clear()
                dlg.setMessage(tr("انفصل الشاحن! وصّله مرة ثانية وخلّه ثابت…", "Charger disconnected! Plug it in again and keep it steady…"))
            }
            if (now - startT > 60000) {
                finishTest()
                return
            }
            mainHandler.postDelayed(this, 700)
        }
    }
    mainHandler.postDelayed(tick, 700)
}

// ---------------- سماعة المكالمات ----------------
internal fun MainActivity.testEarpiece() {
    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val prevMode = am.mode
    val prevVol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
    try {
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            am.availableCommunicationDevices
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
                ?.let { am.setCommunicationDevice(it) }
        } else {
            am.isSpeakerphoneOn = false
        }
        am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
    } catch (e: Exception) {
        // نكمل حتى لو ما قدرنا نغيّر الإعدادات
    }
    val tg = try {
        ToneGenerator(AudioManager.STREAM_VOICE_CALL, 100)
    } catch (e: Exception) {
        null
    }
    tg?.startTone(ToneGenerator.TONE_SUP_DIAL)
    ask(Test.EARPIECE, tr("قرّب أعلى الجوال من أذنك كأنك في مكالمة.\nهل تسمع نغمة واضحة؟", "Hold the top of the phone to your ear like a call.\nDo you hear a clear tone?")) {
        tg?.stopTone()
        tg?.release()
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
            am.mode = prevMode
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, prevVol, 0)
        } catch (e: Exception) {
            // تجاهل
        }
    }
}

// ---------------- حساس القرب ----------------
// نعتمد على "تغيّر" القراءة بدل مقارنتها بأقصى مدى، لأن كل شركة ترجع أرقام مختلفة
// (بعضها 0/5، وبعضها 3/5، وبعضها 0/1). تغطية = القراءة نزلت، رفع = رجعت فوق.
// بعض الجوالات (خصوصاً شاومي) فيها حساس افتراضي ما يشتغل إلا وقت المكالمة،
// فلو ما وصلت أي قراءة نعطي المستخدم طريقة يتأكد فيها يدوياً.
internal fun MainActivity.testProximity() {
    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val s = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY, true) ?: sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    if (s == null) {
        toast(tr("الجهاز ما فيه حساس قرب", "This device has no proximity sensor"))
        skip()
        return
    }
    var near = false
    var far = false
    var last: Float? = null
    var changes = 0
    var finished = false
    lateinit var dlg: AlertDialog
    fun msg() = tr(
        "غطّي أعلى الشاشة (جنب الكاميرا الأمامية) بكف يدك لمدة ثانية، ثم ارفعها.\n\n",
        "Cover the top of the screen (near the front camera) with your palm for a second, then lift it.\n\n"
    ) + tr("تغطية: ", "Covered: ") + (if (near) "✓" else "…") + "\n" + tr("رفع: ", "Uncovered: ") + (if (far) "✓" else "…")

    lateinit var listener: SensorEventListener
    fun stop() {
        finished = true
        sm.unregisterListener(listener)
    }

    listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (finished) return
            val v = e.values[0]
            val prev = last
            last = v
            if (prev != null && v != prev) {
                changes++
                if (v < prev) near = true else if (near) far = true
            } else if (prev == null && v <= 0f) {
                // أول قراءة صفر = مغطّى من البداية
                near = true
            }
            dlg.setMessage(msg())
            if (near && far) {
                stop()
                dlg.dismiss()
                record(Test.PROXIMITY, true)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    dlg = PcDialog(this)
        .setTitle(Test.PROXIMITY.title)
        .setMessage(msg())
        .setCancelable(false)
        .setNegativeButton(tr("ما يستجيب", "Not responding")) { _, _ ->
            stop()
            proximityManual()
        }
        .setNeutralButton(tr("تخطّي", "Skip")) { _, _ ->
            stop()
            skip()
        }
        .show()
    sm.registerListener(listener, s, SensorManager.SENSOR_DELAY_UI)
    cleanup = { stop() }

    // لو مرّت 10 ثواني بدون أي تغيّر في القراءة، غالباً الحساس افتراضي
    Handler(Looper.getMainLooper()).postDelayed({
        if (!finished && changes == 0 && !near) {
            stop()
            dlg.dismiss()
            proximityManual()
        }
    }, 10_000)
}

/** تأكيد يدوي عن طريق مكالمة: الحساس الافتراضي يشتغل فقط وقت الاتصال */
private fun MainActivity.proximityManual() {
    PcDialog(this)
        .setTitle(Test.PROXIMITY.title)
        .setMessage(
            tr(
                "ما وصلتنا قراءة من الحساس. بعض الجوالات (مثل شاومي) فيها حساس ما يشتغل إلا وقت المكالمة.\n\n" +
                    "اتصل بأي رقم، وقرّب الجوال من أذنك أو غطّي أعلى الشاشة بيدك:\n" +
                    "هل الشاشة تنطفي، ثم ترجع تنور لما تبعد يدك؟",
                "No reading from the sensor. Some phones (e.g. Xiaomi) use a sensor that only works during calls.\n\n" +
                    "Call any number and hold the phone to your ear, or cover the top of the screen:\n" +
                    "Does the screen turn off, then back on when you move away?"
            )
        )
        .setCancelable(false)
        .setPositiveButton(tr("نعم، تنطفي", "Yes, it turns off")) { _, _ -> record(Test.PROXIMITY, true) }
        .setNegativeButton(tr("لا", "No")) { _, _ -> record(Test.PROXIMITY, false) }
        .setNeutralButton(tr("إعادة الاختبار", "Retest")) { _, _ -> testProximity() }
        .show()
}

// ---------------- حساسات الحركة ----------------
internal fun MainActivity.testMotion() {
    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    if (acc == null && gyro == null) {
        toast(tr("الجهاز ما فيه حساسات حركة", "This device has no motion sensors"))
        record(Test.MOTION, false)
        return
    }
    var accOk = false
    var gyroOk = false
    var minA = Float.MAX_VALUE
    var maxA = 0f
    var finished = false
    lateinit var dlg: AlertDialog

    fun line(name: String, exists: Boolean, ok: Boolean) =
        "$name: " + when {
            !exists -> tr("غير موجود", "not present")
            ok -> "✓"
            else -> "…"
        }

    fun msg() = tr("حرّك الجوال بقوة وقلّبه في يدك.\n\n", "Shake the phone and rotate it in your hand.\n\n") +
        line(tr("حساس التسارع", "Accelerometer"), acc != null, accOk) + "\n" +
        line(tr("الجيروسكوب", "Gyroscope"), gyro != null, gyroOk)

    val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (finished) return
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            val m = sqrt(x * x + y * y + z * z)
            when (e.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    if (m < minA) minA = m
                    if (m > maxA) maxA = m
                    if (maxA - minA > 6f) accOk = true
                }
                Sensor.TYPE_GYROSCOPE -> if (m > 2f) gyroOk = true
            }
            dlg.setMessage(msg())
            if ((acc == null || accOk) && (gyro == null || gyroOk)) {
                finished = true
                sm.unregisterListener(this)
                dlg.dismiss()
                record(Test.MOTION, true)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    dlg = PcDialog(this)
        .setTitle(Test.MOTION.title)
        .setMessage(msg())
        .setCancelable(false)
        .setNegativeButton(tr("ما يستجيب", "Not responding")) { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            record(Test.MOTION, false)
        }
        .setNeutralButton(tr("تخطّي", "Skip")) { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            skip()
        }
        .show()
    cleanup = {
        finished = true
        sm.unregisterListener(listener)
    }
    acc?.let { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME) }
    gyro?.let { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME) }
}

// ---------------- البصمة ----------------
internal fun MainActivity.testFingerprint() {
    val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK
    when (BiometricManager.from(this).canAuthenticate(auth)) {
        BiometricManager.BIOMETRIC_SUCCESS -> Unit
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
            toast(tr("الجهاز ما فيه بصمة", "This device has no fingerprint sensor"))
            skip()
            return
        }
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
            PcDialog(this)
                .setTitle(Test.FINGERPRINT.title)
                .setMessage(tr("ما فيه بصمة مسجّلة في الجهاز.\nسجّل بصمة من الإعدادات ← الأمان، ثم أعد الاختبار.", "No fingerprint is enrolled.\nAdd one in Settings → Security, then retest."))
                .setCancelable(false)
                .setPositiveButton(tr("تمام", "OK")) { _, _ -> skip() }
                .show()
            return
        }
        else -> {
            toast(tr("حساس البصمة غير متاح حالياً", "Fingerprint sensor is unavailable"))
            record(Test.FINGERPRINT, false)
            return
        }
    }

    var cancelled = false
    val prompt = BiometricPrompt(
        this,
        ContextCompat.getMainExecutor(this),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                toast(tr("البصمة تشتغل ✓", "Fingerprint works ✓"))
                record(Test.FINGERPRINT, true)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (cancelled) return
                PcDialog(this@testFingerprint)
                    .setTitle(Test.FINGERPRINT.title)
                    .setMessage(tr("ما تمت قراءة البصمة ($errString).\nهل الحساس ما يقرأ إصبعك؟", "Fingerprint not read ($errString).\nIs the sensor failing to read your finger?"))
                    .setCancelable(false)
                    .setPositiveButton(tr("ما يشتغل", "Not working")) { _, _ -> record(Test.FINGERPRINT, false) }
                    .setNegativeButton(tr("تخطّي", "Skip")) { _, _ -> skip() }
                    .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> testFingerprint() }
                    .show()
            }
        }
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(tr("اختبار البصمة", "Fingerprint test"))
        .setSubtitle(tr("ضع إصبعك المسجّل على حساس البصمة", "Place an enrolled finger on the sensor"))
        .setNegativeButtonText(tr("إلغاء", "Cancel"))
        .setAllowedAuthenticators(auth)
        .build()
    cleanup = {
        cancelled = true
        prompt.cancelAuthentication()
    }
    prompt.authenticate(info)
}

// ---------------- الواي فاي ----------------
internal fun MainActivity.testWifi() {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    checkDialog(Test.WIFI, tr("شغّل الواي فاي واتصل بأي شبكة، ثم اضغط تحقّق.", "Turn on Wi-Fi and connect to any network, then tap Check.")) {
        @Suppress("DEPRECATION")
        val connected = cm.allNetworks.any {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
        if (connected) tr("الواي فاي متصل ✓", "Wi-Fi connected ✓") else null
    }
}

// ---------------- البلوتوث ----------------
@SuppressLint("MissingPermission")
internal fun MainActivity.testBluetooth() {
    val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    if (adapter == null) {
        toast(tr("الجهاز ما فيه بلوتوث", "This device has no Bluetooth"))
        skip()
        return
    }
    checkDialog(Test.BLUETOOTH, tr("شغّل البلوتوث من الإعدادات السريعة، ثم اضغط تحقّق.", "Turn on Bluetooth from quick settings, then tap Check.")) {
        if (adapter.isEnabled) tr("البلوتوث اشتغل ✓", "Bluetooth is on ✓") else null
    }
}

// ---------------- الشريحة والإشارة ----------------
internal fun MainActivity.testSignal() {
    if (!packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) {
        toast(tr("الجهاز ما يدعم الشرائح", "This device does not support SIM cards"))
        skip()
        return
    }
    val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    // لو الشريحة من شبكة ثانية والجوال مقفول على شبكته، النظام يرجع NETWORK_LOCKED
    if (tm.simState == TelephonyManager.SIM_STATE_NETWORK_LOCKED) {
        Results.networkLocked = true
        Results.details[Test.SIGNAL] = tr("مقفول على شبكة", "Network locked")
        PcDialog(this)
            .setTitle(Test.SIGNAL.title)
            .setMessage(tr(
                "الجوال مقفول على شبكة معيّنة ✗\nالشريحة المركّبة من شبكة ثانية والجوال رافضها.\nما يشتغل إلا مع شبكة واحدة.",
                "The phone is network locked ✗\nThe inserted SIM is from another carrier and was rejected.\nIt only works with one carrier."
            ))
            .setCancelable(false)
            .setPositiveButton(tr("تمام", "OK")) { _, _ -> record(Test.SIGNAL, false) }
            .show()
        return
    }
    checkDialog(
        Test.SIGNAL,
        tr(
            "تأكد إن فيه شريحة مركّبة ووضع الطيران مقفل، ثم اضغط تحقّق.\n\nنصيحة: جرّب شريحة من شبكة مختلفة عن شبكة البائع عشان نكشف لو الجوال مقفول على شبكة.",
            "Make sure a SIM is inserted and airplane mode is off, then tap Check.\n\nTip: try a SIM from a different carrier than the seller's to detect a network lock."
        )
    ) {
        when (tm.simState) {
            TelephonyManager.SIM_STATE_NETWORK_LOCKED -> {
                Results.networkLocked = true
                null
            }
            TelephonyManager.SIM_STATE_READY -> {
                val level = if (Build.VERSION.SDK_INT >= 28) tm.signalStrength?.level ?: 0 else 2
                val op = tm.networkOperatorName?.takeIf { it.isNotBlank() } ?: tr("غير معروف", "Unknown")
                if (level >= 1) {
                    Results.details[Test.SIGNAL] = "$op · $level/4"
                    tr("الشريحة شغّالة ✓ — $op — الإشارة $level/4", "SIM works ✓ — $op — signal $level/4")
                } else null
            }
            else -> null
        }
    }
}

// ---------------- الـ GPS ----------------
@SuppressLint("MissingPermission")
internal fun MainActivity.runGps() {
    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    if (!lm.allProviders.contains(LocationManager.GPS_PROVIDER)) {
        toast(tr("الجهاز ما فيه GPS", "This device has no GPS"))
        record(Test.GPS, false)
        return
    }
    if (!LocationManagerCompat.isLocationEnabled(lm)) {
        PcDialog(this)
            .setTitle(Test.GPS.title)
            .setMessage(tr("شغّل الموقع (GPS) من الإعدادات السريعة، ثم اضغط إعادة.", "Turn on Location (GPS) from quick settings, then tap Retry."))
            .setCancelable(false)
            .setPositiveButton(tr("إعادة", "Retry")) { _, _ -> runGps() }
            .setNegativeButton(tr("تخطّي", "Skip")) { _, _ -> skip() }
            .show()
        return
    }

    var sats = 0
    var best = 0
    var fix = false
    var active = true
    val startT = SystemClock.elapsedRealtime()
    lateinit var dlg: AlertDialog

    val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            fix = true
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }
    val callback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var n = 0
            for (i in 0 until status.satelliteCount) if (status.getCn0DbHz(i) > 0f) n++
            sats = n
            if (n > best) best = n
        }
    }

    fun stop() {
        active = false
        try {
            lm.removeUpdates(listener)
            lm.unregisterGnssStatusCallback(callback)
        } catch (e: Exception) {
            // تجاهل
        }
    }

    dlg = PcDialog(this)
        .setTitle(Test.GPS.title)
        .setMessage(tr("جاري البحث عن الأقمار الصناعية…\nالأفضل تكون قرب نافذة أو برّا.", "Searching for satellites…\nBest near a window or outdoors."))
        .setCancelable(false)
        .setNegativeButton(tr("إيقاف", "Stop")) { _, _ ->
            stop()
            gpsResult(best, fix)
        }
        .show()

    try {
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
        lm.registerGnssStatusCallback(callback, mainHandler)
    } catch (e: Exception) {
        stop()
        dlg.dismiss()
        toast(tr("تعذّر تشغيل الـ GPS", "Could not start GPS"))
        record(Test.GPS, false)
        return
    }

    cleanup = { stop() }
    val tick = object : Runnable {
        override fun run() {
            if (!active) return
            dlg.setMessage(tr("جاري البحث عن الأقمار الصناعية…\nالأقمار المرصودة الآن: $sats\n\nالأفضل تكون قرب نافذة أو برّا.", "Searching for satellites…\nSatellites in view: $sats\n\nBest near a window or outdoors."))
            if (best >= 4 || fix || SystemClock.elapsedRealtime() - startT > 45000) {
                stop()
                dlg.dismiss()
                gpsResult(best, fix)
                return
            }
            mainHandler.postDelayed(this, 1000)
        }
    }
    mainHandler.postDelayed(tick, 1000)
}

private fun MainActivity.gpsResult(best: Int, fix: Boolean) {
    val ok = best >= 4 || fix
    val msg = if (ok) tr("الـ GPS شغّال ✓\nأعلى عدد أقمار مرصودة: $best", "GPS works ✓\nMax satellites in view: $best")
    else tr("ما قدرنا نلتقط إشارة كافية (الأقمار: $best).\nجرّب قرب نافذة أو برّا، ثم أعد الاختبار.", "Signal too weak (satellites: $best).\nTry near a window or outdoors, then retest.")
    PcDialog(this)
        .setTitle(Test.GPS.title)
        .setMessage(msg)
        .setCancelable(false)
        .setPositiveButton(tr("تمام", "OK")) { _, _ -> record(Test.GPS, ok) }
        .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> runGps() }
        .show()
}

// ---------------- سرعة التخزين ----------------
// نكتب ملف 64 ميجا ونقيس سرعة الكتابة، ونقرأه ونقيس القراءة. التخزين التالف أو الرخيص يطلع بطيء جداً.
internal fun MainActivity.testStorage() {
    val dlg = PcDialog(this)
        .setTitle(Test.STORAGE.title)
        .setMessage(tr("جاري فحص التخزين: السرعة وسلامة البيانات… (ثواني قليلة)", "Checking storage speed and data integrity… (a few seconds)"))
        .setCancelable(false)
        .show()
    var cancelled = false
    cleanup = { cancelled = true }
    Thread {
        var write = -1
        var read = -1
        var badChunks = 0
        val f = java.io.File(cacheDir, "speedtest.bin")
        val chunks = 64
        // كل قطعة لها نمط مختلف، عشان لو التخزين يرجّع بيانات غلط نكتشفها
        fun fill(buf: ByteArray, i: Int) {
            val rnd = java.util.Random(i * 7919L + 13)
            rnd.nextBytes(buf)
        }
        try {
            val chunk = ByteArray(1024 * 1024)
            var t0 = SystemClock.elapsedRealtimeNanos()
            java.io.FileOutputStream(f).use { out ->
                for (i in 0 until chunks) {
                    if (cancelled) break
                    fill(chunk, i)
                    out.write(chunk)
                }
                out.flush()
                out.fd.sync()
            }
            var secs = (SystemClock.elapsedRealtimeNanos() - t0) / 1e9
            write = (chunks / secs).toInt()
            val expect = ByteArray(chunk.size)
            var readSecs = 0.0
            java.io.DataInputStream(java.io.FileInputStream(f)).use { inp ->
                for (i in 0 until chunks) {
                    if (cancelled) break
                    t0 = SystemClock.elapsedRealtimeNanos()
                    inp.readFully(chunk)
                    readSecs += (SystemClock.elapsedRealtimeNanos() - t0) / 1e9
                    fill(expect, i)
                    if (!chunk.contentEquals(expect)) badChunks++
                }
            }
            read = if (readSecs > 0) (chunks / readSecs).toInt() else -1
        } catch (e: Exception) {
            write = -1
        } finally {
            f.delete()
        }
        runOnUiThread {
            if (isFinishing || cancelled) return@runOnUiThread
            dlg.dismiss()
            // أقل من 15 MB/s كتابة = تخزين بطيء جداً، وأي بيانات تالفة = تخزين معطوب
            val ok = write >= 15 && badChunks == 0
            val speeds = tr("الكتابة: $write MB/s\nالقراءة: $read MB/s", "Write: $write MB/s\nRead: $read MB/s")
            val msg = when {
                write < 0 -> tr("تعذّر فحص التخزين. ممكن المساحة الفاضية قليلة.", "Could not check storage. Free space may be too low.")
                badChunks > 0 -> tr(
                    "التخزين فيه عطل ✗\n$badChunks من $chunks قطعة رجعت بيانات تالفة.\nهذا يسبب تهنيج وملفات خربانة.\n\n$speeds",
                    "Storage is faulty ✗\n$badChunks of $chunks blocks returned corrupted data.\nThis causes lag and broken files.\n\n$speeds"
                )
                ok -> tr("التخزين سليم ✓\nالبيانات كلها رجعت صحيحة.\n$speeds", "Storage OK ✓\nAll data read back correctly.\n$speeds")
                else -> tr(
                    "التخزين بطيء جداً ✗\n$speeds\n\nممكن تكون الذاكرة متهالكة أو ممتلئة.",
                    "Storage is very slow ✗\n$speeds\n\nThe storage may be worn or nearly full."
                )
            }
            PcDialog(this)
                .setTitle(Test.STORAGE.title)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton(tr("تمام", "OK")) { _, _ ->
                    if (write < 0) {
                        skip()
                    } else {
                        Results.details[Test.STORAGE] = tr("كتابة $write / قراءة $read MB/s", "W $write / R $read MB/s") +
                            if (badChunks > 0) tr(" · بيانات تالفة", " · corrupted data") else tr(" · البيانات سليمة", " · data intact")
                        Results.storageCorrupt = badChunks > 0
                        record(Test.STORAGE, ok)
                    }
                }
                .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> testStorage() }
                .show()
        }
    }.start()
}
