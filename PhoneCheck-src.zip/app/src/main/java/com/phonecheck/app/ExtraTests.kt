package com.phonecheck.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telephony.TelephonyManager
import androidx.appcompat.app.AlertDialog
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import kotlin.math.abs
import kotlin.math.sqrt

private val mainHandler = Handler(Looper.getMainLooper())

/** حوار عام: المستخدم يجهّز الشي ثم يضغط "تحقّق". check يرجع نص النجاح أو null */
internal fun MainActivity.checkDialog(t: Test, instruction: String, retry: Boolean = false, check: () -> String?) {
    val msg = if (retry) "ما زال الاختبار ما نجح.\n\n$instruction" else instruction
    AlertDialog.Builder(this)
        .setTitle(t.title)
        .setMessage(msg)
        .setCancelable(false)
        .setPositiveButton("تحقّق") { _, _ ->
            val ok = try {
                check()
            } catch (e: Exception) {
                null
            }
            if (ok != null) {
                toast(ok)
                record(t, true)
            } else {
                checkDialog(t, instruction, true, check)
            }
        }
        .setNegativeButton("لا يعمل") { _, _ -> record(t, false) }
        .setNeutralButton("تخطّي") { _, _ -> skip() }
        .show()
}

// ---------------- منفذ الشحن ----------------
internal fun MainActivity.testCharging() {
    val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    var active = true
    var plugTime = 0L
    var charging = false
    var plugName = ""
    val samples = mutableListOf<Int>()
    val startT = SystemClock.elapsedRealtime()
    lateinit var dlg: AlertDialog

    fun currentMa(): Int? {
        val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (v == Int.MIN_VALUE || v == 0) return null
        val a = abs(v)
        return if (a > 20000) a / 1000 else a // بعض الأجهزة ترجع µA وبعضها mA
    }

    fun finishTest() {
        active = false
        dlg.dismiss()
        val avg = if (samples.isEmpty()) null else samples.sum() / samples.size
        val ok = plugTime > 0 && charging
        val msg = when {
            plugTime == 0L -> "ما انكشف أي شاحن.\nتأكد من الكيبل والشاحن، أو المنفذ فيه مشكلة."
            !charging -> "الشاحن موصول لكن الجوال ما يشحن ✗\nممكن المشكلة في المنفذ أو الكيبل."
            avg != null -> "الشحن شغّال ✓ ($plugName)\nسرعة الشحن التقريبية: $avg mA\n\nالسرعة تعتمد كمان على الشاحن والكيبل ونسبة البطارية."
            else -> "الشحن شغّال ✓ ($plugName)\nقياس سرعة الشحن غير متاح في هذا الجهاز."
        }
        AlertDialog.Builder(this)
            .setTitle(Test.CHARGING.title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("تمام") { _, _ -> record(Test.CHARGING, ok) }
            .setNeutralButton("إعادة") { _, _ -> testCharging() }
            .show()
    }

    dlg = AlertDialog.Builder(this)
        .setTitle(Test.CHARGING.title)
        .setMessage("وصّل الشاحن الآن…\n(إذا كان موصول، افصله ووصّله من جديد)")
        .setCancelable(false)
        .setNegativeButton("إيقاف") { _, _ ->
            active = false
            finishTest()
        }
        .show()

    val tick = object : Runnable {
        override fun run() {
            if (!active) return
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val plug = bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
            val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val now = SystemClock.elapsedRealtime()
            if (plug != 0) {
                if (plugTime == 0L) plugTime = now
                plugName = when (plug) {
                    BatteryManager.BATTERY_PLUGGED_AC -> "شاحن جداري"
                    BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "لاسلكي"
                    else -> "شاحن"
                }
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                // نتجاهل أول ثانيتين لين يستقر التيار
                if (now - plugTime > 2000) currentMa()?.let { samples += it }
                dlg.setMessage("✓ الشاحن موصول ($plugName)\nجاري قياس سرعة الشحن…")
                if (now - plugTime > 8000) {
                    finishTest()
                    return
                }
            } else if (plugTime > 0) {
                // انفصل أثناء القياس
                plugTime = 0L
                samples.clear()
                dlg.setMessage("انفصل الشاحن! وصّله مرة ثانية وخلّه ثابت…")
            }
            if (now - startT > 60000) {
                finishTest()
                return
            }
            mainHandler.postDelayed(this, 700)
        }
    }
    mainHandler.postDelayed(tick, 700)
}

// ---------------- سماعة المكالمات ----------------
internal fun MainActivity.testEarpiece() {
    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val prevMode = am.mode
    val prevVol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
    try {
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            am.availableCommunicationDevices
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
                ?.let { am.setCommunicationDevice(it) }
        } else {
            am.isSpeakerphoneOn = false
        }
        am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
    } catch (e: Exception) {
        // نكمل حتى لو ما قدرنا نغيّر الإعدادات
    }
    val tg = try {
        ToneGenerator(AudioManager.STREAM_VOICE_CALL, 100)
    } catch (e: Exception) {
        null
    }
    tg?.startTone(ToneGenerator.TONE_SUP_DIAL)
    ask(Test.EARPIECE, "قرّب أعلى الجوال من أذنك كأنك في مكالمة.\nهل تسمع نغمة واضحة؟") {
        tg?.stopTone()
        tg?.release()
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
            am.mode = prevMode
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, prevVol, 0)
        } catch (e: Exception) {
            // تجاهل
        }
    }
}

// ---------------- حساس القرب ----------------
internal fun MainActivity.testProximity() {
    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val s = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    if (s == null) {
        toast("الجهاز ما فيه حساس قرب")
        skip()
        return
    }
    var near = false
    var far = false
    lateinit var dlg: AlertDialog
    fun msg() = "غطّي أعلى الشاشة (جنب الكاميرا الأمامية) بيدك، ثم ارفعها.\n\n" +
        "تغطية: ${if (near) "✓" else "…"}\nرفع: ${if (far) "✓" else "…"}"

    val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val v = e.values[0]
            if (v < s.maximumRange) near = true else if (near) far = true
            dlg.setMessage(msg())
            if (near && far) {
                sm.unregisterListener(this)
                dlg.dismiss()
                record(Test.PROXIMITY, true)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    dlg = AlertDialog.Builder(this)
        .setTitle(Test.PROXIMITY.title)
        .setMessage(msg())
        .setCancelable(false)
        .setNegativeButton("ما يستجيب") { _, _ ->
            sm.unregisterListener(listener)
            record(Test.PROXIMITY, false)
        }
        .setNeutralButton("تخطّي") { _, _ ->
            sm.unregisterListener(listener)
            skip()
        }
        .show()
    sm.registerListener(listener, s, SensorManager.SENSOR_DELAY_NORMAL)
}

// ---------------- حساسات الحركة ----------------
internal fun MainActivity.testMotion() {
    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    if (acc == null && gyro == null) {
        toast("الجهاز ما فيه حساسات حركة")
        record(Test.MOTION, false)
        return
    }
    var accOk = false
    var gyroOk = false
    var minA = Float.MAX_VALUE
    var maxA = 0f
    var finished = false
    lateinit var dlg: AlertDialog

    fun line(name: String, exists: Boolean, ok: Boolean) =
        "$name: " + when {
            !exists -> "غير موجود"
            ok -> "✓"
            else -> "…"
        }

    fun msg() = "حرّك الجوال بقوة وقلّبه في يدك.\n\n" +
        line("حساس التسارع", acc != null, accOk) + "\n" +
        line("الجيروسكوب", gyro != null, gyroOk)

    val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (finished) return
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            val m = sqrt(x * x + y * y + z * z)
            when (e.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    if (m < minA) minA = m
                    if (m > maxA) maxA = m
                    if (maxA - minA > 6f) accOk = true
                }
                Sensor.TYPE_GYROSCOPE -> if (m > 2f) gyroOk = true
            }
            dlg.setMessage(msg())
            if ((acc == null || accOk) && (gyro == null || gyroOk)) {
                finished = true
                sm.unregisterListener(this)
                dlg.dismiss()
                record(Test.MOTION, true)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    dlg = AlertDialog.Builder(this)
        .setTitle(Test.MOTION.title)
        .setMessage(msg())
        .setCancelable(false)
        .setNegativeButton("ما يستجيب") { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            record(Test.MOTION, false)
        }
        .setNeutralButton("تخطّي") { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            skip()
        }
        .show()
    acc?.let { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME) }
    gyro?.let { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME) }
}

// ---------------- البصمة ----------------
internal fun MainActivity.testFingerprint() {
    val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK
    when (BiometricManager.from(this).canAuthenticate(auth)) {
        BiometricManager.BIOMETRIC_SUCCESS -> Unit
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
            toast("الجهاز ما فيه بصمة")
            skip()
            return
        }
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
            AlertDialog.Builder(this)
                .setTitle(Test.FINGERPRINT.title)
                .setMessage("ما فيه بصمة مسجّلة في الجهاز.\nسجّل بصمة من الإعدادات ← الأمان، ثم أعد الاختبار.")
                .setCancelable(false)
                .setPositiveButton("تمام") { _, _ -> skip() }
                .show()
            return
        }
        else -> {
            toast("حساس البصمة غير متاح حالياً")
            record(Test.FINGERPRINT, false)
            return
        }
    }

    val prompt = BiometricPrompt(
        this,
        ContextCompat.getMainExecutor(this),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                toast("البصمة تشتغل ✓")
                record(Test.FINGERPRINT, true)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                AlertDialog.Builder(this@testFingerprint)
                    .setTitle(Test.FINGERPRINT.title)
                    .setMessage("ما تمت قراءة البصمة ($errString).\nهل الحساس ما يقرأ إصبعك؟")
                    .setCancelable(false)
                    .setPositiveButton("ما يشتغل") { _, _ -> record(Test.FINGERPRINT, false) }
                    .setNegativeButton("تخطّي") { _, _ -> skip() }
                    .setNeutralButton("إعادة") { _, _ -> testFingerprint() }
                    .show()
            }
        }
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("اختبار البصمة")
        .setSubtitle("ضع إصبعك المسجّل على حساس البصمة")
        .setNegativeButtonText("إلغاء")
        .setAllowedAuthenticators(auth)
        .build()
    prompt.authenticate(info)
}

// ---------------- الواي فاي ----------------
internal fun MainActivity.testWifi() {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    checkDialog(Test.WIFI, "شغّل الواي فاي واتصل بأي شبكة، ثم اضغط تحقّق.") {
        @Suppress("DEPRECATION")
        val connected = cm.allNetworks.any {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
        if (connected) "الواي فاي متصل ✓" else null
    }
}

// ---------------- البلوتوث ----------------
@SuppressLint("MissingPermission")
internal fun MainActivity.testBluetooth() {
    val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    if (adapter == null) {
        toast("الجهاز ما فيه بلوتوث")
        skip()
        return
    }
    checkDialog(Test.BLUETOOTH, "شغّل البلوتوث من الإعدادات السريعة، ثم اضغط تحقّق.") {
        if (adapter.isEnabled) "البلوتوث اشتغل ✓" else null
    }
}

// ---------------- الشريحة والإشارة ----------------
internal fun MainActivity.testSignal() {
    if (!packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) {
        toast("الجهاز ما يدعم الشرائح")
        skip()
        return
    }
    val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    checkDialog(Test.SIGNAL, "تأكد إن فيه شريحة مركّبة ووضع الطيران مقفل، ثم اضغط تحقّق.") {
        if (tm.simState != TelephonyManager.SIM_STATE_READY) {
            null
        } else {
            val level = if (Build.VERSION.SDK_INT >= 28) tm.signalStrength?.level ?: 0 else 2
            val op = tm.networkOperatorName?.takeIf { it.isNotBlank() } ?: "غير معروف"
            if (level >= 1) "الشريحة شغّالة ✓ — $op — الإشارة $level/4" else null
        }
    }
}

// ---------------- الـ GPS ----------------
@SuppressLint("MissingPermission")
internal fun MainActivity.runGps() {
    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    if (!lm.allProviders.contains(LocationManager.GPS_PROVIDER)) {
        toast("الجهاز ما فيه GPS")
        record(Test.GPS, false)
        return
    }
    if (!LocationManagerCompat.isLocationEnabled(lm)) {
        AlertDialog.Builder(this)
            .setTitle(Test.GPS.title)
            .setMessage("شغّل الموقع (GPS) من الإعدادات السريعة، ثم اضغط إعادة.")
            .setCancelable(false)
            .setPositiveButton("إعادة") { _, _ -> runGps() }
            .setNegativeButton("تخطّي") { _, _ -> skip() }
            .show()
        return
    }

    var sats = 0
    var best = 0
    var fix = false
    var active = true
    val startT = SystemClock.elapsedRealtime()
    lateinit var dlg: AlertDialog

    val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            fix = true
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }
    val callback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var n = 0
            for (i in 0 until status.satelliteCount) if (status.getCn0DbHz(i) > 0f) n++
            sats = n
            if (n > best) best = n
        }
    }

    fun stop() {
        active = false
        try {
            lm.removeUpdates(listener)
            lm.unregisterGnssStatusCallback(callback)
        } catch (e: Exception) {
            // تجاهل
        }
    }

    dlg = AlertDialog.Builder(this)
        .setTitle(Test.GPS.title)
        .setMessage("جاري البحث عن الأقمار الصناعية…\nالأفضل تكون قرب نافذة أو برّا.")
        .setCancelable(false)
        .setNegativeButton("إيقاف") { _, _ ->
            stop()
            gpsResult(best, fix)
        }
        .show()

    try {
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
        lm.registerGnssStatusCallback(callback, mainHandler)
    } catch (e: Exception) {
        stop()
        dlg.dismiss()
        toast("تعذّر تشغيل الـ GPS")
        record(Test.GPS, false)
        return
    }

    val tick = object : Runnable {
        override fun run() {
            if (!active) return
            dlg.setMessage("جاري البحث عن الأقمار الصناعية…\nالأقمار المرصودة الآن: $sats\n\nالأفضل تكون قرب نافذة أو برّا.")
            if (best >= 4 || fix || SystemClock.elapsedRealtime() - startT > 45000) {
                stop()
                dlg.dismiss()
                gpsResult(best, fix)
                return
            }
            mainHandler.postDelayed(this, 1000)
        }
    }
    mainHandler.postDelayed(tick, 1000)
}

private fun MainActivity.gpsResult(best: Int, fix: Boolean) {
    val ok = best >= 4 || fix
    val msg = if (ok) "الـ GPS شغّال ✓\nأعلى عدد أقمار مرصودة: $best"
    else "ما قدرنا نلتقط إشارة كافية (الأقمار: $best).\nجرّب قرب نافذة أو برّا، ثم أعد الاختبار."
    AlertDialog.Builder(this)
        .setTitle(Test.GPS.title)
        .setMessage(msg)
        .setCancelable(false)
        .setPositiveButton("تمام") { _, _ -> record(Test.GPS, ok) }
        .setNeutralButton("إعادة") { _, _ -> runGps() }
        .show()
}
