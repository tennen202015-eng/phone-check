package com.phonecheck.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.view.View
import android.view.animation.DecelerateInterpolator

/** خط IBM Plex Sans Arabic (يتنزّل وقت البناء)، ولو مو موجود نرجع لخط النظام */
object Fonts {
    lateinit var regular: Typeface
    lateinit var medium: Typeface
    lateinit var bold: Typeface
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        regular = load(ctx, "plex_regular.ttf", 400)
        medium = load(ctx, "plex_semibold.ttf", 600)
        bold = load(ctx, "plex_bold.ttf", 700)
        ready = true
    }

    private fun load(ctx: Context, file: String, weight: Int): Typeface = try {
        Typeface.createFromAsset(ctx.assets, "fonts/$file")
    } catch (e: Exception) {
        when {
            Build.VERSION.SDK_INT >= 28 -> Typeface.create(Typeface.DEFAULT, weight, false)
            weight >= 600 -> Typeface.DEFAULT_BOLD
            else -> Typeface.DEFAULT
        }
    }
}

/**
 * حلقة التقييم: قوس 270° مقسّم لقطعة لكل اختبار.
 * أخضر = سليم، مرجاني = فيه مشكلة، شفاف = لم يُختبر.
 * أول قطعة على اليمين (اتجاه القراءة العربي).
 */
class ScoreRing(ctx: Context) : View(ctx) {
    var segments: List<Boolean?> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    private var progress = 1f
    private val density = ctx.resources.displayMetrics.density
    private val stroke = 13f * density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        strokeCap = Paint.Cap.BUTT
    }
    private val rect = RectF()

    fun animateIn() {
        progress = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            startDelay = 150
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = stroke / 2 + 2 * density
        rect.set(pad, pad, width - pad, height - pad)
        val n = segments.size.coerceAtLeast(1)
        val gap = 3.2f
        val each = (270f - gap * (n - 1)) / n
        val shown = n * progress
        for (i in 0 until n) {
            // يبدأ من أسفل اليمين (45°) ويمشي عكس عقارب الساعة لين أسفل اليسار
            val start = 45f - i * (each + gap)
            val status = segments.getOrNull(i)
            paint.color = if (i < shown) {
                when (status) {
                    true -> RING_PASS
                    false -> RING_FAIL
                    null -> RING_EMPTY
                }
            } else {
                RING_EMPTY
            }
            canvas.drawArc(rect, start, -each, false, paint)
        }
    }
}

/** صف يلفّ عناصره لسطر جديد لما تخلص المساحة (للأزرار الصغيرة) — يحترم اتجاه اللغة */
class FlowRow(ctx: Context) : android.view.ViewGroup(ctx) {
    private val gap = (8 * ctx.resources.displayMetrics.density).toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val maxW = MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            c.measure(
                MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            )
            if (x > 0 && x + c.measuredWidth > maxW) {
                x = 0
                y += rowH + gap
                rowH = 0
            }
            x += c.measuredWidth + gap
            rowH = maxOf(rowH, c.measuredHeight)
        }
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), y + rowH + paddingTop + paddingBottom)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val width = r - l
        val maxW = width - paddingLeft - paddingRight
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        var x = 0
        var y = paddingTop
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val cw = c.measuredWidth
            val ch = c.measuredHeight
            if (x > 0 && x + cw > maxW) {
                x = 0
                y += rowH + gap
                rowH = 0
            }
            val left = if (rtl) width - paddingRight - x - cw else paddingLeft + x
            c.layout(left, y, left + cw, y + ch)
            x += cw + gap
            rowH = maxOf(rowH, ch)
        }
    }
}
