package com.phonecheck.app

import android.app.Activity
import android.os.BatteryManager
import android.os.Build
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.roundToInt

// لوحة الألوان: بترولي عميق للهوية، ضباب فاتح للخلفية، وأخضر/أحمر للحالة فقط
val PRIMARY: Int = 0xFF0D4450.toInt()      // بترولي
val PETROL: Int = PRIMARY
val GREEN: Int = 0xFF1E8E5E.toInt()        // نجح
val RED: Int = 0xFFC7432E.toInt()          // فشل
val GRAY: Int = 0xFF8A989B.toInt()         // لم يُختبر
val TEXT: Int = 0xFF14272C.toInt()         // حبر
val SLATE: Int = 0xFF5E7076.toInt()        // نص ثانوي
val BG: Int = 0xFFEDF1F0.toInt()           // ضباب
val LINE: Int = 0xFFE1E8E7.toInt()
val PASS_BG: Int = 0xFFE2F3EB.toInt()
val FAIL_BG: Int = 0xFFFBE7E3.toInt()
val LIGHT: Int = 0xFFB7D3D8.toInt()        // نص خافت فوق البترولي
val RING_PASS: Int = 0xFF5BE3A8.toInt()
val RING_FAIL: Int = 0xFFFF8A73.toInt()
val RING_EMPTY: Int = 0x2EFFFFFF

// ألوان هوية الشركة في التقرير (من الشعار)
val BRAND_DARK: Int = 0xFF0C0C0B.toInt()
val BRAND_GOLD: Int = 0xFFB08A4A.toInt()
val BRAND_GOLD_LIGHT: Int = 0xFFD9B87C.toInt()

/** الاختبارات ووزن كل واحد في التقييم */
enum class Test(private val ar: String, private val en: String, val weight: Int) {
    TOUCH("لمس الشاشة", "Touchscreen", 15),
    DISPLAY("ألوان الشاشة والبكسلات", "Display colors & pixels", 10),
    SPEAKER("السماعة الخارجية", "Loudspeaker", 10),
    EARPIECE("سماعة المكالمات", "Earpiece", 8),
    MIC("المايكروفون", "Microphone", 10),
    CAMERA("الكاميرا الخلفية", "Rear camera", 10),
    FRONT_CAMERA("الكاميرا الأمامية", "Front camera", 7),
    FLASH("الفلاش", "Flash", 5),
    CHARGING("منفذ الشحن", "Charging port", 10),
    STORAGE("سرعة التخزين", "Storage speed", 6),
    FINGERPRINT("البصمة", "Fingerprint", 6),
    PROXIMITY("حساس القرب", "Proximity sensor", 4),
    MOTION("حساسات الحركة", "Motion sensors", 4),
    VIBRATION("الاهتزاز", "Vibration", 5),
    BUTTONS("أزرار الصوت", "Volume buttons", 5),
    WIFI("الواي فاي", "Wi-Fi", 5),
    BLUETOOTH("البلوتوث", "Bluetooth", 4),
    GPS("الـ GPS", "GPS", 4),
    SIGNAL("الشريحة والإشارة", "SIM & signal", 6);

    val title: String get() = tr(ar, en)
}

/** مجموعة اختبارات حسب جزء الجوال */
class TestGroup(private val ar: String, private val en: String, val tests: List<Test>) {
    val name: String get() = tr(ar, en)
}

val TEST_GROUPS: List<TestGroup> = listOf(
    TestGroup("الشاشة", "Display", listOf(Test.TOUCH, Test.DISPLAY)),
    TestGroup("الصوت", "Audio", listOf(Test.SPEAKER, Test.EARPIECE, Test.MIC)),
    TestGroup("الكاميرا", "Camera", listOf(Test.CAMERA, Test.FRONT_CAMERA, Test.FLASH)),
    TestGroup("الطاقة والأداء", "Power & performance", listOf(Test.CHARGING, Test.STORAGE)),
    TestGroup(
        "الحساسات والأزرار", "Sensors & buttons",
        listOf(Test.FINGERPRINT, Test.PROXIMITY, Test.MOTION, Test.VIBRATION, Test.BUTTONS)
    ),
    TestGroup("الاتصال", "Connectivity", listOf(Test.WIFI, Test.BLUETOOTH, Test.GPS, Test.SIGNAL)),
)

/** رابط صفحة الفحص عن بُعد (GitHub Pages) */
const val WEB_URL = "https://tennen202015-eng.github.io/phone-check-web/"

/** رابط سياسة الخصوصية */
const val PRIVACY_URL = "https://tennen202015-eng.github.io/phone-check-web/privacy.html"

/** الاختبارات اللي تشتغل في المتصفح، ورمز كل واحد في نتيجة الصفحة */
val REMOTE_KEYS: List<Pair<String, Test>> = listOf(
    "t" to Test.TOUCH,
    "d" to Test.DISPLAY,
    "sp" to Test.SPEAKER,
    "mi" to Test.MIC,
    "c" to Test.CAMERA,
    "fc" to Test.FRONT_CAMERA,
    "fl" to Test.FLASH,
    "v" to Test.VIBRATION,
    "mo" to Test.MOTION,
    "ch" to Test.CHARGING,
    "g" to Test.GPS,
)
val REMOTE_TESTS: List<Test> = REMOTE_KEYS.map { it.second }

/** حالة الجوال الخارجية (يحددها الفاحص بعينه) */
enum class Cond(private val ar: String, private val en: String) {
    EXCELLENT("ممتازة", "Excellent"),
    LIGHT("خدوش خفيفة", "Light scratches"),
    VISIBLE("خدوش واضحة", "Visible scratches"),
    BROKEN("كسر أو تلف", "Cracked / damaged");

    val label: String get() = tr(ar, en)
}

object Results {
    val map: MutableMap<Test, Boolean> = linkedMapOf()

    /** تفاصيل إضافية لبعض الاختبارات، مثل سرعة الشحن وسرعة التخزين */
    val details: MutableMap<Test, String> = mutableMapOf()

    var body: Cond? = null
    var screen: Cond? = null
    var notes: String = ""

    fun clear() {
        map.clear()
        details.clear()
        body = null
        screen = null
        notes = ""
    }
}

data class ScoreResult(val percent: Int, val grade: String, val tested: Int, val total: Int)

object Scoring {
    private const val AUTO_POINTS = 30 // بطارية 20 + حساسات 5 + أمان 5

    fun batteryPoints(s: DeviceSnapshot): Int {
        var p = when (s.batteryHealthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> 20
            BatteryManager.BATTERY_HEALTH_OVERHEAT, BatteryManager.BATTERY_HEALTH_COLD -> 10
            BatteryManager.BATTERY_HEALTH_UNKNOWN -> 14
            else -> 0
        }
        s.batteryEstimatePct?.let { est ->
            val byEst = when {
                est >= 85 -> 20
                est >= 75 -> 15
                est >= 65 -> 10
                else -> 5
            }
            p = minOf(p, byEst)
        }
        s.cycleCount?.let { c ->
            if (c > 1000) p -= 6 else if (c > 600) p -= 3
        }
        if (s.batteryTempC > 45f) p -= 4
        return p.coerceIn(0, 20)
    }

    fun sensorPoints(s: DeviceSnapshot): Int =
        if (s.sensorsExpected == 0) 5 else (5.0 * s.sensorsFound / s.sensorsExpected).roundToInt()

    fun compute(s: DeviceSnapshot, r: Map<Test, Boolean>): ScoreResult {
        // الفحص عن بُعد ما فيه قراءات تلقائية للبطارية والروت، فالتقييم من الاختبارات فقط
        var earned = if (s.remote) 0 else batteryPoints(s) + sensorPoints(s) + (if (s.rooted) 0 else 5)
        var possible = if (s.remote) 0 else AUTO_POINTS
        for ((t, ok) in r) {
            possible += t.weight
            if (ok) earned += t.weight
        }
        val pct = if (possible == 0) 0 else (earned * 100.0 / possible).roundToInt().coerceIn(0, 100)
        val total = if (s.remote) REMOTE_TESTS.size else Test.values().size
        return ScoreResult(pct, grade(pct), r.size, total)
    }

    fun grade(p: Int): String = when {
        p >= 90 -> tr("ممتاز", "Excellent")
        p >= 75 -> tr("جيد جداً", "Very good")
        p >= 60 -> tr("جيد", "Good")
        p >= 40 -> tr("مقبول", "Fair")
        else -> tr("ضعيف", "Poor")
    }

    /** لون التقدير فوق الخلفية البترولية */
    fun ringGradeColor(p: Int): Int = when {
        p >= 75 -> RING_PASS
        p >= 50 -> 0xFFFFC56B.toInt()
        else -> RING_FAIL
    }

    fun gradeColor(p: Int): Int = when {
        p >= 75 -> GREEN
        p >= 50 -> 0xFFC98A1B.toInt()
        else -> RED
    }
}

/** ملء الشاشة كاملة لاختبارات الشاشة */
fun Activity.goFullscreen() {
    if (Build.VERSION.SDK_INT >= 28) {
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }
    WindowCompat.setDecorFitsSystemWindows(window, false)
    WindowCompat.getInsetsController(window, window.decorView).apply {
        hide(WindowInsetsCompat.Type.systemBars())
        systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}
