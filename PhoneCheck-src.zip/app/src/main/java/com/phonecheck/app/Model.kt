package com.phonecheck.app

import android.app.Activity
import android.os.BatteryManager
import android.os.Build
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.roundToInt

val PRIMARY: Int = 0xFF1565C0.toInt()
val GREEN: Int = 0xFF2E7D32.toInt()
val RED: Int = 0xFFC62828.toInt()
val GRAY: Int = 0xFF757575.toInt()
val TEXT: Int = 0xFF212121.toInt()
val BG: Int = 0xFFF4F6FA.toInt()
val LIGHT: Int = 0xFFE3F2FD.toInt()

/** الاختبارات اليدوية ووزن كل واحد في التقييم */
enum class Test(val title: String, val weight: Int) {
    TOUCH("لمس الشاشة", 15),
    DISPLAY("ألوان الشاشة والبكسلات", 10),
    SPEAKER("السماعة", 10),
    MIC("المايكروفون", 10),
    CAMERA("الكاميرا الخلفية", 10),
    FLASH("الفلاش", 5),
    VIBRATION("الاهتزاز", 5),
    BUTTONS("أزرار الصوت", 5);
}

object Results {
    val map: MutableMap<Test, Boolean> = linkedMapOf()
}

data class ScoreResult(val percent: Int, val grade: String, val tested: Int, val total: Int)

object Scoring {
    private const val AUTO_POINTS = 30 // بطارية 20 + حساسات 5 + أمان 5

    fun batteryPoints(s: DeviceSnapshot): Int {
        var p = when (s.batteryHealthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> 20
            BatteryManager.BATTERY_HEALTH_OVERHEAT, BatteryManager.BATTERY_HEALTH_COLD -> 10
            BatteryManager.BATTERY_HEALTH_UNKNOWN -> 14
            else -> 0
        }
        s.batteryEstimatePct?.let { est ->
            val byEst = when {
                est >= 85 -> 20
                est >= 75 -> 15
                est >= 65 -> 10
                else -> 5
            }
            p = minOf(p, byEst)
        }
        s.cycleCount?.let { c ->
            if (c > 1000) p -= 6 else if (c > 600) p -= 3
        }
        if (s.batteryTempC > 45f) p -= 4
        return p.coerceIn(0, 20)
    }

    fun sensorPoints(s: DeviceSnapshot): Int =
        if (s.sensorsExpected == 0) 5 else (5.0 * s.sensorsFound / s.sensorsExpected).roundToInt()

    fun compute(s: DeviceSnapshot, r: Map<Test, Boolean>): ScoreResult {
        var earned = batteryPoints(s) + sensorPoints(s) + (if (s.rooted) 0 else 5)
        var possible = AUTO_POINTS
        for ((t, ok) in r) {
            possible += t.weight
            if (ok) earned += t.weight
        }
        val pct = (earned * 100.0 / possible).roundToInt().coerceIn(0, 100)
        return ScoreResult(pct, grade(pct), r.size, Test.values().size)
    }

    fun grade(p: Int): String = when {
        p >= 90 -> "ممتاز"
        p >= 75 -> "جيد جداً"
        p >= 60 -> "جيد"
        p >= 40 -> "مقبول"
        else -> "ضعيف"
    }

    fun gradeColor(p: Int): Int = when {
        p >= 75 -> GREEN
        p >= 50 -> 0xFFEF6C00.toInt()
        else -> RED
    }
}

/** ملء الشاشة كاملة لاختبارات الشاشة */
fun Activity.goFullscreen() {
    if (Build.VERSION.SDK_INT >= 28) {
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }
    WindowCompat.setDecorFitsSystemWindows(window, false)
    WindowCompat.getInsetsController(window, window.decorView).apply {
        hide(WindowInsetsCompat.Type.systemBars())
        systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}
