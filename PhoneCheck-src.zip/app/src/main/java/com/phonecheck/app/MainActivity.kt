package com.phonecheck.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView
import java.io.File

/**
 * الشاشة الرئيسية: هنا بس دورة حياة الشاشة وتسلسل الاختبارات.
 * الواجهات في Screens.kt، والعناصر المشتركة في Widgets.kt، والاختبارات في CoreTests.kt و ExtraTests.kt و HardwareTests.kt و SecurityTests.kt.
 */
class MainActivity : AppCompatActivity() {

    internal lateinit var root: LinearLayout
    internal var snapshot: DeviceSnapshot? = null
    internal val queue = ArrayDeque<Test>()

    /** الطابور الحالي من الفحص السريع (يقصّر اختبار المعالج) */
    internal var runQuick = false

    // ---------- نتائج الشاشات والأذونات ----------
    private fun screenLauncher(t: Test) =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(t, true)
                RESULT_FIRST_USER -> record(t, false)
                RESULT_UNDETERMINED -> skip()
                else -> stopRun()
            }
        }

    private val touchLauncher = screenLauncher(Test.TOUCH)
    private val colorLauncher = screenLauncher(Test.DISPLAY)
    private val burnInLauncher = screenLauncher(Test.BURN_IN)
    private val batteryLauncher = screenLauncher(Test.BATTERY)
    private val perfLauncher = screenLauncher(Test.CPU)
    private val multiTouchLauncher = screenLauncher(Test.MULTITOUCH)

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.CAMERA) else showPhoto(Test.CAMERA, bmp)
        }

    private val frontLauncher =
        registerForActivityResult(FrontPicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.FRONT_CAMERA) else showPhoto(Test.FRONT_CAMERA, bmp)
        }

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) runGps() else {
                toast(tr("لازم تسمح بالموقع الدقيق عشان نختبر الـ GPS", "Allow precise location to test GPS"))
                skip()
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) runMicTest() else {
                toast(tr("لازم تسمح باستخدام المايك عشان نختبره", "Allow microphone access to test it"))
                skip()
            }
        }

    private var pendingCamera: Test? = null

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val t = pendingCamera ?: return@registerForActivityResult
            pendingCamera = null
            if (granted) launchCamera(t) else {
                toast(tr("لازم تسمح بالكاميرا عشان نختبرها", "Allow camera access to test it"))
                skip()
            }
        }

    // ---------- الشاشات ----------
    internal enum class Tab { HOME, TESTS, REPORT, DEVICE, MORE }

    internal var tab = Tab.HOME
    internal lateinit var scroll: ScrollView
    internal lateinit var nav: BottomNavigationView

    /** تنظيف الاختبار الشغّال (حساسات، مؤقتات…) لو انوقف الفحص */
    internal var cleanup: (() -> Unit)? = null
    private var pendingStart: Runnable? = null
    private var usageLoading = false

    // حالة الواجهة
    internal val expanded = mutableSetOf<String>()
    internal var ringAnimated = false
    internal val orderedTests: List<Test> by lazy { TEST_GROUPS.flatMap { it.tests } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        tab = Tab.values()[savedInstanceState?.getInt("tab", 0) ?: 0]
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        }
        nav = BottomNavigationView(this).apply {
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
            labelVisibilityMode = NavigationBarView.LABEL_VISIBILITY_LABELED
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            val colors = ColorStateList(states, intArrayOf(PETROL, GRAY))
            itemIconTintList = colors
            itemTextColor = colors
            menu.add(0, Tab.HOME.ordinal, 0, tr("الرئيسية", "Home")).setIcon(R.drawable.ic_tab_home)
            menu.add(0, Tab.TESTS.ordinal, 1, tr("الاختبارات", "Tests")).setIcon(R.drawable.ic_tab_tests)
            menu.add(0, Tab.REPORT.ordinal, 2, tr("التقرير", "Report")).setIcon(R.drawable.ic_tab_report)
            menu.add(0, Tab.DEVICE.ordinal, 3, tr("الجهاز", "Device")).setIcon(R.drawable.ic_tab_device)
            menu.add(0, Tab.MORE.ordinal, 4, tr("المزيد", "More")).setIcon(R.drawable.ic_tab_more)
            selectedItemId = tab.ordinal
            setOnItemSelectedListener { item ->
                tab = Tab.values()[item.itemId]
                scroll.scrollTo(0, 0)
                render()
                true
            }
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = Lang.dir
        }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(page)
        window.statusBarColor = PRIMARY
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab.ordinal)
    }

    override fun onResume() {
        super.onResume()
        RunControl.onStop = { stopRun() }
        snapshot = try {
            DeviceInfo.collect(this)
        } catch (e: Exception) {
            null
        }
        render()
        refreshUsage()
    }

    override fun onPause() {
        RunControl.onStop = null
        super.onPause()
    }

    internal fun goTab(t: Tab) {
        tab = t
        nav.selectedItemId = t.ordinal
    }

    internal fun render() {
        root.removeAllViews()
        when (tab) {
            Tab.HOME -> homeTab()
            Tab.TESTS -> testsTab()
            Tab.REPORT -> reportTab()
            Tab.DEVICE -> deviceTab()
            Tab.MORE -> moreTab()
        }
    }

    private fun refreshUsage() {
        if (usageLoading || !UsageAnalyzer.hasAccess(this)) return
        usageLoading = true
        Thread {
            val u = try {
                UsageAnalyzer.analyze(this)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                usageLoading = false
                Results.usage = u
                if (!isFinishing) render()
            }
        }.start()
    }

    // ---------- تسلسل الاختبارات ----------
    /** يبدأ (أو يكمّل) فحص سريع أو كامل */
    internal fun runMode(m: Mode) {
        if (m.tests.all { it in Results.map }) Results.clearTests()
        Results.mode = m
        runQuick = m == Mode.QUICK
        queue.clear()
        queue.addAll(m.tests.filter { it !in Results.map })
        render()
        next()
    }

    internal fun running(): Boolean = queue.isNotEmpty() || cleanup != null

    /** إيقاف الفحص: يوقف الاختبار الحالي ويفضّي الطابور ويرجع للرئيسية */
    internal fun stopRun() {
        pendingStart?.let { root.removeCallbacks(it) }
        pendingStart = null
        queue.clear()
        cleanup?.invoke()
        cleanup = null
        RunControl.current?.dismiss()
        if (::nav.isInitialized && tab != Tab.HOME) goTab(Tab.HOME) else render()
        toast(tr("تم إيقاف الفحص", "Inspection stopped"))
    }

    internal fun record(t: Test, ok: Boolean) {
        cleanup = null
        Results.map[t] = ok
        render()
        next()
    }

    internal fun skip() {
        cleanup = null
        render()
        next()
    }

    private fun next() {
        val t = queue.removeFirstOrNull() ?: return
        val r = Runnable {
            pendingStart = null
            if (!isFinishing) start(t)
        }
        pendingStart = r
        root.postDelayed(r, 400)
    }

    /** تشغيل اختبار واحد (مو الفحص الكامل) */
    internal fun startSingle(t: Test) {
        queue.clear()
        runQuick = false
        start(t)
    }

    /** الرام ثم التخزين ورا بعض */
    internal fun checkMemory() {
        queue.clear()
        runQuick = false
        queue.add(Test.STORAGE)
        start(Test.RAM)
    }

    internal fun start(t: Test) {
        when (t) {
            Test.TOUCH -> touchLauncher.launch(Intent(this, TouchTestActivity::class.java))
            Test.MULTITOUCH -> multiTouchLauncher.launch(Intent(this, MultiTouchActivity::class.java))
            Test.DISPLAY -> colorLauncher.launch(Intent(this, ColorTestActivity::class.java))
            Test.BURN_IN -> burnInLauncher.launch(Intent(this, BurnInActivity::class.java))
            Test.SPEAKER -> testSpeaker()
            Test.MIC -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runMicTest() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
            Test.CAMERA -> launchCamera(Test.CAMERA)
            Test.FRONT_CAMERA -> {
                if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)) {
                    toast(tr("الجهاز ما فيه كاميرا أمامية", "This device has no front camera"))
                    skip()
                } else {
                    PcDialog(this)
                        .setTitle(Test.FRONT_CAMERA.title)
                        .setMessage(tr("بتفتح الكاميرا الآن. صوّر سيلفي بالكاميرا الأمامية.\nإذا فتحت الخلفية، بدّل للأمامية من تطبيق الكاميرا.", "The camera will open now. Take a selfie with the front camera.\nIf the rear camera opens, switch to the front one in the camera app."))
                        .setCancelable(false)
                        .setPositiveButton(tr("فتح الكاميرا", "Open camera")) { _, _ -> launchCamera(Test.FRONT_CAMERA) }
                        .show()
                }
            }
            Test.FLASH -> testFlash()
            Test.VIBRATION -> testVibration()
            Test.BUTTONS -> testButtons()
            Test.EARPIECE -> testEarpiece()
            Test.CHARGING -> testCharging()
            Test.STORAGE -> testStorage()
            Test.RAM -> testRam()
            Test.CPU -> perfLauncher.launch(Intent(this, PerfTestActivity::class.java).putExtra("quick", runQuick))
            Test.BATTERY -> batteryLauncher.launch(Intent(this, BatteryTestActivity::class.java))
            Test.FINGERPRINT -> testFingerprint()
            Test.PROXIMITY -> testProximity()
            Test.MOTION -> testMotion()
            Test.LIGHT -> testLight()
            Test.COMPASS -> testCompass()
            Test.WIFI -> testWifi()
            Test.BLUETOOTH -> testBluetooth()
            Test.SIGNAL -> testSignal()
            Test.ACCOUNTS -> testAccounts()
            Test.GPS -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runGps() else locationPermission.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }
        }
    }

    // ---------- الكاميرا ----------
    internal fun launchCamera(t: Test) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingCamera = t
            cameraPermission.launch(Manifest.permission.CAMERA)
            return
        }
        try {
            if (t == Test.FRONT_CAMERA) frontLauncher.launch(null) else cameraLauncher.launch(null)
        } catch (e: ActivityNotFoundException) {
            toast(tr("ما لقينا تطبيق كاميرا في الجهاز", "No camera app found"))
            record(t, false)
        } catch (e: SecurityException) {
            toast(tr("لازم تسمح بالكاميرا عشان نختبرها", "Allow camera access to test it"))
            skip()
        }
    }

    // ---------- التقرير ----------
    // نعيد استخدام نفس التقرير لو ما تغيّر شي، عشان العرض ثم المشاركة ما يسوّون تقريرين في السجل
    internal var lastReport: Pair<String, File>? = null

    private fun reportKey(): String =
        listOf(
            Results.map, Results.details, Results.body, Results.screen, Results.notes, Results.battery,
            Results.usage, Results.usageInReport, Results.perf, Results.ram, Results.imei, Results.mode,
            Results.networkLocked, Lang.en
        ).toString()

    internal fun openReport(share: Boolean) {
        val snap = snapshot ?: return
        val imei = Results.imei.takeIf { ReportTrust.validImei(it) } ?: ""
        if (imei.isBlank()) {
            toast(tr("نصيحة: اكتب رقم IMEI في صفحة التقرير عشان التقرير يرتبط بهذا الجوال", "Tip: enter the IMEI on the Report page to tie the report to this phone"))
        }
        val key = reportKey()
        val cached = lastReport?.takeIf { it.first == key && it.second.exists() }?.second
        val file = cached ?: try {
            ReportPdf.create(
                this, snap, Scoring.compute(snap, Results.map), Results.map,
                extras = ReportExtras(
                    details = Results.details.toMap(),
                    body = Results.body,
                    screen = Results.screen,
                    notes = Results.notes,
                    battery = Results.battery,
                    usage = if (Results.usageInReport) Results.usage else null,
                    flags = RedFlags.compute(snap),
                    perf = Results.perf,
                    ram = Results.ram,
                    imei = imei,
                    mode = Results.reportMode,
                    sign = true,
                )
            ).also { lastReport = key to it }
        } catch (e: Exception) {
            toast(tr("تعذّر إنشاء التقرير: ", "Could not create the report: ") + e.message)
            return
        }
        openPdf(file, share)
    }

    internal fun switchLanguage() {
        Lang.set(this, !Lang.en)
        lastReport = null
        recreate()
    }

    internal fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

/** يطلب من تطبيق الكاميرا يفتح الأمامية (تدعمه أغلب تطبيقات الكاميرا) */
class FrontPicturePreview : ActivityResultContracts.TakePicturePreview() {
    override fun createIntent(context: Context, input: Void?): Intent =
        super.createIntent(context, input).apply {
            putExtra("android.intent.extras.CAMERA_FACING", 1)
            putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
            putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        }
}
