package com.phonecheck.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var snapshot: DeviceSnapshot? = null
    private val queue = ArrayDeque<Test>()

    // ---------- نتائج الشاشات والأذونات ----------
    private val touchLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            record(Test.TOUCH, it.resultCode == RESULT_OK)
        }

    private val colorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.DISPLAY, true)
                RESULT_FIRST_USER -> record(Test.DISPLAY, false)
                else -> skip()
            }
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.CAMERA) else showPhoto(Test.CAMERA, bmp)
        }

    private val frontLauncher =
        registerForActivityResult(FrontPicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.FRONT_CAMERA) else showPhoto(Test.FRONT_CAMERA, bmp)
        }

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) runGps() else {
                toast("لازم تسمح بالموقع الدقيق عشان نختبر الـ GPS")
                skip()
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) runMicTest() else {
                toast("لازم تسمح باستخدام المايك عشان نختبره")
                skip()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(BG)
            addView(root)
        }
        setContentView(scroll)
        window.statusBarColor = PRIMARY
    }

    override fun onResume() {
        super.onResume()
        snapshot = try {
            DeviceInfo.collect(this)
        } catch (e: Exception) {
            null
        }
        render()
    }

    // ---------- تسلسل الاختبارات ----------
    private fun runAll() {
        if (Results.map.size == Test.values().size) Results.map.clear()
        queue.clear()
        queue.addAll(Test.values().filter { it !in Results.map })
        render()
        next()
    }

    internal fun record(t: Test, ok: Boolean) {
        Results.map[t] = ok
        render()
        next()
    }

    internal fun skip() {
        render()
        next()
    }

    private fun next() {
        val t = queue.removeFirstOrNull() ?: return
        root.postDelayed({ if (!isFinishing) start(t) }, 400)
    }

    private fun start(t: Test) {
        when (t) {
            Test.TOUCH -> touchLauncher.launch(Intent(this, TouchTestActivity::class.java))
            Test.DISPLAY -> colorLauncher.launch(Intent(this, ColorTestActivity::class.java))
            Test.SPEAKER -> testSpeaker()
            Test.MIC -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runMicTest() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
            Test.CAMERA -> launchCamera(Test.CAMERA)
            Test.FRONT_CAMERA -> {
                if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)) {
                    toast("الجهاز ما فيه كاميرا أمامية")
                    skip()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(Test.FRONT_CAMERA.title)
                        .setMessage("بتفتح الكاميرا الآن. صوّر سيلفي بالكاميرا الأمامية.\nإذا فتحت الخلفية، بدّل للأمامية من تطبيق الكاميرا.")
                        .setCancelable(false)
                        .setPositiveButton("فتح الكاميرا") { _, _ -> launchCamera(Test.FRONT_CAMERA) }
                        .show()
                }
            }
            Test.FLASH -> testFlash()
            Test.VIBRATION -> testVibration()
            Test.BUTTONS -> testButtons()
            Test.EARPIECE -> testEarpiece()
            Test.CHARGING -> testCharging()
            Test.FINGERPRINT -> testFingerprint()
            Test.PROXIMITY -> testProximity()
            Test.MOTION -> testMotion()
            Test.WIFI -> testWifi()
            Test.BLUETOOTH -> testBluetooth()
            Test.SIGNAL -> testSignal()
            Test.GPS -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runGps() else locationPermission.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }
        }
    }

    // ---------- الكاميرا ----------
    private var pendingCamera: Test? = null

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val t = pendingCamera ?: return@registerForActivityResult
            pendingCamera = null
            if (granted) launchCamera(t) else {
                toast("لازم تسمح بالكاميرا عشان نختبرها")
                skip()
            }
        }

    private fun launchCamera(t: Test) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingCamera = t
            cameraPermission.launch(Manifest.permission.CAMERA)
            return
        }
        try {
            if (t == Test.FRONT_CAMERA) frontLauncher.launch(null) else cameraLauncher.launch(null)
        } catch (e: ActivityNotFoundException) {
            toast("ما لقينا تطبيق كاميرا في الجهاز")
            record(t, false)
        } catch (e: SecurityException) {
            toast("لازم تسمح بالكاميرا عشان نختبرها")
            skip()
        }
    }

    // ---------- الاختبارات ----------
    internal fun ask(t: Test, q: String, after: () -> Unit = {}) {
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setMessage(q)
            .setCancelable(false)
            .setPositiveButton("نعم") { _, _ -> after(); record(t, true) }
            .setNegativeButton("لا") { _, _ -> after(); record(t, false) }
            .show()
    }

    private fun testSpeaker() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val prev = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.8).toInt(), 0)
        } catch (e: Exception) {
            // وضع عدم الإزعاج قد يمنع تغيير الصوت
        }
        val tg = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            null
        }
        tg?.startTone(ToneGenerator.TONE_DTMF_6, 2500)
        ask(Test.SPEAKER, "شغّلنا نغمة من السماعة الآن.\nهل سمعتها بوضوح وبدون تشويش؟") {
            tg?.release()
            try {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, prev, 0)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    private fun testVibration() {
        val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (!vib.hasVibrator()) {
            toast("الجهاز ما فيه محرك اهتزاز")
            record(Test.VIBRATION, false)
            return
        }
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 600), -1))
        ask(Test.VIBRATION, "هل حسّيت بالاهتزاز؟") { vib.cancel() }
    }

    private fun testFlash() {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = try {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            null
        }
        if (id == null) {
            toast("ما لقينا فلاش في الجهاز")
            record(Test.FLASH, false)
            return
        }
        try {
            cm.setTorchMode(id, true)
        } catch (e: Exception) {
            toast("تعذّر تشغيل الفلاش")
            record(Test.FLASH, false)
            return
        }
        ask(Test.FLASH, "شغّلنا الفلاش الخلفي.\nهل هو شغّال؟") {
            try {
                cm.setTorchMode(id, false)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    private fun showPhoto(t: Test, bmp: Bitmap) {
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setMessage("هل الصورة واضحة وبدون بقع أو غباش؟")
            .setView(iv)
            .setCancelable(false)
            .setPositiveButton("نعم") { _, _ -> record(t, true) }
            .setNegativeButton("لا") { _, _ -> record(t, false) }
            .show()
    }

    private fun cameraCancelled(t: Test) {
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setMessage("ما تم التقاط صورة. هل الكاميرا ما اشتغلت؟")
            .setCancelable(false)
            .setPositiveButton("الكاميرا ما تشتغل") { _, _ -> record(t, false) }
            .setNegativeButton("تخطّي") { _, _ -> skip() }
            .setNeutralButton("إعادة") { _, _ -> start(t) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun runMicTest() {
        val dlg = AlertDialog.Builder(this)
            .setTitle(Test.MIC.title)
            .setMessage("تكلّم بصوت واضح قرب أسفل الجوال لمدة 3 ثوانٍ…")
            .setCancelable(false)
            .show()
        Thread {
            var peak = 0
            try {
                val rate = 44100
                val minBuf = AudioRecord.getMinBufferSize(
                    rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192)
                )
                val buf = ShortArray(2048)
                rec.startRecording()
                val end = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < end) {
                    val n = rec.read(buf, 0, buf.size)
                    for (i in 0 until n) {
                        val a = abs(buf[i].toInt())
                        if (a > peak) peak = a
                    }
                }
                rec.stop()
                rec.release()
            } catch (e: Exception) {
                peak = -1
            }
            runOnUiThread {
                if (!isFinishing) {
                    dlg.dismiss()
                    micResult(peak)
                }
            }
        }.start()
    }

    private fun micResult(peak: Int) {
        val ok = peak > 1500
        val msg = when {
            peak < 0 -> "تعذّر تشغيل المايك."
            ok -> "المايك يلتقط الصوت بشكل جيد ✓\n(مستوى الصوت: $peak)"
            else -> "الصوت الملتقط ضعيف جداً (المستوى: $peak).\nتأكد إنك تكلمت قرب المايك، أو أعد الاختبار."
        }
        AlertDialog.Builder(this)
            .setTitle(Test.MIC.title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("تمام") { _, _ -> record(Test.MIC, ok) }
            .setNeutralButton("إعادة") { _, _ -> runMicTest() }
            .show()
    }

    private fun testButtons() {
        var up = false
        var down = false
        fun status() = "اضغط زر رفع الصوت ثم زر خفض الصوت.\n\n" +
            "رفع الصوت: ${if (up) "✓" else "…"}\nخفض الصوت: ${if (down) "✓" else "…"}"

        val dlg = AlertDialog.Builder(this)
            .setTitle(Test.BUTTONS.title)
            .setMessage(status())
            .setCancelable(false)
            .setNegativeButton("زر ما يشتغل") { _, _ -> record(Test.BUTTONS, false) }
            .create()
        dlg.setOnKeyListener { d, keyCode, event ->
            val isVolume = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
            if (isVolume && event.action == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) up = true else down = true
                dlg.setMessage(status())
                if (up && down) {
                    d.dismiss()
                    record(Test.BUTTONS, true)
                }
            }
            isVolume
        }
        dlg.show()
    }

    // ---------- التقرير ----------
    private fun openReport(share: Boolean) {
        val snap = snapshot ?: return
        val file = try {
            ReportPdf.create(this, snap, Scoring.compute(snap, Results.map), Results.map)
        } catch (e: Exception) {
            toast("تعذّر إنشاء التقرير: ${e.message}")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = if (share) {
            Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("report", uri)
            }
        } else {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(if (share) Intent.createChooser(intent, "مشاركة التقرير") else intent)
        } catch (e: ActivityNotFoundException) {
            toast("ما فيه تطبيق يفتح PDF، استخدم زر المشاركة")
        }
    }

    // ---------- الواجهة ----------
    private val expanded = mutableSetOf<String>()
    private var ringAnimated = false
    private val orderedTests: List<Test> by lazy { TEST_GROUPS.flatMap { it.second } }

    private fun render() {
        root.removeAllViews()
        val snap = snapshot
        root.addView(hero(snap))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(36))
        }
        root.addView(body)

        body.addView(sectionHeading("الاختبارات", "${Results.map.size} من ${Test.values().size}"))
        for ((group, tests) in TEST_GROUPS) {
            body.addView(testGroup(group, tests), blockParams())
        }

        body.addView(sectionHeading("التقرير", null))
        body.addView(reportBlock(), blockParams())

        if (snap != null) {
            body.addView(sectionHeading("مواصفات الجهاز", null))
            val specs = surface()
            snap.sections.forEachIndexed { i, s -> specs.addView(specSection(s, i > 0)) }
            body.addView(specs, blockParams())
        }
    }

    private fun hero(snap: DeviceSnapshot?): View {
        val r = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(16), dp(20), dp(24))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        box.addView(text("فاحص الجوال", 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(-1, -2))
        box.addView(
            text(snap?.deviceName ?: "", 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) },
            LinearLayout.LayoutParams(-1, -2)
        )

        val sc = snap?.let { Scoring.compute(it, Results.map) }

        // الحلقة والرقم في وسطها
        val ringBox = FrameLayout(this)
        val ring = ScoreRing(this).apply { segments = orderedTests.map { Results.map[it] } }
        ringBox.addView(ring, FrameLayout.LayoutParams(-1, -1))
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        center.addView(text(sc?.percent?.toString() ?: "—", 64f, Fonts.bold, Color.WHITE).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        })
        center.addView(text("من 100", 14f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER })
        ringBox.addView(center, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        box.addView(ringBox, LinearLayout.LayoutParams(dp(224), dp(224)).apply { topMargin = dp(12) })
        if (!ringAnimated) {
            ringAnimated = true
            ring.animateIn()
        }

        if (sc != null) {
            // التقدير يجلس في فتحة الحلقة السفلية
            box.addView(
                text(sc.grade, 20f, Fonts.bold, Scoring.ringGradeColor(sc.percent)).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = -dp(34) }
            )
            val note = when {
                sc.tested == 0 -> "التقييم الحالي من الفحص التلقائي فقط.\nابدأ الاختبارات لتقييم أدق."
                sc.tested < sc.total -> "مبني على ${sc.tested} من ${sc.total} اختبار"
                else -> "اكتملت كل الاختبارات"
            }
            box.addView(
                text(note, 13f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) }
            )
        }

        val remaining = Test.values().size - Results.map.size
        val label = when {
            Results.map.isEmpty() -> "ابدأ الفحص"
            remaining > 0 -> "أكمل الفحص ($remaining متبقية)"
            else -> "أعد الفحص من البداية"
        }
        box.addView(
            pill(label, Color.WHITE, PETROL, filled = true) { runAll() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(20) }
        )
        box.addView(
            pill("فحص جوال ثاني", LIGHT, Color.WHITE, filled = false) {
                startActivity(Intent(this, RemoteActivity::class.java))
            },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
        )
        return box
    }

    private fun sectionHeading(title: String, trailing: String?): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(4), dp(26), dp(4), dp(10))
        }
        row.addView(text(title, 18f, Fonts.bold, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) row.addView(text(trailing, 13f, Fonts.medium, SLATE))
        return row
    }

    private fun testGroup(name: String, tests: List<Test>): View {
        val box = surface()
        val done = tests.count { it in Results.map }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(14), dp(16), dp(4))
        }
        head.addView(text(name, 13f, Fonts.medium, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(text("$done/${tests.size}", 13f, Fonts.medium, if (done == tests.size) GREEN else SLATE))
        box.addView(head)
        tests.forEachIndexed { i, t ->
            if (i > 0) box.addView(divider(dp(56)))
            box.addView(testRow(t))
        }
        return box
    }

    private fun testRow(t: Test): View {
        val r = Results.map[t]
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setBackgroundResource(rippleRes())
            setOnClickListener {
                queue.clear()
                start(t)
            }
        }
        row.addView(statusMark(r), LinearLayout.LayoutParams(dp(28), dp(28)))
        row.addView(
            text(t.title, 15f, Fonts.medium, TEXT),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) }
        )
        row.addView(
            if (r == null) text("ابدأ", 14f, Fonts.bold, PETROL)
            else text("إعادة", 14f, Fonts.medium, SLATE)
        )
        return row
    }

    private fun statusMark(r: Boolean?): View = TextView(this).apply {
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Fonts.bold
        includeFontPadding = false
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            when (r) {
                true -> setColor(PASS_BG)
                false -> setColor(FAIL_BG)
                null -> {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), LINE)
                }
            }
        }
        when (r) {
            true -> {
                text = "✓"
                setTextColor(GREEN)
            }
            false -> {
                text = "✕"
                setTextColor(RED)
            }
            null -> text = ""
        }
    }

    private fun reportBlock(): View {
        val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        box.addView(
            text(
                "ملف PDF فيه التقييم ونتيجة كل اختبار ومواصفات الجهاز، جاهز ترسله للمشتري.",
                14f, Fonts.regular, SLATE
            ).apply { setLineSpacing(0f, 1.25f) }
        )
        val btns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        btns.addView(
            pill("عرض التقرير", PETROL, Color.WHITE, filled = true) { openReport(false) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
        )
        btns.addView(
            pill("مشاركة", PETROL, PETROL, filled = false) { openReport(true) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
        )
        box.addView(btns)
        return box
    }

    private fun specSection(s: InfoSection, divider: Boolean): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (divider) wrap.addView(divider(dp(16)))
        val open = s.title in expanded
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundResource(rippleRes())
            setOnClickListener {
                if (open) expanded.remove(s.title) else expanded.add(s.title)
                render()
            }
        }
        head.addView(text(s.title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(text(if (open) "إخفاء" else "${s.items.size} بنود", 13f, Fonts.regular, SLATE))
        head.addView(text(if (open) "▴" else "▾", 14f, Fonts.regular, SLATE).apply { setPadding(dp(8), 0, 0, 0) })
        wrap.addView(head)
        if (open) {
            val list = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), 0, dp(16), dp(10))
            }
            for (item in s.items) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(7), 0, dp(7))
                }
                row.addView(text(item.label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(text(item.value, 14f, Fonts.medium, TEXT).apply { gravity = Gravity.END })
                list.addView(row)
            }
            wrap.addView(list)
        }
        return wrap
    }

    // ---------- عناصر مشتركة ----------
    private fun surface(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(20).toFloat()
        }
        clipToOutline = true
    }

    private fun blockParams() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }

    private fun divider(insetStart: Int): View = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { marginStart = insetStart }
    }

    private fun rippleRes(): Int {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun pill(label: String, bg: Int, fg: Int, filled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            textSize = 15f
            typeface = Fonts.bold
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                if (filled) setColor(bg) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), bg)
                }
            }
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

/** يطلب من تطبيق الكاميرا يفتح الأمامية (تدعمه أغلب تطبيقات الكاميرا) */
class FrontPicturePreview : ActivityResultContracts.TakePicturePreview() {
    override fun createIntent(context: Context, input: Void?): Intent =
        super.createIntent(context, input).apply {
            putExtra("android.intent.extras.CAMERA_FACING", 1)
            putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
            putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        }
}
