package com.phonecheck.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var snapshot: DeviceSnapshot? = null
    private val queue = ArrayDeque<Test>()

    // ---------- نتائج الشاشات والأذونات ----------
    private val touchLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            record(Test.TOUCH, it.resultCode == RESULT_OK)
        }

    private val colorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.DISPLAY, true)
                RESULT_FIRST_USER -> record(Test.DISPLAY, false)
                else -> skip()
            }
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.CAMERA) else showPhoto(Test.CAMERA, bmp)
        }

    private val frontLauncher =
        registerForActivityResult(FrontPicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.FRONT_CAMERA) else showPhoto(Test.FRONT_CAMERA, bmp)
        }

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) runGps() else {
                toast("لازم تسمح بالموقع الدقيق عشان نختبر الـ GPS")
                skip()
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) runMicTest() else {
                toast("لازم تسمح باستخدام المايك عشان نختبره")
                skip()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(28))
        }
        val scroll = ScrollView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(BG)
            addView(root)
        }
        setContentView(scroll)
        window.statusBarColor = PRIMARY
    }

    override fun onResume() {
        super.onResume()
        snapshot = try {
            DeviceInfo.collect(this)
        } catch (e: Exception) {
            null
        }
        render()
    }

    // ---------- تسلسل الاختبارات ----------
    private fun runAll() {
        if (Results.map.size == Test.values().size) Results.map.clear()
        queue.clear()
        queue.addAll(Test.values().filter { it !in Results.map })
        render()
        next()
    }

    internal fun record(t: Test, ok: Boolean) {
        Results.map[t] = ok
        render()
        next()
    }

    internal fun skip() {
        render()
        next()
    }

    private fun next() {
        val t = queue.removeFirstOrNull() ?: return
        root.postDelayed({ if (!isFinishing) start(t) }, 400)
    }

    private fun start(t: Test) {
        when (t) {
            Test.TOUCH -> touchLauncher.launch(Intent(this, TouchTestActivity::class.java))
            Test.DISPLAY -> colorLauncher.launch(Intent(this, ColorTestActivity::class.java))
            Test.SPEAKER -> testSpeaker()
            Test.MIC -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runMicTest() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
            Test.CAMERA -> {
                try {
                    cameraLauncher.launch(null)
                } catch (e: ActivityNotFoundException) {
                    toast("ما لقينا تطبيق كاميرا في الجهاز")
                    record(Test.CAMERA, false)
                }
            }
            Test.FRONT_CAMERA -> {
                if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)) {
                    toast("الجهاز ما فيه كاميرا أمامية")
                    skip()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(Test.FRONT_CAMERA.title)
                        .setMessage("بتفتح الكاميرا الآن. صوّر سيلفي بالكاميرا الأمامية.\nإذا فتحت الخلفية، بدّل للأمامية من تطبيق الكاميرا.")
                        .setCancelable(false)
                        .setPositiveButton("فتح الكاميرا") { _, _ ->
                            try {
                                frontLauncher.launch(null)
                            } catch (e: ActivityNotFoundException) {
                                toast("ما لقينا تطبيق كاميرا في الجهاز")
                                record(Test.FRONT_CAMERA, false)
                            }
                        }
                        .show()
                }
            }
            Test.FLASH -> testFlash()
            Test.VIBRATION -> testVibration()
            Test.BUTTONS -> testButtons()
            Test.EARPIECE -> testEarpiece()
            Test.CHARGING -> testCharging()
            Test.FINGERPRINT -> testFingerprint()
            Test.PROXIMITY -> testProximity()
            Test.MOTION -> testMotion()
            Test.WIFI -> testWifi()
            Test.BLUETOOTH -> testBluetooth()
            Test.SIGNAL -> testSignal()
            Test.GPS -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runGps() else locationPermission.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }
        }
    }

    // ---------- الاختبارات ----------
    internal fun ask(t: Test, q: String, after: () -> Unit = {}) {
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setMessage(q)
            .setCancelable(false)
            .setPositiveButton("نعم") { _, _ -> after(); record(t, true) }
            .setNegativeButton("لا") { _, _ -> after(); record(t, false) }
            .show()
    }

    private fun testSpeaker() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val prev = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.8).toInt(), 0)
        } catch (e: Exception) {
            // وضع عدم الإزعاج قد يمنع تغيير الصوت
        }
        val tg = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            null
        }
        tg?.startTone(ToneGenerator.TONE_DTMF_6, 2500)
        ask(Test.SPEAKER, "شغّلنا نغمة من السماعة الآن.\nهل سمعتها بوضوح وبدون تشويش؟") {
            tg?.release()
            try {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, prev, 0)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    private fun testVibration() {
        val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (!vib.hasVibrator()) {
            toast("الجهاز ما فيه محرك اهتزاز")
            record(Test.VIBRATION, false)
            return
        }
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 600), -1))
        ask(Test.VIBRATION, "هل حسّيت بالاهتزاز؟") { vib.cancel() }
    }

    private fun testFlash() {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = try {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            null
        }
        if (id == null) {
            toast("ما لقينا فلاش في الجهاز")
            record(Test.FLASH, false)
            return
        }
        try {
            cm.setTorchMode(id, true)
        } catch (e: Exception) {
            toast("تعذّر تشغيل الفلاش")
            record(Test.FLASH, false)
            return
        }
        ask(Test.FLASH, "شغّلنا الفلاش الخلفي.\nهل هو شغّال؟") {
            try {
                cm.setTorchMode(id, false)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    private fun showPhoto(t: Test, bmp: Bitmap) {
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setMessage("هل الصورة واضحة وبدون بقع أو غباش؟")
            .setView(iv)
            .setCancelable(false)
            .setPositiveButton("نعم") { _, _ -> record(t, true) }
            .setNegativeButton("لا") { _, _ -> record(t, false) }
            .show()
    }

    private fun cameraCancelled(t: Test) {
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setMessage("ما تم التقاط صورة. هل الكاميرا ما اشتغلت؟")
            .setCancelable(false)
            .setPositiveButton("الكاميرا ما تشتغل") { _, _ -> record(t, false) }
            .setNegativeButton("تخطّي") { _, _ -> skip() }
            .setNeutralButton("إعادة") { _, _ -> start(t) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun runMicTest() {
        val dlg = AlertDialog.Builder(this)
            .setTitle(Test.MIC.title)
            .setMessage("تكلّم بصوت واضح قرب أسفل الجوال لمدة 3 ثوانٍ…")
            .setCancelable(false)
            .show()
        Thread {
            var peak = 0
            try {
                val rate = 44100
                val minBuf = AudioRecord.getMinBufferSize(
                    rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192)
                )
                val buf = ShortArray(2048)
                rec.startRecording()
                val end = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < end) {
                    val n = rec.read(buf, 0, buf.size)
                    for (i in 0 until n) {
                        val a = abs(buf[i].toInt())
                        if (a > peak) peak = a
                    }
                }
                rec.stop()
                rec.release()
            } catch (e: Exception) {
                peak = -1
            }
            runOnUiThread {
                if (!isFinishing) {
                    dlg.dismiss()
                    micResult(peak)
                }
            }
        }.start()
    }

    private fun micResult(peak: Int) {
        val ok = peak > 1500
        val msg = when {
            peak < 0 -> "تعذّر تشغيل المايك."
            ok -> "المايك يلتقط الصوت بشكل جيد ✓\n(مستوى الصوت: $peak)"
            else -> "الصوت الملتقط ضعيف جداً (المستوى: $peak).\nتأكد إنك تكلمت قرب المايك، أو أعد الاختبار."
        }
        AlertDialog.Builder(this)
            .setTitle(Test.MIC.title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("تمام") { _, _ -> record(Test.MIC, ok) }
            .setNeutralButton("إعادة") { _, _ -> runMicTest() }
            .show()
    }

    private fun testButtons() {
        var up = false
        var down = false
        fun status() = "اضغط زر رفع الصوت ثم زر خفض الصوت.\n\n" +
            "رفع الصوت: ${if (up) "✓" else "…"}\nخفض الصوت: ${if (down) "✓" else "…"}"

        val dlg = AlertDialog.Builder(this)
            .setTitle(Test.BUTTONS.title)
            .setMessage(status())
            .setCancelable(false)
            .setNegativeButton("زر ما يشتغل") { _, _ -> record(Test.BUTTONS, false) }
            .create()
        dlg.setOnKeyListener { d, keyCode, event ->
            val isVolume = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
            if (isVolume && event.action == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) up = true else down = true
                dlg.setMessage(status())
                if (up && down) {
                    d.dismiss()
                    record(Test.BUTTONS, true)
                }
            }
            isVolume
        }
        dlg.show()
    }

    // ---------- التقرير ----------
    private fun openReport(share: Boolean) {
        val snap = snapshot ?: return
        val file = try {
            ReportPdf.create(this, snap, Scoring.compute(snap, Results.map), Results.map)
        } catch (e: Exception) {
            toast("تعذّر إنشاء التقرير: ${e.message}")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = if (share) {
            Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("report", uri)
            }
        } else {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(if (share) Intent.createChooser(intent, "مشاركة التقرير") else intent)
        } catch (e: ActivityNotFoundException) {
            toast("ما فيه تطبيق يفتح PDF، استخدم زر المشاركة")
        }
    }

    // ---------- الواجهة ----------
    private fun render() {
        root.removeAllViews()
        val snap = snapshot

        // البطاقة الرئيسية
        val header = card(PRIMARY)
        header.addView(text("فاحص الجوال", 22f, true, Color.WHITE))
        header.addView(text(snap?.deviceName ?: "", 15f, false, LIGHT))
        if (snap != null) {
            val sc = Scoring.compute(snap, Results.map)
            header.addView(text("${sc.percent}", 56f, true, Color.WHITE).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            })
            header.addView(text("من 100  —  ${sc.grade}", 16f, true, Color.WHITE).apply { gravity = Gravity.CENTER })
            header.addView(text("الاختبارات المنجزة: ${sc.tested} من ${sc.total}", 13f, false, LIGHT).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
        }
        val mainLabel = when {
            Results.map.isEmpty() -> "ابدأ الفحص الكامل"
            Results.map.size < Test.values().size -> "أكمل الفحص"
            else -> "إعادة الفحص من البداية"
        }
        header.addView(button(mainLabel, Color.WHITE, PRIMARY) { runAll() })
        root.addView(header)

        // الاختبارات
        val tests = card()
        tests.addView(title("الاختبارات"))
        for (t in Test.values()) tests.addView(testRow(t))
        root.addView(tests)

        // التقرير
        val rep = card()
        rep.addView(title("التقرير"))
        rep.addView(text("أنشئ تقرير PDF فيه التقييم وكل تفاصيل الجهاز، وشاركه مع المشتري أو احفظه.", 13f, false, GRAY))
        val btns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        btns.addView(
            button("عرض التقرير", PRIMARY, Color.WHITE) { openReport(false) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
        )
        btns.addView(
            button("مشاركة", GREEN, Color.WHITE) { openReport(true) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
        )
        rep.addView(btns)
        root.addView(rep)

        // تفاصيل الجهاز
        snap?.sections?.forEach { s ->
            val c = card()
            c.addView(title(s.title))
            for (item in s.items) c.addView(infoRow(item))
            root.addView(c)
        }
    }

    private fun testRow(t: Test): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val r = Results.map[t]
        row.addView(text(t.title, 15f, false, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        val (label, color) = when (r) {
            true -> "سليم ✓" to GREEN
            false -> "مشكلة ✗" to RED
            null -> "لم يُختبر" to GRAY
        }
        row.addView(text(label, 13f, true, color).apply { setPadding(dp(8), 0, dp(8), 0) })
        val b = Button(this).apply {
            text = if (r == null) "اختبار" else "إعادة"
            isAllCaps = false
            textSize = 13f
            setTextColor(PRIMARY)
            background = GradientDrawable().apply {
                setStroke(dp(1), PRIMARY)
                cornerRadius = dp(8).toFloat()
            }
            stateListAnimator = null
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                queue.clear()
                start(t)
            }
        }
        row.addView(b)
        return row
    }

    private fun infoRow(item: InfoItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, dp(6))
        }
        row.addView(text(item.label, 14f, false, GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(item.value, 14f, true, TEXT).apply { gravity = Gravity.END })
        return row
    }

    private fun card(bg: Int = Color.WHITE): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(16).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun title(s: String): TextView = text(s, 17f, true, TEXT).apply { setPadding(0, 0, 0, dp(6)) }

    private fun text(s: String, size: Float, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, bg: Int, fg: Int, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(fg)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(12).toFloat()
        }
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(14) }
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

/** يطلب من تطبيق الكاميرا يفتح الأمامية (تدعمه أغلب تطبيقات الكاميرا) */
class FrontPicturePreview : ActivityResultContracts.TakePicturePreview() {
    override fun createIntent(context: Context, input: Void?): Intent =
        super.createIntent(context, input).apply {
            putExtra("android.intent.extras.CAMERA_FACING", 1)
            putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
            putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        }
}
