package com.phonecheck.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.text.Editable
import android.text.TextWatcher
import android.content.res.ColorStateList
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var snapshot: DeviceSnapshot? = null
    private val queue = ArrayDeque<Test>()

    // ---------- نتائج الشاشات والأذونات ----------
    private val touchLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.TOUCH, true)
                RESULT_FIRST_USER -> record(Test.TOUCH, false)
                else -> stopRun()
            }
        }

    private val colorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.DISPLAY, true)
                RESULT_FIRST_USER -> record(Test.DISPLAY, false)
                else -> stopRun()
            }
        }

    private val batteryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.BATTERY, true)
                RESULT_FIRST_USER -> record(Test.BATTERY, false)
                RESULT_UNDETERMINED -> skip()
                else -> stopRun()
            }
        }

    private val perfLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.CPU, true)
                RESULT_FIRST_USER -> record(Test.CPU, false)
                else -> stopRun()
            }
        }

    private val multiTouchLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            when (it.resultCode) {
                RESULT_OK -> record(Test.MULTITOUCH, true)
                RESULT_FIRST_USER -> record(Test.MULTITOUCH, false)
                RESULT_UNDETERMINED -> skip()
                else -> stopRun()
            }
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.CAMERA) else showPhoto(Test.CAMERA, bmp)
        }

    private val frontLauncher =
        registerForActivityResult(FrontPicturePreview()) { bmp ->
            if (bmp == null) cameraCancelled(Test.FRONT_CAMERA) else showPhoto(Test.FRONT_CAMERA, bmp)
        }

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) runGps() else {
                toast(tr("لازم تسمح بالموقع الدقيق عشان نختبر الـ GPS", "Allow precise location to test GPS"))
                skip()
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) runMicTest() else {
                toast(tr("لازم تسمح باستخدام المايك عشان نختبره", "Allow microphone access to test it"))
                skip()
            }
        }

    // ---------- الشاشات ----------
    private enum class Tab { HOME, TESTS, REPORT, DEVICE, MORE }
    private var tab = Tab.HOME
    private lateinit var scroll: ScrollView
    private lateinit var nav: BottomNavigationView

    /** تنظيف الاختبار الشغّال (حساسات، مؤقتات…) لو انوقف الفحص */
    internal var cleanup: (() -> Unit)? = null
    private var pendingStart: Runnable? = null
    private var usageLoading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        tab = Tab.values()[savedInstanceState?.getInt("tab", 0) ?: 0]
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        }
        nav = BottomNavigationView(this).apply {
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
            labelVisibilityMode = NavigationBarView.LABEL_VISIBILITY_LABELED
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            val colors = ColorStateList(states, intArrayOf(PETROL, GRAY))
            itemIconTintList = colors
            itemTextColor = colors
            menu.add(0, Tab.HOME.ordinal, 0, tr("الرئيسية", "Home")).setIcon(R.drawable.ic_tab_home)
            menu.add(0, Tab.TESTS.ordinal, 1, tr("الاختبارات", "Tests")).setIcon(R.drawable.ic_tab_tests)
            menu.add(0, Tab.REPORT.ordinal, 2, tr("التقرير", "Report")).setIcon(R.drawable.ic_tab_report)
            menu.add(0, Tab.DEVICE.ordinal, 3, tr("الجهاز", "Device")).setIcon(R.drawable.ic_tab_device)
            menu.add(0, Tab.MORE.ordinal, 4, tr("المزيد", "More")).setIcon(R.drawable.ic_tab_more)
            selectedItemId = tab.ordinal
            setOnItemSelectedListener { item ->
                tab = Tab.values()[item.itemId]
                scroll.scrollTo(0, 0)
                render()
                true
            }
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = Lang.dir
        }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(page)
        window.statusBarColor = PRIMARY
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab.ordinal)
    }

    override fun onResume() {
        super.onResume()
        RunControl.onStop = { stopRun() }
        snapshot = try {
            DeviceInfo.collect(this)
        } catch (e: Exception) {
            null
        }
        render()
        refreshUsage()
    }

    override fun onPause() {
        RunControl.onStop = null
        super.onPause()
    }

    private fun goTab(t: Tab) {
        tab = t
        nav.selectedItemId = t.ordinal
    }

    private fun refreshUsage() {
        if (usageLoading || !UsageAnalyzer.hasAccess(this)) return
        usageLoading = true
        Thread {
            val u = try {
                UsageAnalyzer.analyze(this)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                usageLoading = false
                Results.usage = u
                if (!isFinishing) render()
            }
        }.start()
    }

    // ---------- تسلسل الاختبارات ----------
    private fun runAll() {
        if (Results.map.size == Test.values().size) {
            Results.clearTests()
        }
        queue.clear()
        queue.addAll(Test.values().filter { it !in Results.map })
        render()
        next()
    }

    private fun running(): Boolean = queue.isNotEmpty() || cleanup != null

    /** إيقاف الفحص: يوقف الاختبار الحالي ويفضّي الطابور ويرجع للرئيسية */
    internal fun stopRun() {
        pendingStart?.let { root.removeCallbacks(it) }
        pendingStart = null
        queue.clear()
        cleanup?.invoke()
        cleanup = null
        RunControl.current?.dismiss()
        if (::nav.isInitialized && tab != Tab.HOME) goTab(Tab.HOME) else render()
        toast(tr("تم إيقاف الفحص", "Inspection stopped"))
    }

    internal fun record(t: Test, ok: Boolean) {
        cleanup = null
        Results.map[t] = ok
        render()
        next()
    }

    internal fun skip() {
        cleanup = null
        render()
        next()
    }

    private fun next() {
        val t = queue.removeFirstOrNull() ?: return
        val r = Runnable {
            pendingStart = null
            if (!isFinishing) start(t)
        }
        pendingStart = r
        root.postDelayed(r, 400)
    }

    private fun start(t: Test) {
        when (t) {
            Test.TOUCH -> touchLauncher.launch(Intent(this, TouchTestActivity::class.java))
            Test.DISPLAY -> colorLauncher.launch(Intent(this, ColorTestActivity::class.java))
            Test.SPEAKER -> testSpeaker()
            Test.MIC -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runMicTest() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
            Test.CAMERA -> launchCamera(Test.CAMERA)
            Test.FRONT_CAMERA -> {
                if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)) {
                    toast(tr("الجهاز ما فيه كاميرا أمامية", "This device has no front camera"))
                    skip()
                } else {
                    PcDialog(this)
                        .setTitle(Test.FRONT_CAMERA.title)
                        .setMessage(tr("بتفتح الكاميرا الآن. صوّر سيلفي بالكاميرا الأمامية.\nإذا فتحت الخلفية، بدّل للأمامية من تطبيق الكاميرا.", "The camera will open now. Take a selfie with the front camera.\nIf the rear camera opens, switch to the front one in the camera app."))
                        .setCancelable(false)
                        .setPositiveButton(tr("فتح الكاميرا", "Open camera")) { _, _ -> launchCamera(Test.FRONT_CAMERA) }
                        .show()
                }
            }
            Test.FLASH -> testFlash()
            Test.VIBRATION -> testVibration()
            Test.BUTTONS -> testButtons()
            Test.EARPIECE -> testEarpiece()
            Test.CHARGING -> testCharging()
            Test.STORAGE -> testStorage()
            Test.BATTERY -> batteryLauncher.launch(Intent(this, BatteryTestActivity::class.java))
            Test.FINGERPRINT -> testFingerprint()
            Test.PROXIMITY -> testProximity()
            Test.MOTION -> testMotion()
            Test.WIFI -> testWifi()
            Test.BLUETOOTH -> testBluetooth()
            Test.SIGNAL -> testSignal()
            Test.CPU -> perfLauncher.launch(Intent(this, PerfTestActivity::class.java))
            Test.RAM -> testRam()
            Test.MULTITOUCH -> multiTouchLauncher.launch(Intent(this, MultiTouchActivity::class.java))
            Test.LIGHT -> testLight()
            Test.COMPASS -> testCompass()
            Test.GPS -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) runGps() else locationPermission.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }
        }
    }

    // ---------- الكاميرا ----------
    private var pendingCamera: Test? = null

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val t = pendingCamera ?: return@registerForActivityResult
            pendingCamera = null
            if (granted) launchCamera(t) else {
                toast(tr("لازم تسمح بالكاميرا عشان نختبرها", "Allow camera access to test it"))
                skip()
            }
        }

    private fun launchCamera(t: Test) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingCamera = t
            cameraPermission.launch(Manifest.permission.CAMERA)
            return
        }
        try {
            if (t == Test.FRONT_CAMERA) frontLauncher.launch(null) else cameraLauncher.launch(null)
        } catch (e: ActivityNotFoundException) {
            toast(tr("ما لقينا تطبيق كاميرا في الجهاز", "No camera app found"))
            record(t, false)
        } catch (e: SecurityException) {
            toast(tr("لازم تسمح بالكاميرا عشان نختبرها", "Allow camera access to test it"))
            skip()
        }
    }

    // ---------- الاختبارات ----------
    internal fun ask(t: Test, q: String, after: () -> Unit = {}) {
        cleanup = after
        PcDialog(this)
            .setTitle(t.title)
            .setMessage(q)
            .setCancelable(false)
            .setPositiveButton(tr("نعم", "Yes")) { _, _ -> after(); record(t, true) }
            .setNegativeButton(tr("لا", "No")) { _, _ -> after(); record(t, false) }
            .show()
    }

    private fun testSpeaker() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val prev = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.8).toInt(), 0)
        } catch (e: Exception) {
            // وضع عدم الإزعاج قد يمنع تغيير الصوت
        }
        val tg = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            null
        }
        tg?.startTone(ToneGenerator.TONE_DTMF_6, 2500)
        ask(Test.SPEAKER, tr("شغّلنا نغمة من السماعة الآن.\nهل سمعتها بوضوح وبدون تشويش؟", "A tone is playing from the speaker.\nDid you hear it clearly, without distortion?")) {
            tg?.release()
            try {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, prev, 0)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    private fun testVibration() {
        val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (!vib.hasVibrator()) {
            toast(tr("الجهاز ما فيه محرك اهتزاز", "This device has no vibration motor"))
            record(Test.VIBRATION, false)
            return
        }
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 600), -1))
        ask(Test.VIBRATION, tr("هل حسّيت بالاهتزاز؟", "Did you feel the vibration?")) { vib.cancel() }
    }

    private fun testFlash() {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = try {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            null
        }
        if (id == null) {
            toast(tr("ما لقينا فلاش في الجهاز", "No flash found on this device"))
            record(Test.FLASH, false)
            return
        }
        try {
            cm.setTorchMode(id, true)
        } catch (e: Exception) {
            toast(tr("تعذّر تشغيل الفلاش", "Could not turn on the flash"))
            record(Test.FLASH, false)
            return
        }
        ask(Test.FLASH, tr("شغّلنا الفلاش الخلفي.\nهل هو شغّال؟", "The rear flash is on.\nIs it lit?")) {
            try {
                cm.setTorchMode(id, false)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    private fun showPhoto(t: Test, bmp: Bitmap) {
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        PcDialog(this)
            .setTitle(t.title)
            .setMessage(tr("هل الصورة واضحة وبدون بقع أو غباش؟", "Is the photo clear, without spots or blur?"))
            .setView(iv)
            .setCancelable(false)
            .setPositiveButton(tr("نعم", "Yes")) { _, _ -> record(t, true) }
            .setNegativeButton(tr("لا", "No")) { _, _ -> record(t, false) }
            .show()
    }

    private fun cameraCancelled(t: Test) {
        PcDialog(this)
            .setTitle(t.title)
            .setMessage(tr("ما تم التقاط صورة. هل الكاميرا ما اشتغلت؟", "No photo was taken. Did the camera fail to work?"))
            .setCancelable(false)
            .setPositiveButton(tr("الكاميرا ما تشتغل", "Camera not working")) { _, _ -> record(t, false) }
            .setNegativeButton(tr("تخطّي", "Skip")) { _, _ -> skip() }
            .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> start(t) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun runMicTest() {
        var cancelled = false
        cleanup = { cancelled = true }
        val dlg = PcDialog(this)
            .setTitle(Test.MIC.title)
            .setMessage(tr("تكلّم بصوت واضح قرب أسفل الجوال لمدة 3 ثوانٍ…", "Speak clearly near the bottom of the phone for 3 seconds…"))
            .setCancelable(false)
            .show()
        Thread {
            var peak = 0
            try {
                val rate = 44100
                val minBuf = AudioRecord.getMinBufferSize(
                    rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192)
                )
                val buf = ShortArray(2048)
                rec.startRecording()
                val end = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < end) {
                    val n = rec.read(buf, 0, buf.size)
                    for (i in 0 until n) {
                        val a = abs(buf[i].toInt())
                        if (a > peak) peak = a
                    }
                }
                rec.stop()
                rec.release()
            } catch (e: Exception) {
                peak = -1
            }
            runOnUiThread {
                if (!isFinishing && !cancelled) {
                    dlg.dismiss()
                    micResult(peak)
                }
            }
        }.start()
    }

    private fun micResult(peak: Int) {
        val ok = peak > 1500
        val msg = when {
            peak < 0 -> tr("تعذّر تشغيل المايك.", "Could not start the microphone.")
            ok -> tr("المايك يلتقط الصوت بشكل جيد ✓\n(مستوى الصوت: $peak)", "The microphone picks up sound well ✓\n(level: $peak)")
            else -> tr("الصوت الملتقط ضعيف جداً (المستوى: $peak).\nتأكد إنك تكلمت قرب المايك، أو أعد الاختبار.", "Very weak sound (level: $peak).\nMake sure you spoke near the mic, or retest.")
        }
        PcDialog(this)
            .setTitle(Test.MIC.title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton(tr("تمام", "OK")) { _, _ -> record(Test.MIC, ok) }
            .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> runMicTest() }
            .show()
    }

    private fun testButtons() {
        var up = false
        var down = false
        fun status() = tr("اضغط زر رفع الصوت ثم زر خفض الصوت.\n\n", "Press volume up, then volume down.\n\n") +
            tr("رفع الصوت: ", "Volume up: ") + (if (up) "✓" else "…") + "\n" +
            tr("خفض الصوت: ", "Volume down: ") + (if (down) "✓" else "…")

        val dlg = PcDialog(this)
            .setTitle(Test.BUTTONS.title)
            .setMessage(status())
            .setCancelable(false)
            .setNegativeButton(tr("زر ما يشتغل", "A button fails")) { _, _ -> record(Test.BUTTONS, false) }
            .create()
        dlg.setOnKeyListener { d, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (event.action == KeyEvent.ACTION_UP) RunControl.confirmStop(this)
                return@setOnKeyListener true
            }
            val isVolume = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
            if (isVolume && event.action == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) up = true else down = true
                dlg.setMessage(status())
                if (up && down) {
                    d.dismiss()
                    record(Test.BUTTONS, true)
                }
            }
            isVolume
        }
        dlg.show()
    }

    // ---------- التقرير ----------
    // نعيد استخدام نفس التقرير لو ما تغيّر شي، عشان العرض ثم المشاركة ما يسوّون تقريرين في السجل
    private var lastReport: Pair<String, File>? = null

    private fun reportKey(): String =
        listOf(Results.map, Results.details, Results.body, Results.screen, Results.notes, Results.battery, Results.usage, Results.usageInReport, Results.perf, Results.ram, Lang.en).toString()

    private fun openReport(share: Boolean) {
        val snap = snapshot ?: return
        val key = reportKey()
        val cached = lastReport?.takeIf { it.first == key && it.second.exists() }?.second
        val file = cached ?: try {
            ReportPdf.create(
                this, snap, Scoring.compute(snap, Results.map), Results.map,
                extras = ReportExtras(
                    Results.details.toMap(), Results.body, Results.screen, Results.notes, Results.battery,
                    if (Results.usageInReport) Results.usage else null,
                    RedFlags.compute(snap), Results.perf, Results.ram,
                )
            ).also { lastReport = key to it }
        } catch (e: Exception) {
            toast(tr("تعذّر إنشاء التقرير: ", "Could not create the report: ") + e.message)
            return
        }
        openPdf(file, share)
    }

    // ---------- الواجهة ----------
    private val expanded = mutableSetOf<String>()
    private var ringAnimated = false
    private val orderedTests: List<Test> by lazy { TEST_GROUPS.flatMap { it.tests } }

    private fun render() {
        root.removeAllViews()
        when (tab) {
            Tab.HOME -> homeTab()
            Tab.TESTS -> testsTab()
            Tab.REPORT -> reportTab()
            Tab.DEVICE -> deviceTab()
            Tab.MORE -> moreTab()
        }
    }

    private fun body(): LinearLayout {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(28))
        }
        root.addView(b)
        return b
    }

    /** ترويسة الشاشات الفرعية */
    private fun pageHeader(title: String, sub: String?) {
        val r = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        box.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT))
        box.addView(text(title, 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
        if (!sub.isNullOrBlank()) box.addView(text(sub, 14f, Fonts.regular, LIGHT).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(box)
    }

    // ---------- الرئيسية ----------
    private fun homeTab() {
        root.addView(hero(snapshot))
        val b = body()
        val flags = RedFlags.compute(snapshot)
        if (flags.isNotEmpty()) b.addView(flagsBlock(flags), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        b.addView(sectionHeading(tr("أدوات الفحص", "Inspection tools"), null))

        val bat = Results.battery
        val usage = Results.usage
        val tiles = listOf(
            Triple(
                tr("صحة البطارية", "Battery health"),
                bat?.summary ?: tr("فحص عميق 10-20 دقيقة", "10-20 min deep test"),
            ) { startSingle(Test.BATTERY) },
            Triple(
                tr("المعالج والتهنيج", "Processor & lag"),
                Results.perf?.let { p ->
                    (if (p.passed) tr("سليم · ", "OK · ") else tr("فيه مشكلة · ", "Issue · ")) + p.summary
                } ?: tr("اختبار ضغط دقيقة ونص", "90-second stress test"),
            ) { startSingle(Test.CPU) },
            Triple(
                tr("الرام والتخزين", "RAM & storage"),
                listOfNotNull(
                    Results.map[Test.RAM]?.let { tr("الرام ", "RAM ") + if (it) "✓" else "✗" },
                    Results.map[Test.STORAGE]?.let { tr("التخزين ", "Storage ") + if (it) "✓" else "✗" },
                ).joinToString(" · ").ifBlank { tr("فحص الأعطال الخفية", "Find hidden faults") },
            ) { checkMemory() },
            Triple(
                tr("ملف الاستخدام", "Usage profile"),
                when {
                    usage != null -> usage.intensityText
                    UsageAnalyzer.hasAccess(this) -> tr("جاري التحليل…", "Analyzing…")
                    else -> tr("يحتاج تفعيل", "Needs access")
                },
            ) { goTab(Tab.REPORT) },
            Triple(tr("فحص جوال ثاني", "Inspect another phone"), tr("آيفون أو أندرويد", "iPhone or Android")) {
                startActivity(Intent(this, RemoteActivity::class.java))
            },
            Triple(
                tr("التقرير", "Report"),
                tr("${History.all(this).size} تقرير محفوظ", "${History.all(this).size} saved"),
            ) { goTab(Tab.REPORT) },
        )
        for (i in tiles.indices step 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in i until minOf(i + 2, tiles.size)) {
                val (t, sub, onClick) = tiles[j]
                row.addView(tile(t, sub, onClick), LinearLayout.LayoutParams(0, -1, 1f).apply {
                    if (j % 2 == 1) marginStart = dp(10)
                })
            }
            b.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }

    private fun tile(title: String, sub: String, onClick: () -> Unit): View {
        val box = surface().apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            minimumHeight = dp(96)
            setBackgroundResource(0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
            foreground = getDrawable(rippleRes())
            isClickable = true
            setOnClickListener { onClick() }
        }
        box.addView(text(title, 15f, Fonts.bold, TEXT))
        box.addView(text(sub, 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(4), 0, 0) })
        return box
    }

    /** الرام ثم التخزين ورا بعض */
    private fun checkMemory() {
        queue.clear()
        queue.add(Test.STORAGE)
        start(Test.RAM)
    }

    /** صندوق "تنبيهات مهمة" */
    private fun flagsBlock(flags: List<RedFlag>): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(if (flags.any { it.severe }) FAIL_BG else 0xFFFDF1DC.toInt())
                cornerRadius = dp(20).toFloat()
            }
        }
        box.addView(text("⚠  " + tr("تنبيهات مهمة", "Important warnings"), 16f, Fonts.bold, if (flags.any { it.severe }) RED else 0xFFA86B0C.toInt()))
        for (f in flags.take(8)) {
            box.addView(text("•  " + f.text, 14f, Fonts.regular, TEXT).apply {
                setPadding(0, dp(6), 0, 0)
                if (f.severe) setTextColor(RED)
            })
        }
        if (flags.size > 8) box.addView(text(tr("+${flags.size - 8} في التقرير", "+${flags.size - 8} more in the report"), 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(6), 0, 0) })
        return box
    }

    /** تشغيل اختبار واحد (مو الفحص الكامل) */
    private fun startSingle(t: Test) {
        queue.clear()
        start(t)
    }

    private fun hero(snap: DeviceSnapshot?): View {
        val r = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(14), dp(20), dp(24))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chip(if (Lang.en) "العربية" else "English") { switchLanguage() })
        box.addView(top, LinearLayout.LayoutParams(-1, -2))

        box.addView(
            text(snap?.deviceName ?: "", 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(6), 0, 0) },
            LinearLayout.LayoutParams(-1, -2)
        )

        val sc = snap?.let { Scoring.compute(it, Results.map) }

        // الحلقة والرقم في وسطها
        val ringBox = FrameLayout(this)
        val ring = ScoreRing(this).apply { segments = orderedTests.map { Results.map[it] } }
        ringBox.addView(ring, FrameLayout.LayoutParams(-1, -1))
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        center.addView(text(sc?.percent?.toString() ?: "—", 64f, Fonts.bold, Color.WHITE).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        })
        center.addView(text(tr("من 100", "out of 100"), 14f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER })
        ringBox.addView(center, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        box.addView(ringBox, LinearLayout.LayoutParams(dp(224), dp(224)).apply { topMargin = dp(12) })
        if (!ringAnimated) {
            ringAnimated = true
            ring.animateIn()
        }

        if (sc != null) {
            box.addView(
                text(sc.grade, 20f, Fonts.bold, Scoring.ringGradeColor(sc.percent)).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = -dp(34) }
            )
            val note = when {
                sc.tested == 0 -> tr("التقييم الحالي من الفحص التلقائي فقط.\nابدأ الاختبارات لتقييم أدق.", "Current score is from the automatic check only.\nRun the tests for an accurate score.")
                sc.tested < sc.total -> tr("مبني على ${sc.tested} من ${sc.total} اختبار", "Based on ${sc.tested} of ${sc.total} tests")
                else -> tr("اكتملت كل الاختبارات", "All tests completed")
            }
            box.addView(
                text(note, 13f, Fonts.regular, LIGHT).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) }
            )
        }
        box.addView(runButton(onDark = true), LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(20) })
        return box
    }

    /** زر بدء/إكمال الفحص، ويتحوّل لـ "إيقاف الفحص" وقت ما يكون شغّال */
    private fun runButton(onDark: Boolean): View {
        if (running()) {
            return pill(
                tr("إيقاف الفحص", "Stop inspection"),
                if (onDark) Color.WHITE else RED, if (onDark) Color.WHITE else RED, filled = false
            ) { stopRun() }
        }
        val remaining = Test.values().size - Results.map.size
        val label = when {
            Results.map.isEmpty() -> tr("ابدأ الفحص الكامل", "Start full inspection")
            remaining > 0 -> tr("أكمل الفحص ($remaining متبقية)", "Continue ($remaining left)")
            else -> tr("أعد الفحص من البداية", "Start over")
        }
        return if (onDark) pill(label, Color.WHITE, PETROL, filled = true) { runAll() }
        else pill(label, PETROL, Color.WHITE, filled = true) { runAll() }
    }

    // ---------- الاختبارات ----------
    private fun testsTab() {
        pageHeader(
            tr("الاختبارات", "Tests"),
            tr("${Results.map.size} من ${Test.values().size} مكتملة · اضغط أي اختبار لتشغيله لحاله", "${Results.map.size} of ${Test.values().size} done · tap any test to run it alone")
        )
        val b = body()
        b.addView(runButton(onDark = false), LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(14) })
        for (g in TEST_GROUPS) {
            b.addView(sectionHeading(g.name, "${g.tests.count { it in Results.map }}/${g.tests.size}"))
            b.addView(testGroup(g.tests), blockParams())
        }
    }

    // ---------- التقرير ----------
    private fun reportTab() {
        pageHeader(tr("التقرير", "Report"), tr("الحالة الخارجية وملف الاستخدام وإنشاء التقرير", "Condition, usage profile and report"))
        val b = body()
        val flags = RedFlags.compute(snapshot)
        if (flags.isNotEmpty()) b.addView(flagsBlock(flags), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        b.addView(sectionHeading(tr("إنشاء التقرير", "Create report"), null))
        b.addView(reportBlock(), blockParams())
        b.addView(sectionHeading(tr("الحالة الخارجية", "Cosmetic condition"), null))
        b.addView(conditionBlock(), blockParams())
        b.addView(sectionHeading(tr("ملف الاستخدام", "Usage profile"), null))
        b.addView(usageBlock(), blockParams())
    }

    private fun usageBlock(): View {
        val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        if (!UsageAnalyzer.hasAccess(this)) {
            box.addView(text(tr(
                "يقرأ سجل استخدام الجوال: من متى مستخدم، ومتوسط الشاشة يومياً، ومستوى الاستخدام، وتوزيعه (ألعاب، فيديو، تواصل…). يعرض فئات ونسب فقط بدون أسماء تطبيقات.",
                "Reads the phone's usage history: how long it has been in use, average daily screen time, usage level and breakdown (games, video, social…). Shows categories and shares only, no app names."
            ), 14f, Fonts.regular, SLATE).apply { setLineSpacing(0f, 1.25f) })
            box.addView(text(tr(
                "ملاحظة: ضبط المصنع يمسح هذا السجل، فأفضل وقت للفحص قبل مسح الجوال.",
                "Note: a factory reset erases this history, so run it before the phone is wiped."
            ), 13f, Fonts.regular, SLATE).apply { setPadding(0, dp(8), 0, 0) })
            box.addView(pill(tr("تفعيل الوصول لبيانات الاستخدام", "Allow usage access"), PETROL, Color.WHITE, filled = true) {
                try {
                    startActivity(UsageAnalyzer.settingsIntent())
                    toast(tr("اختر \"فاحص الجوال\" وفعّل السماح، ثم ارجع", "Select \"Phone Check\", allow access, then come back"))
                } catch (e: Exception) {
                    toast(tr("افتح الإعدادات ← التطبيقات ← الوصول الخاص ← الوصول لبيانات الاستخدام", "Open Settings → Apps → Special access → Usage access"))
                }
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
            return box
        }
        val u = Results.usage
        if (u == null) {
            box.addView(text(tr("جاري تحليل سجل الاستخدام…", "Analyzing usage history…"), 14f, Fonts.medium, SLATE))
            return box
        }
        box.addView(text(u.summary, 16f, Fonts.bold, TEXT).apply { setLineSpacing(0f, 1.25f) })
        if (!u.recentReset) {
            box.addView(statRow(tr("مستخدم منذ", "In use for"), u.inUseText))
            u.avgDailyMin?.let { box.addView(statRow(tr("متوسط الشاشة يومياً", "Daily screen time"), hm(it))) }
            box.addView(statRow(tr("مستوى الاستخدام", "Usage level"), u.intensityText))
            if (u.historyDays > 0) box.addView(statRow(tr("السجل يغطي", "History covers"), tr("${u.historyDays} يوم", "${u.historyDays} days")))
            if (u.shares.isNotEmpty()) {
                box.addView(text(tr("توزيع الاستخدام", "Usage breakdown"), 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(12), 0, dp(6)) })
                for ((cat, pct) in u.shares.take(6)) box.addView(barRow(cat.label, pct, cat.color))
            }
        }
        // إضافة للتقرير
        val inc = Results.usageInReport
        box.addView(TextView(this).apply {
            text = (if (inc) "✓  " else "") + tr("يظهر في التقرير", "Included in report")
            textSize = 14f
            typeface = Fonts.bold
            setTextColor(if (inc) Color.WHITE else TEXT)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                if (inc) setColor(PETROL) else setStroke(dp(1), LINE)
            }
            setOnClickListener {
                Results.usageInReport = !Results.usageInReport
                render()
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        return box
    }

    private fun statRow(label: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, dp(7))
        }
        row.addView(text(label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 14f, Fonts.bold, TEXT).apply { gravity = Gravity.END })
        return row
    }

    private fun barRow(label: String, pct: Int, color: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }
        row.addView(text(label, 13f, Fonts.regular, SLATE), LinearLayout.LayoutParams(dp(112), -2))
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                setColor(0xFFE9EEED.toInt())
                cornerRadius = dp(4).toFloat()
            }
            clipToOutline = true
        }
        val p = pct.coerceIn(0, 100)
        track.addView(View(this).apply {
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(4).toFloat()
            }
        }, LinearLayout.LayoutParams(0, -1, p.toFloat().coerceAtLeast(0.5f)))
        track.addView(View(this), LinearLayout.LayoutParams(0, -1, (100 - p).toFloat().coerceAtLeast(0.01f)))
        row.addView(track, LinearLayout.LayoutParams(0, dp(8), 1f))
        row.addView(text("$p%", 13f, Fonts.bold, TEXT).apply {
            gravity = Gravity.END
        }, LinearLayout.LayoutParams(dp(44), -2))
        return row
    }

    private fun hm(min: Int): String =
        if (min >= 60) tr("${min / 60} ساعة ${min % 60} د", "${min / 60}h ${min % 60}m") else tr("$min دقيقة", "$min min")

    // ---------- الجهاز ----------
    private fun deviceTab() {
        val snap = snapshot
        pageHeader(snap?.deviceName ?: tr("الجهاز", "Device"), tr("مواصفات الجهاز وقراءاته الحالية", "Device specs and current readings"))
        val b = body()
        if (snap == null) {
            b.addView(text(tr("تعذّر قراءة معلومات الجهاز.", "Could not read device info."), 14f, Fonts.regular, SLATE).apply { setPadding(dp(4), dp(16), dp(4), 0) })
            return
        }
        b.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
        val specs = surface()
        snap.sections.forEachIndexed { i, s -> specs.addView(specSection(s, i > 0)) }
        b.addView(specs, blockParams())
    }

    // ---------- المزيد ----------
    private fun moreTab() {
        pageHeader(tr("المزيد", "More"), null)
        val b = body()
        b.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
        b.addView(settingsBlock(), blockParams())
    }

    private fun switchLanguage() {
        Lang.set(this, !Lang.en)
        lastReport = null
        recreate()
    }

    /** زر صغير شفاف فوق الخلفية البترولية */
    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        typeface = Fonts.medium
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), LIGHT)
        }
        setOnClickListener { onClick() }
    }

    private fun sectionHeading(title: String, trailing: String?): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(4), dp(26), dp(4), dp(10))
        }
        row.addView(text(title, 18f, Fonts.bold, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) row.addView(text(trailing, 13f, Fonts.medium, SLATE))
        return row
    }

    private fun testGroup(tests: List<Test>): View {
        val box = surface()
        tests.forEachIndexed { i, t ->
            if (i > 0) box.addView(divider(dp(56)))
            box.addView(testRow(t))
        }
        return box
    }

    private fun testRow(t: Test): View {
        val r = Results.map[t]
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setBackgroundResource(rippleRes())
            setOnClickListener {
                queue.clear()
                start(t)
            }
        }
        row.addView(statusMark(r), LinearLayout.LayoutParams(dp(28), dp(28)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text(t.title, 15f, Fonts.medium, TEXT))
        Results.details[t]?.let { titles.addView(text(it, 12f, Fonts.regular, SLATE)) }
        row.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        row.addView(
            if (r == null) text(tr("ابدأ", "Start"), 14f, Fonts.bold, PETROL)
            else text(tr("إعادة", "Retest"), 14f, Fonts.medium, SLATE)
        )
        return row
    }

    private fun statusMark(r: Boolean?): View = TextView(this).apply {
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Fonts.bold
        includeFontPadding = false
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            when (r) {
                true -> setColor(PASS_BG)
                false -> setColor(FAIL_BG)
                null -> {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), LINE)
                }
            }
        }
        when (r) {
            true -> {
                text = "✓"
                setTextColor(GREEN)
            }
            false -> {
                text = "✕"
                setTextColor(RED)
            }
            null -> text = ""
        }
    }

    /** الحالة الخارجية: الهيكل والشاشة وملاحظات، تدخل في التقرير */
    private fun conditionBlock(): View {
        val box = surface().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
        box.addView(text(tr("حدّد حالة الجوال من الخارج بعينك، وتظهر في التقرير.", "Rate the outside of the phone by eye. It appears in the report."), 13f, Fonts.regular, SLATE))

        fun condRow(title: String, current: Cond?, set: (Cond?) -> Unit) {
            box.addView(text(title, 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(14), 0, dp(8)) })
            val wrap = FlowRow(this)
            for (c in Cond.values()) {
                val selected = c == current
                wrap.addView(TextView(this).apply {
                    text = c.label
                    textSize = 13f
                    typeface = if (selected) Fonts.bold else Fonts.medium
                    setTextColor(if (selected) Color.WHITE else TEXT)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(18).toFloat()
                        if (selected) setColor(PETROL) else setStroke(dp(1), LINE)
                    }
                    setOnClickListener {
                        set(if (selected) null else c)
                        render()
                    }
                })
            }
            box.addView(wrap, LinearLayout.LayoutParams(-1, -2))
        }
        condRow(tr("الهيكل والإطار", "Body & frame"), Results.body) { Results.body = it }
        condRow(tr("زجاج الشاشة", "Screen glass"), Results.screen) { Results.screen = it }

        box.addView(text(tr("ملاحظات", "Notes"), 14f, Fonts.medium, TEXT).apply { setPadding(0, dp(14), 0, dp(8)) })
        val notes = EditText(this).apply {
            setText(Results.notes)
            hint = tr("مثلاً: البطارية مغيّرة، فيه ضمان لين 2027، الكرتون موجود…", "e.g. battery replaced, warranty until 2027, box included…")
            textSize = 14f
            typeface = Fonts.regular
            setTextColor(TEXT)
            setHintTextColor(GRAY)
            minLines = 2
            gravity = Gravity.TOP or Gravity.START
            textDirection = Lang.textDir
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), LINE)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    Results.notes = s?.toString().orEmpty().take(400)
                }
            })
        }
        box.addView(notes, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun reportBlock(): View {
        val box = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        box.addView(
            text(
                tr(
                    "ملف PDF بشعار الشركة، فيه رقم تقرير والتقييم ونتيجة كل اختبار والحالة الخارجية ومواصفات الجهاز. ينحفظ في السجل تلقائياً.",
                    "A branded PDF with a report number, score, every test result, cosmetic condition and device specs. Saved to History automatically."
                ),
                14f, Fonts.regular, SLATE
            ).apply { setLineSpacing(0f, 1.25f) }
        )
        val btns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        btns.addView(
            pill(tr("عرض التقرير", "View report"), PETROL, Color.WHITE, filled = true) { openReport(false) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
        )
        btns.addView(
            pill(tr("مشاركة", "Share"), PETROL, PETROL, filled = false) { openReport(true) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
        )
        box.addView(btns)
        return box
    }

    private fun settingsBlock(): View {
        val box = surface()
        fun item(title: String, value: String, onClick: () -> Unit) {
            if (box.childCount > 0) box.addView(divider(dp(16)))
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(15), dp(16), dp(15))
                setBackgroundResource(rippleRes())
                setOnClickListener { onClick() }
            }
            row.addView(text(title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(value, 14f, Fonts.regular, SLATE))
            box.addView(row)
        }
        item(tr("اللغة", "Language"), if (Lang.en) "English" else "العربية") { switchLanguage() }
        item(tr("فحص جوال ثاني", "Inspect another phone"), "") {
            startActivity(Intent(this, RemoteActivity::class.java))
        }
        item(tr("سجل الفحوصات", "Inspection history"), History.all(this).size.toString()) {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        item(tr("سياسة الخصوصية", "Privacy policy"), "") { openUrl(PRIVACY_URL + if (Lang.en) "?lang=en" else "") }
        item(tr("الإصدار", "Version"), versionName()) {}
        return box
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    private fun specSection(s: InfoSection, divider: Boolean): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (divider) wrap.addView(divider(dp(16)))
        val open = s.title in expanded
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundResource(rippleRes())
            setOnClickListener {
                if (open) expanded.remove(s.title) else expanded.add(s.title)
                render()
            }
        }
        head.addView(text(s.title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(text(if (open) tr("إخفاء", "Hide") else tr("${s.items.size} بنود", "${s.items.size} items"), 13f, Fonts.regular, SLATE))
        head.addView(text(if (open) "▴" else "▾", 14f, Fonts.regular, SLATE).apply { setPaddingRelative(dp(8), 0, 0, 0) })
        wrap.addView(head)
        if (open) {
            val list = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), 0, dp(16), dp(10))
            }
            for (item in s.items) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(7), 0, dp(7))
                }
                row.addView(text(item.label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(text(item.value, 14f, Fonts.medium, TEXT).apply { gravity = Gravity.END })
                list.addView(row)
            }
            wrap.addView(list)
        }
        return wrap
    }

    // ---------- عناصر مشتركة ----------
    private fun surface(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(20).toFloat()
        }
        clipToOutline = true
    }

    private fun blockParams() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }

    private fun divider(insetStart: Int): View = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { marginStart = insetStart }
    }

    private fun rippleRes(): Int {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun pill(label: String, bg: Int, fg: Int, filled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            textSize = 15f
            typeface = Fonts.bold
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                if (filled) setColor(bg) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), bg)
                }
            }
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

/** يطلب من تطبيق الكاميرا يفتح الأمامية (تدعمه أغلب تطبيقات الكاميرا) */
class FrontPicturePreview : ActivityResultContracts.TakePicturePreview() {
    override fun createIntent(context: Context, input: Void?): Intent =
        super.createIntent(context, input).apply {
            putExtra("android.intent.extras.CAMERA_FACING", 1)
            putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
            putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        }
}
