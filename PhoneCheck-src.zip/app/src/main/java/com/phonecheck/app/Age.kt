package com.phonecheck.app

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * العمر والقدرة: تقييم منفصل عن "الحالة".
 * الحالة = هل القطع سليمة. العمر والقدرة = هل الجوال لسه مناسب للاستخدام اليوم.
 * جوال 2018 سليم ياخذ حالة ممتازة، بس عمره وقدرته "قديم".
 */
data class AgeProfile(
    val launchYear: Int?,          // سنة الإنتاج تقريباً (من إصدار أندرويد اللي نزل فيه)
    val firstAndroid: String?,     // إصدار أندرويد الأصلي
    val currentAndroid: String,
    val patchDate: String?,        // تاريخ آخر تحديث أمني
    val patchAgeMonths: Int?,
    val ramGb: Int,
    val perfClass: Int,            // فئة الأداء الرسمية من أندرويد (0 = غير معلنة)
    val score: Int,                // 0..100
) {
    val level: Int
        get() = when {
            score >= 80 -> 0
            score >= 60 -> 1
            score >= 40 -> 2
            else -> 3
        }

    val label: String
        get() = when (level) {
            0 -> tr("حديث", "Modern")
            1 -> tr("جيد لسنوات", "Good for years")
            2 -> tr("بدأ يقدم", "Ageing")
            else -> tr("قديم", "Old")
        }

    val color: Int
        get() = when (level) {
            0, 1 -> GREEN
            2 -> 0xFFC98A1B.toInt()
            else -> RED
        }

    val supportText: String
        get() = when {
            patchAgeMonths == null -> tr("غير معروف", "Unknown")
            patchAgeMonths <= 6 -> tr("يستقبل تحديثات أمنية ✓", "Receiving security updates ✓")
            patchAgeMonths <= 12 -> tr("التحديثات متأخرة", "Updates are behind")
            else -> tr("توقف الدعم غالباً ⚠", "Probably no longer supported ⚠")
        }

    val advice: String
        get() = when (level) {
            0 -> tr("مناسب لكل الاستخدامات، حتى الألعاب الثقيلة.", "Suitable for everything, including heavy games.")
            1 -> tr("مناسب للاستخدام اليومي لسنوات قادمة.", "Good for daily use for years to come.")
            2 -> tr("مناسب للاستخدام اليومي، بس الألعاب والتطبيقات الثقيلة ممكن تتعبه.", "Fine for daily use, but heavy games and apps may struggle.")
            else -> tr("مناسب للاستخدام الخفيف فقط، والتطبيقات الجديدة ممكن تكون بطيئة عليه.", "Suitable for light use only; new apps may run slowly.")
        } + if ((patchAgeMonths ?: 0) > 12) tr(
            " ما يستقبل تحديثات أمنية، فالأفضل ما تعتمد عليه في التطبيقات البنكية.",
            " It no longer gets security updates, so avoid relying on it for banking apps."
        ) else ""

    /** سطر مختصر: قديم · إنتاج 2018 تقريباً */
    val summary: String
        get() = label + (launchYear?.let { tr(" · إنتاج $it تقريباً", " · made around $it") } ?: "")
}

object AgeAnalyzer {

    /** إصدار أندرويد ← سنة نزول الجوالات فيه تقريباً */
    private val YEAR_BY_API = mapOf(
        21 to 2015, 22 to 2015, 23 to 2016, 24 to 2016, 25 to 2017, 26 to 2017, 27 to 2018,
        28 to 2018, 29 to 2019, 30 to 2020, 31 to 2021, 32 to 2022, 33 to 2022, 34 to 2023,
        35 to 2024, 36 to 2025, 37 to 2026,
    )
    private val NAME_BY_API = mapOf(
        21 to "5.0", 22 to "5.1", 23 to "6", 24 to "7", 25 to "7.1", 26 to "8", 27 to "8.1",
        28 to "9", 29 to "10", 30 to "11", 31 to "12", 32 to "12L", 33 to "13", 34 to "14",
        35 to "15", 36 to "16", 37 to "17",
    )

    fun analyze(ctx: Context): AgeProfile {
        val firstApi = listOf("ro.product.first_api_level", "ro.board.first_api_level", "ro.vendor.api_level")
            .firstNotNullOfOrNull { DeviceInfo.prop(it)?.toIntOrNull()?.takeIf { v -> v in 16..40 } }
        val year = firstApi?.let { YEAR_BY_API[it] }
        val now = Calendar.getInstance()
        val thisYear = now.get(Calendar.YEAR)

        val patch = Build.VERSION.SECURITY_PATCH.takeIf { it.isNotBlank() }
        val patchMonths = patch?.let {
            try {
                val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(it)
                if (d == null) null else {
                    val c = Calendar.getInstance().apply { time = d }
                    ((now.get(Calendar.YEAR) - c.get(Calendar.YEAR)) * 12 + now.get(Calendar.MONTH) - c.get(Calendar.MONTH))
                        .coerceAtLeast(0)
                }
            } catch (e: Exception) {
                null
            }
        }

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        // الرام المعلنة أكبر شوي من اللي يشوفه النظام، فنقرّب لأقرب رقم
        val ramGb = (mi.totalMem / 1_073_741_824.0).let { kotlin.math.ceil(it - 0.3).toInt().coerceAtLeast(1) }
        val perfClass = if (Build.VERSION.SDK_INT >= 31) Build.VERSION.MEDIA_PERFORMANCE_CLASS else 0

        // العمر (40 نقطة)
        val ageYears: Int? = year?.let { thisYear - it }
        val agePts = if (ageYears == null) 20 else when {
            ageYears <= 1 -> 40
            ageYears == 2 -> 34
            ageYears == 3 -> 28
            ageYears == 4 -> 20
            ageYears == 5 -> 12
            else -> 5
        }
        // الدعم بالتحديثات (30 نقطة)
        val m: Int? = patchMonths
        val supportPts = if (m == null) 15 else when {
            m <= 3 -> 30
            m <= 6 -> 25
            m <= 12 -> 18
            m <= 24 -> 8
            else -> 0
        }
        // القدرة (30 نقطة): الرام + فئة الأداء الرسمية
        val ramPts = when {
            ramGb >= 8 -> 15
            ramGb >= 6 -> 12
            ramGb >= 4 -> 8
            ramGb >= 3 -> 4
            else -> 1
        }
        val classPts = when {
            perfClass >= 33 -> 15
            perfClass >= 31 -> 12
            perfClass >= 30 -> 9
            else -> 5
        }
        val score = (agePts + supportPts + ramPts + classPts).coerceIn(0, 100)

        return AgeProfile(
            launchYear = year,
            firstAndroid = firstApi?.let { NAME_BY_API[it] ?: "API $it" },
            currentAndroid = Build.VERSION.RELEASE,
            patchDate = patch,
            patchAgeMonths = patchMonths,
            ramGb = ramGb,
            perfClass = perfClass,
            score = score,
        )
    }

    fun items(a: AgeProfile): List<InfoItem> = buildList {
        add(InfoItem(tr("التقييم", "Rating"), "${a.label} (${a.score}/100)"))
        a.launchYear?.let { add(InfoItem(tr("سنة الإنتاج", "Year made"), tr("$it تقريباً", "around $it"))) }
        a.firstAndroid?.let { add(InfoItem(tr("نزل بأندرويد", "Launched with Android"), it)) }
        add(InfoItem(tr("أندرويد الحالي", "Current Android"), a.currentAndroid))
        add(InfoItem(tr("آخر تحديث أمني", "Last security patch"), a.patchDate ?: tr("غير معروف", "Unknown")))
        add(InfoItem(tr("الدعم", "Support"), a.supportText))
        add(InfoItem(tr("الرام", "RAM"), "${a.ramGb} GB"))
        if (a.perfClass > 0) add(InfoItem(tr("فئة الأداء الرسمية", "Performance class"), "${a.perfClass}"))
    }
}
