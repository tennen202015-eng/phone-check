package com.phonecheck.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** اختبار الألوان: كشف البكسلات الميتة والخطوط والبقع */
class ColorTestActivity : AppCompatActivity() {

    private val colors = intArrayOf(
        Color.RED, Color.GREEN, Color.BLUE, Color.WHITE, Color.BLACK, Color.rgb(128, 128, 128)
    )
    private var idx = -1
    private lateinit var screen: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screen = TextView(this).apply {
            text = tr("اضغط على الشاشة لتغيير اللون\n\nدقّق في كل لون:\nهل فيه نقاط ميتة أو خطوط أو بقع؟\n\nللإيقاف اضغط رجوع", "Tap the screen to change color\n\nCheck each color carefully:\nany dead pixels, lines or spots?\n\nPress Back to stop")
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setOnClickListener { nextColor() }
        }
        setContentView(screen)
        goFullscreen()
    }

    private fun nextColor() {
        idx++
        if (idx >= colors.size) {
            askResult()
            return
        }
        screen.text = ""
        screen.setBackgroundColor(colors[idx])
    }

    private fun askResult() {
        PcDialog(this)
            .setTitle(Test.DISPLAY.title)
            .setMessage(tr("هل لاحظت نقاط ميتة أو خطوط أو بقع أو اختلاف في الألوان؟", "Did you notice dead pixels, lines, spots or uneven colors?"))
            .setCancelable(false)
            .setPositiveButton(tr("لا، سليمة", "No, looks fine")) { _, _ ->
                setResult(RESULT_OK)
                finish()
            }
            .setNegativeButton(tr("نعم، فيه مشكلة", "Yes, there is an issue")) { _, _ ->
                setResult(RESULT_FIRST_USER)
                finish()
            }
            .setNeutralButton(tr("إعادة", "Repeat")) { _, _ ->
                idx = -1
                nextColor()
            }
            .show()
    }
}
