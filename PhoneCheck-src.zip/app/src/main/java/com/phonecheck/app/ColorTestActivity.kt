package com.phonecheck.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** اختبار الألوان: كشف البكسلات الميتة والخطوط والبقع */
class ColorTestActivity : AppCompatActivity() {

    private val colors = intArrayOf(
        Color.RED, Color.GREEN, Color.BLUE, Color.WHITE, Color.BLACK, Color.rgb(128, 128, 128)
    )
    private var idx = -1
    private lateinit var screen: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screen = TextView(this).apply {
            text = "اضغط على الشاشة لتغيير اللون\n\nدقّق في كل لون:\nهل فيه نقاط ميتة أو خطوط أو بقع؟"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setOnClickListener { nextColor() }
        }
        setContentView(screen)
        goFullscreen()
    }

    private fun nextColor() {
        idx++
        if (idx >= colors.size) {
            askResult()
            return
        }
        screen.text = ""
        screen.setBackgroundColor(colors[idx])
    }

    private fun askResult() {
        AlertDialog.Builder(this)
            .setTitle("ألوان الشاشة")
            .setMessage("هل لاحظت نقاط ميتة أو خطوط أو بقع أو اختلاف في الألوان؟")
            .setCancelable(false)
            .setPositiveButton("لا، سليمة") { _, _ ->
                setResult(RESULT_OK)
                finish()
            }
            .setNegativeButton("نعم، فيه مشكلة") { _, _ ->
                setResult(RESULT_FIRST_USER)
                finish()
            }
            .setNeutralButton("إعادة") { _, _ ->
                idx = -1
                nextColor()
            }
            .show()
    }
}
