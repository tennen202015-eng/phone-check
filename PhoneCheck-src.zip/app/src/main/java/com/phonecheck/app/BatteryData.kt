package com.phonecheck.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/** نتيجة نشاط البطارية لما الحكم "غير محدد" */
const val RESULT_UNDETERMINED = 2

/** مصدر السعة الأصلية للبطارية */
enum class CapSource { TABLE, SYSTEM, MANUAL }

/** من وين جت نسبة الصحة */
enum class HealthSource { MANUFACTURER, SYSTEM_FILES, MEASURED, CYCLES }

/** قدرات القياس اللي يسمح فيها الجوال (نكتشفها قبل الفحص) */
data class BatteryCaps(
    val currentOk: Boolean,          // قراءة التيار اللحظي
    val chargeCounterOk: Boolean,    // عدّاد الشحن
    val sysVoltage: Boolean,         // قراءة الجهد من ملفات النظام (لحظية)
    val voltUpdates: Int,            // كم مرة تغيّر الجهد في البث أثناء الفحص المبدئي
    val cycles: Int?,
    val oemHealth: Int?,             // صحة البطارية من الشركة المصنعة (أندرويد 14+ وبعض الأجهزة)
    val mfgDate: Long?,              // تاريخ تصنيع البطارية
    val firstUse: Long?,             // تاريخ أول استخدام
    val sysFullMah: Int?,            // السعة الكاملة الحالية من ملفات النظام
    val sysDesignMah: Int?,          // السعة الأصلية من ملفات النظام
    val sysAsoc: Int?,               // نسبة الصحة من ملفات سامسونج
    val raw: String,                 // نص التشخيص الخام
) {
    val directHealth: Int?
        get() = oemHealth ?: sysAsoc ?: run {
            if (sysFullMah != null && sysDesignMah != null && sysDesignMah > 0)
                (sysFullMah * 100.0 / sysDesignMah).roundToInt().coerceIn(1, 100) else null
        }
}

/** نتيجة فحص البطارية العميق */
data class BatteryReport(
    val healthPct: Int?,
    val healthMargin: Int?,           // ± هامش الخطأ
    val healthSource: HealthSource?,
    val confidence: Int,              // 0 منخفضة، 1 متوسطة، 2 عالية، 3 عالية جداً (من المصنع)
    val provisional: Boolean,         // حكم مبدئي لأن البيانات قليلة
    val measuredMah: Int?,            // السعة المقاسة أثناء الشحن
    val dischargeMah: Int?,           // السعة المقاسة أثناء التفريغ (تأكيد)
    val segmentsAgree: Boolean?,      // نصفين القياس متفقين
    val designMah: Int?,
    val designSource: CapSource?,
    val method: Int,                  // 0 عداد الشحن، 1 تكامل التيار، -1 لا يوجد
    val levelDelta: Int,
    val cycles: Int?,
    val irMohm: Int?,
    val irNote: String,
    val maxTempC: Float?,
    val maxChargeMa: Int?,
    val swollen: Boolean,
    val verdict: Int,                 // -1 غير محدد، 0 ممتازة، 1 جيدة، 2 مقبولة، 3 تحتاج تغيير، 4 خطر
    val mfgDate: Long?,
    val firstUse: Long?,
    val capsSummary: List<Pair<String, Boolean>>,
    val missing: List<String> = emptyList(),   // ليش ما قدرنا نحدد الحكم
) {
    val determined: Boolean get() = verdict >= 0

    val confidenceText: String
        get() = when (confidence) {
            3 -> tr("ثقة عالية جداً (من الشركة المصنعة)", "Very high confidence (manufacturer data)")
            2 -> tr("ثقة عالية", "High confidence")
            1 -> tr("ثقة متوسطة", "Medium confidence")
            else -> tr("ثقة منخفضة", "Low confidence")
        }

    val verdictText: String
        get() = when (verdict) {
            -1 -> tr("غير محدد: الشروط ما اكتملت", "Undetermined: conditions not met")
            0 -> tr("ممتازة", "Excellent")
            1 -> tr("جيدة", "Good")
            2 -> tr("مقبولة وتضعف", "Fair, weakening")
            3 -> tr("تحتاج تغيير قريب", "Needs replacement soon")
            else -> tr("خطر: لازم تتغير فوراً", "Danger: replace immediately")
        } + if (provisional && verdict in 0..3) tr(" (مبدئي)", " (provisional)") else ""

    val verdictColor: Int
        get() = when (verdict) {
            -1 -> GRAY
            0, 1 -> GREEN
            2 -> 0xFFC98A1B.toInt()
            else -> RED
        }

    val passed: Boolean get() = verdict in 0..2

    val healthText: String?
        get() = healthPct?.let { h -> "$h%" + (healthMargin?.takeIf { it > 0 }?.let { " (±$it%)" } ?: "") }

    val sourceText: String
        get() = when (designSource) {
            CapSource.TABLE -> tr("قاعدة بيانات الموديلات", "model database")
            CapSource.SYSTEM -> tr("النظام", "system")
            CapSource.MANUAL -> tr("إدخال يدوي", "entered manually")
            null -> "-"
        }

    val healthSourceText: String
        get() = when (healthSource) {
            HealthSource.MANUFACTURER -> tr("قراءة الشركة المصنعة", "manufacturer reading")
            HealthSource.SYSTEM_FILES -> tr("ملفات نظام البطارية", "battery system files")
            HealthSource.MEASURED -> tr("قياس فعلي أثناء الشحن", "actual measurement while charging")
            HealthSource.CYCLES -> tr("تقدير من عدد الدورات", "estimate from cycle count")
            null -> tr("غير متاح", "not available")
        }

    /** سطر مختصر تحت اسم الاختبار */
    val summary: String
        get() = if (!determined) tr("غير محدد · أعد الفحص بالشروط", "Undetermined · retest under conditions")
        else (healthText?.let { tr("الصحة $it", "Health $it") + " · " } ?: "") + confidenceText
}

/** قراءات البطارية الخام، مع توحيد الوحدات لأن كل شركة ترجع وحدات مختلفة */
object BatteryProbe {

    /** التيار بالملي أمبير (قيمة مطلقة). بعض الأجهزة ترجع µA وبعضها mA */
    fun currentMa(raw: Int): Int? {
        if (raw == Int.MIN_VALUE || raw == Int.MAX_VALUE || raw == 0) return null
        val a = abs(raw)
        return if (a > 20000) a / 1000 else a
    }

    /** عدّاد الشحن بالميكرو أمبير ساعة */
    fun chargeCounterUah(raw: Int): Long? {
        if (raw == Int.MIN_VALUE || raw == Int.MAX_VALUE || raw <= 0) return null
        return if (raw < 100_000) raw * 1000L else raw.toLong()
    }

    private val voltPaths = listOf(
        "/sys/class/power_supply/battery/voltage_now",
        "/sys/class/power_supply/bms/voltage_now",
        "/sys/class/power_supply/battery/batt_vol",
    )

    /** الجهد بالملي فولت من ملفات النظام لو مسموح (أدق وأسرع تحديث) */
    fun sysVoltageMv(): Int? {
        for (p in voltPaths) {
            val v = readLong(p) ?: continue
            val mv = when {
                v > 1_000_000 -> (v / 1000).toInt()  // µV
                v in 2500..5000 -> v.toInt()         // mV
                else -> null
            }
            if (mv != null && mv in 2500..5000) return mv
        }
        return null
    }

    fun sysCycles(): Int? = firstInt(
        "/sys/class/power_supply/battery/cycle_count",
        "/sys/class/power_supply/bms/cycle_count",
        "/sys/class/power_supply/battery/battery_cycle",
    )?.takeIf { it in 1..5000 }

    /** السعة بالملي أمبير ساعة من ملفات النظام */
    private fun mahFrom(vararg paths: String): Int? {
        for (p in paths) {
            val v = readLong(p) ?: continue
            val mah = if (v > 20000) (v / 1000).toInt() else v.toInt()
            if (mah in 800..15000) return mah
        }
        return null
    }

    fun sysFullMah(): Int? = mahFrom(
        "/sys/class/power_supply/battery/charge_full",
        "/sys/class/power_supply/bms/charge_full",
    )

    fun sysDesignMah(): Int? = mahFrom(
        "/sys/class/power_supply/battery/charge_full_design",
        "/sys/class/power_supply/bms/charge_full_design",
    )

    fun sysAsoc(): Int? = firstInt(
        "/sys/class/power_supply/battery/fg_asoc",
        "/sys/class/power_supply/battery/batt_asoc",
    )?.takeIf { it in 10..100 }

    /**
     * قراءات الشركة المصنعة (أندرويد 14+): صحة البطارية وتاريخ التصنيع وأول استخدام.
     * غالباً محجوبة عن التطبيقات، بس بعض الأجهزة تسمح، فنجرّب بأمان.
     */
    fun oemHealth(bm: BatteryManager): Int? {
        if (Build.VERSION.SDK_INT < 34) return null
        return try {
            bm.getIntProperty(10).takeIf { it in 1..100 } // BATTERY_PROPERTY_STATE_OF_HEALTH
        } catch (e: Throwable) {
            null
        }
    }

    fun oemDate(bm: BatteryManager, id: Int): Long? {
        if (Build.VERSION.SDK_INT < 34) return null
        return try {
            val v = bm.getLongProperty(id) // 7 تاريخ التصنيع، 8 أول استخدام (ثواني)
            val nowSec = System.currentTimeMillis() / 1000
            if (v in 1_420_070_400L..nowSec) v * 1000 else null
        } catch (e: Throwable) {
            null
        }
    }

    private fun firstInt(vararg paths: String): Int? {
        for (p in paths) readLong(p)?.let { return it.toInt() }
        return null
    }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLong()
    } catch (e: Exception) {
        null
    }

    /** فحص مبدئي لقدرات الجوال (ياخذ عينات لمدة قصيرة) */
    fun probe(ctx: Context, samples: List<Int?>, ccSamples: List<Long?>, voltValues: Set<Int>): BatteryCaps {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val cyc34 = if (Build.VERSION.SDK_INT >= 34) bi?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)?.takeIf { it > 0 } else null
        val currentOk = samples.count { it != null } >= 2
        val ccOk = ccSamples.count { it != null } >= 2
        val sysV = sysVoltageMv()
        val caps = BatteryCaps(
            currentOk = currentOk,
            chargeCounterOk = ccOk,
            sysVoltage = sysV != null,
            voltUpdates = voltValues.size,
            cycles = cyc34 ?: sysCycles(),
            oemHealth = oemHealth(bm),
            mfgDate = oemDate(bm, 7),
            firstUse = oemDate(bm, 8),
            sysFullMah = sysFullMah(),
            sysDesignMah = sysDesignMah(),
            sysAsoc = sysAsoc(),
            raw = "",
        )
        val raw = buildString {
            appendLine("model=${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}) sdk=${Build.VERSION.SDK_INT}")
            appendLine("current_now raw=${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)} samples=$samples")
            appendLine("current_avg raw=${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)}")
            appendLine("charge_counter samples=$ccSamples")
            appendLine("capacity_prop=${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}")
            appendLine("broadcast voltages=$voltValues")
            appendLine("sys voltage=$sysV cycles=${caps.cycles} full=${caps.sysFullMah} design=${caps.sysDesignMah} asoc=${caps.sysAsoc}")
            appendLine("oem soh=${caps.oemHealth} mfg=${caps.mfgDate} first=${caps.firstUse}")
            appendLine("status=${bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)} plugged=${bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)} health=${bi?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)}")
            appendLine("design table=${DesignCapacity.fromTable()} system=${DesignCapacity.fromSystem(ctx)} manual=${DesignCapacity.manual(ctx)}")
        }
        return caps.copy(raw = raw)
    }
}

/** السعة الأصلية للبطارية: جدول الموديلات أولاً، ثم النظام، ثم إدخال يدوي */
object DesignCapacity {
    private const val PREFS = "battery"

    // موديلات سامسونج: أول جزء من رقم الموديل (مثل SM-S918) والسعة بالـ mAh
    private val samsung = mapOf(
        "SM-G991" to 4000, "SM-G996" to 4800, "SM-G998" to 5000,
        "SM-S901" to 3700, "SM-S906" to 4500, "SM-S908" to 5000,
        "SM-S911" to 3900, "SM-S916" to 4700, "SM-S918" to 5000,
        "SM-S921" to 4000, "SM-S926" to 4900, "SM-S928" to 5000,
        "SM-N981" to 4300, "SM-N986" to 4500,
        "SM-A525" to 4500, "SM-A526" to 4500, "SM-A528" to 4500,
        "SM-A536" to 5000, "SM-A546" to 5000, "SM-A556" to 5000,
        "SM-A346" to 5000, "SM-A356" to 5000,
        "SM-A145" to 5000, "SM-A146" to 5000, "SM-A155" to 5000, "SM-A156" to 5000,
        "SM-A736" to 5000,
        "SM-F731" to 3700, "SM-F946" to 4400,
    )

    // أجهزة بكسل: الاسم الداخلي (Build.DEVICE)
    private val pixel = mapOf(
        "oriole" to 4614, "raven" to 5003, "bluejay" to 4410,
        "panther" to 4355, "cheetah" to 5000, "lynx" to 4385,
        "shiba" to 4575, "husky" to 5050, "akita" to 4492,
        "tokay" to 4700, "caiman" to 4700, "komodo" to 5060,
    )

    fun fromTable(): Int? {
        pixel[Build.DEVICE.lowercase()]?.let { return it }
        val model = Build.MODEL.uppercase()
        return samsung.entries.firstOrNull { model.startsWith(it.key) }?.value
    }

    fun fromSystem(ctx: Context): Int? = try {
        val cls = Class.forName("com.android.internal.os.PowerProfile")
        val obj = cls.getConstructor(Context::class.java).newInstance(ctx)
        val v = (cls.getMethod("getBatteryCapacity").invoke(obj) as Double).toInt()
        // قيم مثل 1000 أو 3000 بالضبط غالباً قيم افتراضية مو حقيقية
        if (v in 1500..10000 && v != 3000) v else null
    } catch (e: Throwable) {
        null
    }

    fun manual(ctx: Context): Int? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("manual_" + Build.MODEL, 0).takeIf { it > 0 }

    fun setManual(ctx: Context, mah: Int?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
            if (mah == null) remove("manual_" + Build.MODEL) else putInt("manual_" + Build.MODEL, mah)
        }.apply()
    }

    fun resolve(ctx: Context): Pair<Int, CapSource>? {
        manual(ctx)?.let { return it to CapSource.MANUAL }
        fromTable()?.let { return it to CapSource.TABLE }
        fromSystem(ctx)?.let { return it to CapSource.SYSTEM }
        return null
    }
}
