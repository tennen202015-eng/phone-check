package com.phonecheck.app

import android.content.Context
import android.os.Build
import java.io.File

/** مصدر السعة الأصلية للبطارية */
enum class CapSource { TABLE, SYSTEM, MANUAL }

/** نتيجة فحص البطارية العميق */
data class BatteryReport(
    val healthPct: Int?,          // الصحة المقاسة %
    val confidence: Int,          // 0 منخفضة، 1 متوسطة، 2 عالية
    val measuredMah: Int?,        // السعة الفعلية المقاسة
    val designMah: Int?,          // السعة الأصلية
    val designSource: CapSource?,
    val method: Int,              // 0 عداد الشحن، 1 تكامل التيار، 2 تقدير من الدورات، -1 لا يوجد
    val levelDelta: Int,          // كم نسبة شحن انقاست
    val cycles: Int?,
    val irMohm: Int?,             // المقاومة الداخلية بالملي أوم
    val maxTempC: Float?,
    val swollen: Boolean,
    val verdict: Int,             // 0 ممتازة، 1 جيدة، 2 مقبولة، 3 تحتاج تغيير، 4 خطر
) {
    val confidenceText: String
        get() = when (confidence) {
            2 -> tr("ثقة عالية", "High confidence")
            1 -> tr("ثقة متوسطة", "Medium confidence")
            else -> tr("ثقة منخفضة", "Low confidence")
        }

    val verdictText: String
        get() = when (verdict) {
            0 -> tr("ممتازة", "Excellent")
            1 -> tr("جيدة", "Good")
            2 -> tr("مقبولة وتضعف", "Fair, weakening")
            3 -> tr("تحتاج تغيير قريب", "Needs replacement soon")
            else -> tr("خطر: لازم تتغير فوراً", "Danger: replace immediately")
        }

    val verdictColor: Int
        get() = when (verdict) {
            0, 1 -> GREEN
            2 -> 0xFFC98A1B.toInt()
            else -> RED
        }

    val passed: Boolean get() = verdict <= 2

    val sourceText: String
        get() = when (designSource) {
            CapSource.TABLE -> tr("قاعدة بيانات الموديلات", "model database")
            CapSource.SYSTEM -> tr("النظام", "system")
            CapSource.MANUAL -> tr("إدخال يدوي", "entered manually")
            null -> "-"
        }

    val methodText: String
        get() = when (method) {
            0 -> tr("عدّاد الشحن أثناء الشحن", "charge counter while charging")
            1 -> tr("قياس التيار أثناء الشحن", "current integration while charging")
            2 -> tr("تقدير من عدد الدورات", "estimate from cycle count")
            else -> tr("غير متاح", "not available")
        }

    /** سطر مختصر تحت اسم الاختبار */
    val summary: String
        get() = (healthPct?.let { tr("الصحة $it%", "Health $it%") + " · " } ?: "") + confidenceText
}

/** قراءات البطارية الخام، مع توحيد الوحدات لأن كل شركة ترجع وحدات مختلفة */
object BatteryProbe {

    /** التيار بالملي أمبير (قيمة مطلقة). بعض الأجهزة ترجع µA وبعضها mA */
    fun currentMa(raw: Int): Int? {
        if (raw == Int.MIN_VALUE || raw == 0) return null
        val a = kotlin.math.abs(raw)
        return if (a > 20000) a / 1000 else a
    }

    /** عدّاد الشحن بالميكرو أمبير ساعة */
    fun chargeCounterUah(raw: Int): Long? {
        if (raw == Int.MIN_VALUE || raw <= 0) return null
        return if (raw < 100_000) raw * 1000L else raw.toLong()
    }

    /** الجهد بالملي فولت من ملفات النظام لو مسموح (أدق وأسرع تحديث) */
    fun sysVoltageMv(): Int? = readInt("/sys/class/power_supply/battery/voltage_now")?.let {
        when {
            it > 1_000_000 -> it / 1000   // µV
            it in 2500..5000 -> it        // mV
            else -> null
        }
    }

    fun sysCycles(): Int? =
        (readInt("/sys/class/power_supply/battery/cycle_count")
            ?: readInt("/sys/class/power_supply/battery/battery_cycle"))?.takeIf { it in 1..5000 }

    private fun readInt(path: String): Int? = try {
        File(path).readText().trim().toLong().toInt()
    } catch (e: Exception) {
        null
    }
}

/** السعة الأصلية للبطارية: جدول الموديلات أولاً، ثم النظام، ثم إدخال يدوي */
object DesignCapacity {
    private const val PREFS = "battery"

    // موديلات سامسونج: أول جزء من رقم الموديل (مثل SM-S918) والسعة بالـ mAh
    private val samsung = mapOf(
        "SM-G991" to 4000, "SM-G996" to 4800, "SM-G998" to 5000,
        "SM-S901" to 3700, "SM-S906" to 4500, "SM-S908" to 5000,
        "SM-S911" to 3900, "SM-S916" to 4700, "SM-S918" to 5000,
        "SM-S921" to 4000, "SM-S926" to 4900, "SM-S928" to 5000,
        "SM-N981" to 4300, "SM-N986" to 4500,
        "SM-A525" to 4500, "SM-A526" to 4500, "SM-A528" to 4500,
        "SM-A536" to 5000, "SM-A546" to 5000, "SM-A556" to 5000,
        "SM-A346" to 5000, "SM-A356" to 5000,
        "SM-A145" to 5000, "SM-A146" to 5000, "SM-A155" to 5000, "SM-A156" to 5000,
        "SM-A736" to 5000,
        "SM-F731" to 3700, "SM-F946" to 4400,
    )

    // أجهزة بكسل: الاسم الداخلي (Build.DEVICE)
    private val pixel = mapOf(
        "oriole" to 4614, "raven" to 5003, "bluejay" to 4410,
        "panther" to 4355, "cheetah" to 5000, "lynx" to 4385,
        "shiba" to 4575, "husky" to 5050, "akita" to 4492,
        "tokay" to 4700, "caiman" to 4700, "komodo" to 5060,
    )

    fun fromTable(): Int? {
        pixel[Build.DEVICE.lowercase()]?.let { return it }
        val model = Build.MODEL.uppercase()
        return samsung.entries.firstOrNull { model.startsWith(it.key) }?.value
    }

    fun fromSystem(ctx: Context): Int? = try {
        val cls = Class.forName("com.android.internal.os.PowerProfile")
        val obj = cls.getConstructor(Context::class.java).newInstance(ctx)
        val v = (cls.getMethod("getBatteryCapacity").invoke(obj) as Double).toInt()
        // قيم مثل 1000 أو 3000 بالضبط غالباً قيم افتراضية مو حقيقية
        if (v in 1500..10000 && v != 3000) v else null
    } catch (e: Throwable) {
        null
    }

    fun manual(ctx: Context): Int? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("manual_" + Build.MODEL, 0).takeIf { it > 0 }

    fun setManual(ctx: Context, mah: Int?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
            if (mah == null) remove("manual_" + Build.MODEL) else putInt("manual_" + Build.MODEL, mah)
        }.apply()
    }

    fun resolve(ctx: Context): Pair<Int, CapSource>? {
        manual(ctx)?.let { return it to CapSource.MANUAL }
        fromTable()?.let { return it to CapSource.TABLE }
        fromSystem(ctx)?.let { return it to CapSource.SYSTEM }
        return null
    }
}
