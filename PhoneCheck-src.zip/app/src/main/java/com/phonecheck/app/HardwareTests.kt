package com.phonecheck.app

import android.app.ActivityManager
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.appcompat.app.AlertDialog
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** نتيجة اختبار الرام */
data class RamReport(
    val testedMb: Int,
    val errors: Int,
    val writeMbs: Int,
    val totalMb: Int,
    val availMb: Int,
) {
    val passed: Boolean get() = errors == 0 && testedMb >= 64
    val summary: String
        get() = tr("فحص $testedMb MB · أخطاء $errors · $writeMbs MB/s", "Tested $testedMb MB · $errors errors · $writeMbs MB/s")
}

// ---------------- الرام ----------------
/**
 * نحجز جزء كبير من الرام ونكتب فيه أنماط مختلفة ثم نتأكد إنها رجعت صحيحة.
 * أي خطأ = رام معطوبة (تسبب تهنيج وقفلات تطبيقات وإعادة تشغيل).
 */
internal fun MainActivity.testRam() {
    val dlg = PcDialog(this)
        .setTitle(Test.RAM.title)
        .setMessage(tr("جاري فحص الرام: كتابة أنماط والتأكد منها… (10-20 ثانية)", "Checking RAM: writing and verifying patterns… (10-20 seconds)"))
        .setCancelable(false)
        .show()
    var cancelled = false
    cleanup = { cancelled = true }
    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    Thread {
        val rt = Runtime.getRuntime()
        val blockInts = 2 * 1024 * 1024 // 8 MB لكل قطعة
        val blocks = mutableListOf<IntArray>()
        val budget = (rt.maxMemory() * 0.6 - (rt.totalMemory() - rt.freeMemory())).toLong().coerceAtMost(768L * 1024 * 1024)
        var errors = 0
        var writeNs = 0L
        var bytesWritten = 0L
        try {
            while (!cancelled && (blocks.size + 1L) * blockInts * 4 < budget) {
                blocks += IntArray(blockInts)
            }
        } catch (e: OutOfMemoryError) {
            // نوقف الحجز عند الحد
        }
        // 4 تمريرات: نمط متغير، عكسه، أصفار وواحدات متبادلة، وعكسها
        val seeds = intArrayOf(0x5A5A5A5A, -0x5A5A5A5B, 0x00FF00FF, -0xFF0100)
        for (seed in seeds) {
            if (cancelled) break
            val t0 = SystemClock.elapsedRealtimeNanos()
            for ((b, arr) in blocks.withIndex()) {
                var v = seed xor (b * 0x9E3779B1.toInt())
                for (i in arr.indices) {
                    arr[i] = v
                    v = v * 1103515245 + 12345
                }
            }
            writeNs += SystemClock.elapsedRealtimeNanos() - t0
            bytesWritten += blocks.size.toLong() * blockInts * 4
            for ((b, arr) in blocks.withIndex()) {
                var v = seed xor (b * 0x9E3779B1.toInt())
                for (i in arr.indices) {
                    if (arr[i] != v) errors++
                    v = v * 1103515245 + 12345
                }
            }
        }
        val testedMb = blocks.size * 8
        blocks.clear()
        val mbs = if (writeNs > 0) (bytesWritten / 1048576.0 / (writeNs / 1e9)).roundToInt() else 0
        val report = RamReport(
            testedMb = testedMb,
            errors = errors,
            writeMbs = mbs,
            totalMb = (mi.totalMem / 1048576).toInt(),
            availMb = (mi.availMem / 1048576).toInt(),
        )
        runOnUiThread {
            if (isFinishing || cancelled) return@runOnUiThread
            dlg.dismiss()
            val msg = when {
                report.testedMb < 64 -> tr("ما قدرنا نحجز مساحة كافية من الرام للفحص. سكّر التطبيقات وأعد المحاولة.", "Could not reserve enough RAM for the test. Close other apps and retry.")
                report.errors > 0 -> tr(
                    "الرام فيها عطل ✗\nلقينا ${report.errors} خطأ في ${report.testedMb} MB.\nهذا يسبب تهنيج وقفل تطبيقات وإعادة تشغيل.",
                    "RAM is faulty ✗\nFound ${report.errors} errors in ${report.testedMb} MB.\nThis causes lag, app crashes and restarts."
                )
                else -> tr(
                    "الرام سليمة ✓\nفحصنا ${report.testedMb} MB بدون أي خطأ.\nالسرعة: ${report.writeMbs} MB/s\nالرام الكلية: ${report.totalMb} MB",
                    "RAM OK ✓\nTested ${report.testedMb} MB with no errors.\nSpeed: ${report.writeMbs} MB/s\nTotal RAM: ${report.totalMb} MB"
                )
            }
            PcDialog(this)
                .setTitle(Test.RAM.title)
                .setMessage(msg + tr(
                    "\n\nملاحظة: التطبيق يقدر يفحص الجزء المسموح له من الرام فقط.",
                    "\n\nNote: an app can only test the part of RAM it is allowed to use."
                ))
                .setCancelable(false)
                .setPositiveButton(tr("تمام", "OK")) { _, _ ->
                    if (report.testedMb < 64) {
                        skip()
                    } else {
                        Results.ram = report
                        Results.details[Test.RAM] = report.summary
                        record(Test.RAM, report.passed)
                    }
                }
                .setNeutralButton(tr("إعادة", "Retry")) { _, _ -> testRam() }
                .show()
        }
    }.start()
}

// ---------------- حساس الإضاءة ----------------
internal fun MainActivity.testLight() {
    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val light = sm.getDefaultSensor(Sensor.TYPE_LIGHT)
    if (light == null) {
        toast(tr("الجهاز ما فيه حساس إضاءة", "This device has no light sensor"))
        skip()
        return
    }
    var minL = Float.MAX_VALUE
    var maxL = 0f
    var now = -1f
    var finished = false
    lateinit var dlg: AlertDialog

    fun msg() = tr(
        "غطِّ أعلى الشاشة (جنب الكاميرا الأمامية) بيدك، وبعدين ارفعها ووجّه الجوال للضوء.\n\nالقراءة الآن: ",
        "Cover the top of the screen (near the front camera) with your hand, then uncover it and face a light.\n\nCurrent reading: "
    ) + (if (now < 0) "…" else "${now.roundToInt()} lux")

    val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (finished) return
            now = e.values[0]
            if (now < minL) minL = now
            if (now > maxL) maxL = now
            dlg.setMessage(msg())
            // لازم يتغير فعلاً بين ظلام وضوء، مو مجرد تذبذب بسيط
            if (maxL - minL >= 30f && minL <= maxL * 0.25f) {
                finished = true
                sm.unregisterListener(this)
                dlg.dismiss()
                Results.details[Test.LIGHT] = "${minL.roundToInt()} → ${maxL.roundToInt()} lux"
                record(Test.LIGHT, true)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    dlg = PcDialog(this)
        .setTitle(Test.LIGHT.title)
        .setMessage(msg())
        .setCancelable(false)
        .setNegativeButton(tr("ما تتغير القراءة", "Reading doesn't change")) { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            record(Test.LIGHT, false)
        }
        .setNeutralButton(tr("تخطّي", "Skip")) { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            skip()
        }
        .show()
    cleanup = {
        finished = true
        sm.unregisterListener(listener)
    }
    sm.registerListener(listener, light, SensorManager.SENSOR_DELAY_UI)
}

// ---------------- البوصلة ----------------
/** لازم الاتجاه يلف على الأقل 4 من 8 جهات (يعني نص دورة تقريباً) والمجال المغناطيسي منطقي */
internal fun MainActivity.testCompass() {
    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    if (mag == null || acc == null) {
        toast(tr("الجهاز ما فيه بوصلة", "This device has no compass"))
        skip()
        return
    }
    val gravity = FloatArray(3)
    val geo = FloatArray(3)
    var hasG = false
    var hasM = false
    val sectors = mutableSetOf<Int>()
    var field = 0f
    var heading = -1
    var finished = false
    lateinit var dlg: AlertDialog

    fun msg() = tr(
        "حط الجوال مسطّح ولفّه حول نفسه دورة كاملة ببطء.\nلو ما تحركت القراءة، حرّكه بشكل رقم 8 للمعايرة.\n\n",
        "Lay the phone flat and slowly turn it a full circle.\nIf the reading doesn't move, wave it in a figure 8 to calibrate.\n\n"
    ) + tr("الاتجاه: ", "Heading: ") + (if (heading < 0) "…" else "$heading°") +
        tr("\nالجهات المكتشفة: ${sectors.size} من 8", "\nDirections covered: ${sectors.size} of 8")

    val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (finished) return
            when (e.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    System.arraycopy(e.values, 0, gravity, 0, 3)
                    hasG = true
                }
                Sensor.TYPE_MAGNETIC_FIELD -> {
                    System.arraycopy(e.values, 0, geo, 0, 3)
                    field = sqrt(geo[0] * geo[0] + geo[1] * geo[1] + geo[2] * geo[2])
                    hasM = true
                }
            }
            if (!hasG || !hasM) return
            val r = FloatArray(9)
            if (!SensorManager.getRotationMatrix(r, null, gravity, geo)) return
            val o = FloatArray(3)
            SensorManager.getOrientation(r, o)
            heading = ((Math.toDegrees(o[0].toDouble()) + 360) % 360).roundToInt()
            sectors += (heading / 45) % 8
            dlg.setMessage(msg())
            // المجال المغناطيسي للأرض بين 20 و 70 ميكروتسلا تقريباً
            if (sectors.size >= 4 && field in 15f..90f) {
                finished = true
                sm.unregisterListener(this)
                dlg.dismiss()
                Results.details[Test.COMPASS] = tr("المجال ${field.roundToInt()} µT", "Field ${field.roundToInt()} µT")
                record(Test.COMPASS, true)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    dlg = PcDialog(this)
        .setTitle(Test.COMPASS.title)
        .setMessage(msg())
        .setCancelable(false)
        .setNegativeButton(tr("الاتجاه ما يتغير", "Heading doesn't change")) { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            Results.details[Test.COMPASS] = tr("المجال ${field.roundToInt()} µT", "Field ${field.roundToInt()} µT")
            record(Test.COMPASS, false)
        }
        .setNeutralButton(tr("تخطّي", "Skip")) { _, _ ->
            finished = true
            sm.unregisterListener(listener)
            skip()
        }
        .show()
    cleanup = {
        finished = true
        sm.unregisterListener(listener)
    }
    sm.registerListener(listener, acc, SensorManager.SENSOR_DELAY_UI)
    sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_UI)
}

// ---------------- تنبيهات مهمة ----------------
/** تنبيه واحد: severe = عطل واضح (أحمر)، وإلا تنبيه للانتباه (برتقالي) */
data class RedFlag(val text: String, val severe: Boolean)

object RedFlags {
    fun compute(snap: DeviceSnapshot?): List<RedFlag> {
        val out = mutableListOf<RedFlag>()
        // الأعطال الواضحة أولاً
        // اللي لها تفاصيل أوضح تحت، ما نكررها هنا
        val explained = buildSet {
            if (Results.perf?.issues?.isNotEmpty() == true) add(Test.CPU)
            if ((Results.ram?.errors ?: 0) > 0) add(Test.RAM)
            if (Results.storageCorrupt) add(Test.STORAGE)
            if (Results.networkLocked) add(Test.SIGNAL)
            add(Test.ACCOUNTS)
            Results.battery?.let { if (it.swollen || (it.determined && it.verdict >= 3)) add(Test.BATTERY) }
        }
        for ((t, ok) in Results.map) {
            if (!ok && t !in explained) out += RedFlag(tr("عطل: ", "Fault: ") + t.title, true)
        }
        Results.ram?.takeIf { it.errors > 0 }?.let {
            out += RedFlag(tr("الرام فيها أخطاء (${it.errors})، تسبب تهنيج وإعادة تشغيل", "RAM has errors (${it.errors}); causes lag and restarts"), true)
        }
        if (Results.storageCorrupt) out += RedFlag(tr("التخزين يرجّع بيانات تالفة", "Storage returns corrupted data"), true)
        if (Results.map[Test.ACCOUNTS] == false) {
            out += RedFlag(tr(
                "فيه حساب لسه مسجل: بعد ضبط المصنع الجوال بيطلب حساب البائع ويتقفل (FRP)",
                "An account is still signed in: after a factory reset the phone will ask for the seller's account (FRP lock)"
            ), true)
        }
        if (Results.networkLocked) out += RedFlag(tr("الجوال مقفول على شبكة واحدة", "Phone is locked to one carrier"), true)
        Results.perf?.let { p -> for (i in p.issues) out += RedFlag(i, p.throttlePct > 40 || p.freezes > 0) }
        Results.battery?.let { b ->
            when {
                b.swollen -> out += RedFlag(tr("البطارية منتفخة: خطر", "Battery is swollen: dangerous"), true)
                b.determined && b.verdict >= 3 -> out += RedFlag(tr("البطارية تحتاج تغيير", "Battery needs replacement"), true)
                !b.determined -> out += RedFlag(tr("البطارية ما انحكم عليها (شروط القياس ما اكتملت)", "Battery not rated (test conditions not met)"), false)
            }
        }
        if (snap != null && !snap.remote) {
            snap.bootsPerDay?.takeIf { it > 1.5 }?.let {
                out += RedFlag(tr(
                    String.format(java.util.Locale.US, "يعيد التشغيل كثير: %.1f مرة باليوم (ممكن يطفي لحاله)", it),
                    String.format(java.util.Locale.US, "Restarts often: %.1f times a day (may shut down by itself)", it)
                ), false)
            }
            if (snap.rooted) out += RedFlag(tr("الجوال فيه روت (معدّل)", "Phone is rooted (modified)"), false)
            if (snap.bootloaderUnlocked == true) out += RedFlag(tr("البوتلودر مفتوح: النظام ممكن يكون معدّل", "Bootloader unlocked: the system may be modified"), false)
            if (snap.knoxTripped == true) out += RedFlag(tr("Knox مكسور: الجوال انعدّل نظامه سابقاً (يأثر على Samsung Pay والضمان)", "Knox tripped: the system was modified before (affects Samsung Pay and warranty)"), false)
        }
        Results.usage?.let { u ->
            if (u.recentReset) out += RedFlag(tr("الجوال انمسح (ضبط مصنع) مؤخراً، اسأل البائع عن السبب", "Phone was factory reset recently; ask the seller why"), false)
            if (u.heavyGaming) out += RedFlag(tr("استخدام ألعاب ثقيل (يستهلك البطارية والمعالج)", "Heavy gaming use (wears battery and CPU)"), false)
        }
        return out.sortedByDescending { it.severe }
    }
}
