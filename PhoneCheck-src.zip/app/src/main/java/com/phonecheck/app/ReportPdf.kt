package com.phonecheck.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** بيانات إضافية تدخل التقرير */
class ReportExtras(
    val details: Map<Test, String> = emptyMap(),
    val body: Cond? = null,
    val screen: Cond? = null,
    val notes: String = "",
    val battery: BatteryReport? = null,
)

/** إنشاء تقرير PDF بلغة التطبيق الحالية، مع شعار الشركة أعلى اليسار */
object ReportPdf {

    /** رقم تقرير فريد، مثل DW-261016-4F2A */
    fun newReportId(now: Date): String =
        "DW-" + SimpleDateFormat("yyMMdd", Locale.US).format(now) + "-" +
            Random.nextInt(0x1000, 0xFFFF).toString(16).uppercase(Locale.US)

    fun create(
        ctx: Context,
        snap: DeviceSnapshot,
        score: ScoreResult,
        results: Map<Test, Boolean>,
        tests: List<Test> = Test.values().toList(),
        extras: ReportExtras = ReportExtras(),
    ): File {
        Fonts.init(ctx)
        val now = Date()
        val reportId = newReportId(now)
        val dateText = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(now)
        val doc = PdfDocument()
        val w = PdfWriter(doc, Lang.en, reportId)

        // ---------- الترويسة: شريط داكن، الشعار يسار، العنوان في الباقي ----------
        w.newPage()
        val bandH = 124f
        w.canvas.drawRect(0f, 0f, w.pageW.toFloat(), bandH, Paint().apply { color = BRAND_DARK })
        w.canvas.drawRect(0f, bandH, w.pageW.toFloat(), bandH + 2.5f, Paint().apply { color = BRAND_GOLD })

        val logoH = 92f
        var logoW = 0f
        loadLogo(ctx)?.let { bmp ->
            logoW = logoH * bmp.width / bmp.height
            val top = (bandH - logoH) / 2
            w.canvas.drawBitmap(
                bmp, null, RectF(w.margin, top, w.margin + logoW, top + logoH),
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            )
        }
        val textX = w.margin + logoW + 18f
        val textW = (w.pageW - w.margin - textX).toInt()
        w.y = 24f
        w.paragraph(tr("تقرير فحص الجوال", "Phone Inspection Report"), 20f, Color.WHITE, true, 3f, textX, textW)
        w.paragraph(snap.deviceName, 13f, BRAND_GOLD_LIGHT, true, 4f, textX, textW)
        w.paragraph(tr("تاريخ الفحص: ", "Date: ") + dateText, 9.5f, 0xFFBDBDBD.toInt(), false, 1f, textX, textW)
        w.paragraph(tr("رقم التقرير: ", "Report no.: ") + reportId, 9.5f, 0xFFBDBDBD.toInt(), false, 0f, textX, textW)
        w.y = bandH + 22f

        // ---------- التقييم ----------
        w.paragraph(
            tr("التقييم العام: ", "Overall score: ") + "${score.percent}/100  —  ${score.grade}",
            19f, Scoring.gradeColor(score.percent), true
        )
        if (snap.remote) {
            w.paragraph(tr("طريقة الفحص: عن بُعد عبر متصفح الجوال المفحوص", "Method: remote, via the inspected phone's browser"), 10f, Color.GRAY)
        }
        val note = if (score.tested == score.total) {
            tr("تم إجراء جميع الاختبارات (${score.total})", "All tests completed (${score.total})")
        } else {
            tr(
                "تم إجراء ${score.tested} من ${score.total} اختبار، والتقييم مبني على المختبَر فقط",
                "${score.tested} of ${score.total} tests completed; the score is based on tested items only"
            )
        }
        w.paragraph(note, 10f, Color.GRAY)

        // ---------- تقرير البطارية (أهم قسم بعد التقييم) ----------
        extras.battery?.let { b ->
            w.sectionTitle(tr("تقرير البطارية", "Battery report"))
            w.row(tr("الحكم", "Verdict"), b.verdictText, b.verdictColor)
            b.healthPct?.let { w.row(tr("صحة البطارية", "Battery health"), "$it%  ·  ${b.confidenceText}", b.verdictColor) }
            b.measuredMah?.let { w.row(tr("السعة الفعلية المقاسة", "Measured capacity"), "$it mAh") }
            b.designMah?.let { w.row(tr("السعة الأصلية", "Design capacity"), "$it mAh (${b.sourceText})") }
            w.row(tr("طريقة القياس", "Method"), b.methodText + if (b.levelDelta > 0) "  ·  ${b.levelDelta}%" else "")
            b.cycles?.let { w.row(tr("دورات الشحن", "Charge cycles"), "$it") }
            w.row(
                tr("المقاومة الداخلية", "Internal resistance"),
                b.irMohm?.let { "$it mΩ" } ?: tr("غير متاحة في هذا الجهاز", "Not available on this device")
            )
            b.maxTempC?.let { w.row(tr("أعلى حرارة أثناء الفحص", "Max temperature during test"), String.format(Locale.US, "%.1f°C", it)) }
            w.row(
                tr("انتفاخ", "Swelling"),
                if (b.swollen) tr("نعم ⚠", "Yes ⚠") else tr("لا يوجد", "None"),
                if (b.swollen) RED else GREEN
            )
        }

        // ---------- الحالة الخارجية ----------
        if (extras.body != null || extras.screen != null || extras.notes.isNotBlank()) {
            w.sectionTitle(tr("الحالة الخارجية", "Cosmetic condition"))
            extras.body?.let { w.row(tr("الهيكل", "Body"), it.label, condColor(it)) }
            extras.screen?.let { w.row(tr("زجاج الشاشة", "Screen glass"), it.label, condColor(it)) }
            if (extras.notes.isNotBlank()) {
                w.y += 2f
                w.paragraph(tr("ملاحظات: ", "Notes: ") + extras.notes.trim(), 10.5f, Color.DKGRAY)
            }
        }

        // ---------- نتائج الاختبارات ----------
        w.sectionTitle(tr("نتائج الاختبارات", "Test results"))
        for (t in tests) {
            val r = results[t]
            var (label, color) = when (r) {
                true -> tr("سليم ✓", "Pass ✓") to GREEN
                false -> tr("فيه مشكلة ✗", "Fail ✗") to RED
                null -> tr("لم يُختبر", "Not tested") to Color.GRAY
            }
            extras.details[t]?.let { if (r != null) label += "  ·  $it" }
            w.row(t.title, label, color)
        }

        // ---------- تفاصيل الجهاز ----------
        for (s in snap.sections) {
            w.sectionTitle(s.title)
            for (i in s.items) w.row(i.label, i.value)
        }

        w.y += 12f
        w.paragraph(
            tr(
                "ملاحظة: هذا التقرير ناتج عن فحص برمجي للجهاز وقت إنشائه. لا يكشف هل القطع أصلية أو مستبدلة، " +
                    "وبعض القيم مثل صحة البطارية تقديرية حسب ما يسمح به النظام.",
                "Note: this report reflects a software inspection of the device at the time it was created. " +
                    "It cannot tell whether parts are original or replaced, and some values such as battery health are estimates."
            ),
            9f, Color.GRAY
        )
        w.finish()

        // نحفظ التقرير بشكل دائم عشان يظهر في السجل
        val dir = File(ctx.filesDir, "reports").apply { mkdirs() }
        val file = File(dir, "$reportId.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()

        History.add(
            ctx,
            HistoryEntry(reportId, now.time, snap.deviceName, score.percent, snap.remote, file.absolutePath)
        )
        return file
    }

    private fun condColor(c: Cond): Int = when (c) {
        Cond.EXCELLENT -> GREEN
        Cond.LIGHT -> 0xFF5E7076.toInt()
        Cond.VISIBLE -> 0xFFC98A1B.toInt()
        Cond.BROKEN -> RED
    }

    private fun loadLogo(ctx: Context): Bitmap? = try {
        val raw = BitmapFactory.decodeResource(ctx.resources, R.drawable.company_logo)
        // نصغّره عشان حجم الملف يبقى خفيف
        Bitmap.createScaledBitmap(raw, 420, 420 * raw.height / raw.width, true)
    } catch (e: Exception) {
        null
    }
}

private class PdfWriter(private val doc: PdfDocument, private val en: Boolean, private val reportId: String) {
    val pageW = 595
    val pageH = 842
    val margin = 40f
    private val bottom = 48f
    private val contentW: Int get() = (pageW - 2 * margin).toInt()
    private var page: PdfDocument.Page? = null
    private var number = 0
    var y = margin

    val canvas: Canvas get() = page!!.canvas

    private val linePaint = Paint().apply {
        color = 0xFFE6E6E6.toInt()
        strokeWidth = 0.8f
    }
    private val accentPaint = Paint().apply { color = BRAND_GOLD }

    fun newPage() {
        page?.let { footer(); doc.finishPage(it) }
        number++
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, number).create())
        y = margin
    }

    fun finish() {
        page?.let { footer(); doc.finishPage(it) }
        page = null
    }

    /** تذييل كل صفحة: اسم الشركة ورقم التقرير ورقم الصفحة */
    private fun footer() {
        val yy = pageH - 30f
        canvas.drawLine(margin, yy - 8f, pageW - margin, yy - 8f, linePaint)
        val text = "DUWAINI  ·  $reportId  ·  " + tr("صفحة $number", "Page $number")
        val l = layout(text, 8.5f, Color.GRAY, false, contentW, Layout.Alignment.ALIGN_CENTER)
        draw(l, margin, yy)
    }

    private fun ensure(h: Float) {
        if (y + h > pageH - bottom) newPage()
    }

    private fun layout(text: String, size: Float, color: Int, bold: Boolean, width: Int, align: Layout.Alignment): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Fonts.bold else Fonts.regular
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, p, width.coerceAtLeast(10))
            .setAlignment(align)
            .setTextDirection(if (en) TextDirectionHeuristics.LTR else TextDirectionHeuristics.RTL)
            .build()
    }

    private fun draw(l: StaticLayout, x: Float, top: Float) {
        canvas.save()
        canvas.translate(x, top)
        l.draw(canvas)
        canvas.restore()
    }

    fun paragraph(
        text: String,
        size: Float = 11f,
        color: Int = Color.BLACK,
        bold: Boolean = false,
        gapAfter: Float = 6f,
        x: Float = margin,
        width: Int = contentW,
    ) {
        val l = layout(text, size, color, bold, width, Layout.Alignment.ALIGN_NORMAL)
        ensure(l.height.toFloat())
        draw(l, x, y)
        y += l.height + gapAfter
    }

    fun sectionTitle(t: String) {
        y += 12f
        ensure(52f)
        paragraph(t, 14f, BRAND_DARK, true, gapAfter = 3f)
        canvas.drawRect(margin, y, pageW - margin, y + 1.5f, accentPaint)
        y += 6f
    }

    fun row(label: String, value: String, valueColor: Int = Color.BLACK) {
        val half = contentW / 2
        val l1 = layout(label, 10.5f, Color.DKGRAY, false, half, Layout.Alignment.ALIGN_NORMAL)
        val l2 = layout(value, 10.5f, valueColor, true, half, Layout.Alignment.ALIGN_OPPOSITE)
        val h = maxOf(l1.height, l2.height).toFloat()
        ensure(h + 8f)
        // العنوان على جهة بداية القراءة، والقيمة على الجهة الثانية
        if (en) {
            draw(l1, margin, y)
            draw(l2, margin + half, y)
        } else {
            draw(l1, margin + half, y)
            draw(l2, margin, y)
        }
        y += h + 3f
        canvas.drawLine(margin, y, pageW - margin, y, linePaint)
        y += 4f
    }
}
