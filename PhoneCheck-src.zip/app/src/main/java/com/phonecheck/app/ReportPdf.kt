package com.phonecheck.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** إنشاء تقرير PDF عربي من نتائج الفحص */
object ReportPdf {

    fun create(
        ctx: Context,
        snap: DeviceSnapshot,
        score: ScoreResult,
        results: Map<Test, Boolean>,
        tests: List<Test> = Test.values().toList(),
    ): File {
        Fonts.init(ctx)
        val doc = PdfDocument()
        val w = PdfWriter(doc)
        val now = Date()
        val dateText = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(now)

        // الترويسة
        w.newPage()
        w.canvas.drawRect(0f, 0f, w.pageW.toFloat(), 112f, Paint().apply { color = PRIMARY })
        w.y = 26f
        w.paragraph("تقرير فحص الجوال", 22f, Color.WHITE, true, gapAfter = 4f)
        w.paragraph(snap.deviceName, 14f, Color.WHITE, gapAfter = 2f)
        w.paragraph("تاريخ الفحص: $dateText", 10f, LIGHT)
        w.y = 132f

        // التقييم
        w.paragraph("التقييم العام: ${score.percent} من 100  —  ${score.grade}", 19f, Scoring.gradeColor(score.percent), true)
        if (snap.remote) w.paragraph("طريقة الفحص: عن بُعد عبر متصفح الجوال المفحوص", 10f, Color.GRAY)
        val note = if (score.tested == score.total) "تم إجراء جميع الاختبارات اليدوية (${score.total})"
        else "تم إجراء ${score.tested} من ${score.total} اختبارات يدوية، والتقييم مبني على المختبَر فقط"
        w.paragraph(note, 10f, Color.GRAY)

        // نتائج الاختبارات
        w.sectionTitle("نتائج الاختبارات")
        for (t in tests) {
            val r = results[t]
            val (label, color) = when (r) {
                true -> "سليم ✓" to GREEN
                false -> "فيه مشكلة ✗" to RED
                null -> "لم يُختبر" to Color.GRAY
            }
            w.row(t.title, label, color)
        }

        // تفاصيل الجهاز
        for (s in snap.sections) {
            w.sectionTitle(s.title)
            for (i in s.items) w.row(i.label, i.value)
        }

        w.y += 12f
        w.paragraph(
            "ملاحظة: هذا التقرير ناتج عن فحص برمجي على الجهاز نفسه وقت إنشائه. " +
                "لا يكشف هل القطع أصلية أو مستبدلة، وبعض القيم مثل صحة البطارية تقديرية حسب ما يسمح به النظام.",
            9f, Color.GRAY
        )
        w.finish()

        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(now)
        val file = File(dir, "PhoneCheck_$stamp.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }
}

private class PdfWriter(private val doc: PdfDocument) {
    val pageW = 595
    val pageH = 842
    private val margin = 40f
    private val contentW: Int get() = (pageW - 2 * margin).toInt()
    private var page: PdfDocument.Page? = null
    private var number = 0
    var y = margin

    val canvas: Canvas get() = page!!.canvas

    private val linePaint = Paint().apply {
        color = 0xFFE0E0E0.toInt()
        strokeWidth = 0.8f
    }
    private val accentPaint = Paint().apply { color = PRIMARY }

    fun newPage() {
        page?.let { doc.finishPage(it) }
        number++
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, number).create())
        y = margin
    }

    fun finish() {
        page?.let { doc.finishPage(it) }
        page = null
    }

    private fun ensure(h: Float) {
        if (y + h > pageH - margin) newPage()
    }

    private fun layout(text: String, size: Float, color: Int, bold: Boolean, width: Int, align: Layout.Alignment): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Fonts.bold else Fonts.regular
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setAlignment(align)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .build()
    }

    private fun draw(l: StaticLayout, x: Float, top: Float) {
        canvas.save()
        canvas.translate(x, top)
        l.draw(canvas)
        canvas.restore()
    }

    fun paragraph(
        text: String,
        size: Float = 11f,
        color: Int = Color.BLACK,
        bold: Boolean = false,
        gapAfter: Float = 6f,
    ) {
        val l = layout(text, size, color, bold, contentW, Layout.Alignment.ALIGN_NORMAL)
        ensure(l.height.toFloat())
        draw(l, margin, y)
        y += l.height + gapAfter
    }

    fun sectionTitle(t: String) {
        y += 10f
        ensure(50f)
        paragraph(t, 14f, PRIMARY, true, gapAfter = 3f)
        canvas.drawRect(margin, y, pageW - margin, y + 1.5f, accentPaint)
        y += 6f
    }

    fun row(label: String, value: String, valueColor: Int = Color.BLACK) {
        val half = contentW / 2
        val l1 = layout(label, 10.5f, Color.DKGRAY, false, half, Layout.Alignment.ALIGN_NORMAL)
        val l2 = layout(value, 10.5f, valueColor, true, half, Layout.Alignment.ALIGN_OPPOSITE)
        val h = maxOf(l1.height, l2.height).toFloat()
        ensure(h + 8f)
        draw(l1, margin + half, y)
        draw(l2, margin, y)
        y += h + 3f
        canvas.drawLine(margin, y, pageW - margin, y, linePaint)
        y += 4f
    }
}
