package com.phonecheck.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** بيانات إضافية تدخل التقرير */
class ReportExtras(
    val details: Map<Test, String> = emptyMap(),
    val body: Cond? = null,
    val screen: Cond? = null,
    val notes: String = "",
    val battery: BatteryReport? = null,
    val usage: UsageProfile? = null,
    val flags: List<RedFlag> = emptyList(),
    val perf: PerfReport? = null,
    val ram: RamReport? = null,
    val imei: String = "",
    val conditions: TestConditions? = null,
    val mode: Mode? = null,
    /** توقيع التقرير برمز QR (للفحص المحلي فقط) */
    val sign: Boolean = false,
    /** صادر من محل مشترك (معتمد)، وإلا "فحص ذاتي" */
    val certified: Boolean = false,
)

/** إنشاء تقرير PDF بلغة التطبيق الحالية، مع شعار الشركة أعلى اليسار */
object ReportPdf {

    /** رقم تقرير فريد، مثل DW-261016-4F2A */
    fun newReportId(now: Date): String =
        "DW-" + SimpleDateFormat("yyMMdd", Locale.US).format(now) + "-" +
            Random.nextInt(0x1000, 0xFFFF).toString(16).uppercase(Locale.US)

    fun create(
        ctx: Context,
        snap: DeviceSnapshot,
        score: ScoreResult,
        results: Map<Test, Boolean>,
        tests: List<Test> = Test.values().toList(),
        extras: ReportExtras = ReportExtras(),
    ): File {
        Fonts.init(ctx)
        val now = Date()
        val reportId = newReportId(now)
        val dateText = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(now)
        val doc = PdfDocument()
        // الفحص الذاتي (بدون محل معتمد) عليه علامة مائية واضحة
        val selfCheck = !snap.remote && !extras.certified
        val w = PdfWriter(doc, Lang.en, reportId, if (selfCheck) tr("فحص ذاتي", "SELF-CHECK") else null)

        // ---------- الترويسة: خلفية بيضاء، شعار DUWAINI يسار، العنوان في الباقي، وخط ذهبي تحت ----------
        w.newPage()
        val bandH = 128f
        val logoH = 100f
        var logoW = 0f
        loadLogo(ctx)?.let { bmp ->
            logoW = logoH * bmp.width / bmp.height
            val top = (bandH - logoH) / 2
            w.canvas.drawBitmap(
                bmp, null, RectF(w.margin, top, w.margin + logoW, top + logoH),
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            )
        }
        val textX = w.margin + logoW + 18f
        val textW = (w.pageW - w.margin - textX).toInt()
        w.y = 24f
        val title = when {
            snap.remote -> tr("تقرير فحص الجوال", "Phone Inspection Report")
            selfCheck -> tr("تقرير فحص ذاتي", "Self-Check Report")
            extras.mode == Mode.QUICK -> tr("تقرير فحص سريع", "Quick Inspection Report")
            extras.mode == Mode.FULL -> tr("تقرير فحص كامل", "Full Inspection Report")
            else -> tr("تقرير فحص الجوال", "Phone Inspection Report")
        }
        val meta = 0xFF6B6B6B.toInt()
        w.paragraph(title, 20f, BRAND_DARK, true, 3f, textX, textW)
        w.paragraph(snap.deviceName, 13f, BRAND_GOLD, true, 4f, textX, textW)
        w.paragraph(tr("تاريخ الفحص: ", "Date: ") + dateText, 9.5f, meta, false, 1f, textX, textW)
        if (selfCheck) {
            w.paragraph(tr("غير صادر من محل معتمد", "Not issued by a certified shop"), 9.5f, RED, true, 1f, textX, textW)
        } else if (License.holder.isNotBlank()) {
            w.paragraph(tr("صادر من: ", "Issued by: ") + License.holder, 9.5f, meta, false, 1f, textX, textW)
        }
        w.paragraph(tr("رقم التقرير: ", "Report no.: ") + reportId, 9.5f, meta, false, 0f, textX, textW)
        // خط ذهبي أنيق تحت الترويسة
        val lineY = maxOf(bandH, w.y + 10f)
        w.canvas.drawRect(w.margin, lineY, w.pageW - w.margin, lineY + 1.6f, Paint().apply { color = BRAND_GOLD })
        w.canvas.drawRect(w.margin, lineY + 4f, w.pageW - w.margin, lineY + 4.6f, Paint().apply { color = 0xFFE6DCC8.toInt() })
        w.y = lineY + 24f

        // ---------- التقييم ----------
        w.paragraph(
            tr("التقييم العام: ", "Overall score: ") + "${score.percent}/100  —  ${score.grade}",
            19f, Scoring.gradeColor(score.percent), true
        )
        if (snap.remote) {
            w.paragraph(tr("طريقة الفحص: عن بُعد عبر متصفح الجوال المفحوص", "Method: remote, via the inspected phone's browser"), 10f, Color.GRAY)
        }
        extras.mode?.let { m ->
            w.paragraph(
                tr("نوع الفحص: ", "Inspection type: ") + m.label +
                    if (m == Mode.QUICK) tr(
                        " (بدون فحص البطارية العميق والـ GPS، والتقييم مبدئي)",
                        " (without the deep battery test and GPS; the score is preliminary)"
                    ) else "",
                10f, if (m == Mode.QUICK) 0xFFA86B0C.toInt() else Color.GRAY
            )
        }
        val note = if (score.tested == score.total) {
            tr("تم إجراء جميع الاختبارات (${score.total})", "All tests completed (${score.total})")
        } else {
            tr(
                "تم إجراء ${score.tested} من ${score.total} اختبار، والتقييم مبني على المختبَر فقط",
                "${score.tested} of ${score.total} tests completed; the score is based on tested items only"
            )
        }
        w.paragraph(note, 10f, Color.GRAY)

        // ---------- العمر والقدرة: تقييم ثاني منفصل عن الحالة ----------
        if (!snap.remote) snap.age?.let { a ->
            w.sectionTitle(tr("العمر والقدرة", "Age & capability"))
            w.row(tr("التقييم", "Rating"), "${a.label}  (${a.score}/100)", a.color)
            a.launchYear?.let { w.row(tr("سنة الإنتاج", "Year made"), tr("$it تقريباً", "around $it")) }
            w.row(tr("أندرويد", "Android"), (a.firstAndroid?.let { tr("نزل بـ $it، ", "launched with $it, ") } ?: "") + tr("الحالي ${a.currentAndroid}", "now ${a.currentAndroid}"))
            w.row(tr("آخر تحديث أمني", "Last security patch"), (a.patchDate ?: "-") + "  ·  " + a.supportText, if ((a.patchAgeMonths ?: 0) > 12) RED else Color.BLACK)
            w.row(tr("الرام", "RAM"), "${a.ramGb} GB")
            w.paragraph(a.advice, 10f, BRAND_DARK, false, 3f)
            w.paragraph(tr(
                "الحالة تقيس هل القطع سليمة، والعمر والقدرة يقيس هل الجوال لسه مناسب اليوم. جوال قديم سليم ياخذ حالة عالية وعمر \"قديم\". سنة الإنتاج تقريبية من إصدار أندرويد اللي نزل فيه.",
                "Condition measures whether parts work; age & capability measures whether the phone still fits today's use. An old phone in perfect shape gets a high condition score and an \"Old\" age rating. The year is estimated from the Android version it launched with."
            ), 8.5f, Color.GRAY)
        }

        // ---------- التحقق من التقرير ----------
        if (extras.sign) {
            val url = ReportTrust.signedUrl(
                ctx, reportId, now, snap, score, results, extras.battery, extras.body, extras.screen,
                extras.imei, extras.flags.size, extras.mode ?: Mode.FULL
            )
            val m = url?.let { ReportTrust.qr(it) }
            if (m != null) {
                w.sectionTitle(tr("التحقق من التقرير", "Report verification"))
                val imeiLine = if (extras.imei.isNotBlank()) "IMEI: ${extras.imei}" else tr("IMEI: غير مُدخل", "IMEI: not entered")
                w.qrBlock(
                    m,
                    imeiLine + "\n" + tr("بصمة الجهاز: ", "Device tag: ") + ReportTrust.deviceTag(ctx) + "\n\n" + tr(
                        "امسح الرمز بكاميرا الجوال: تفتح صفحة تتأكد من التوقيع الرقمي وتعرض بيانات التقرير الأصلية. لو أي رقم في الصفحة يختلف عن هذا الملف، فالملف معدّل.",
                        "Scan with a phone camera: a page checks the digital signature and shows the original report data. If anything on that page differs from this file, the file was altered."
                    )
                )
            }
        }

        // ---------- تنبيهات مهمة: أول شي يشوفه المشتري ----------
        if (extras.flags.isNotEmpty()) {
            w.sectionTitle(tr("⚠ تنبيهات مهمة", "⚠ Important warnings"))
            for (f in extras.flags) {
                w.paragraph("•  " + f.text, 10.5f, if (f.severe) RED else 0xFFA86B0C.toInt(), f.severe, 3f)
            }
        }

        // ---------- تقرير البطارية (أهم قسم بعد التقييم) ----------
        extras.battery?.let { b ->
            w.sectionTitle(tr("تقرير البطارية", "Battery report"))
            w.row(tr("الحكم", "Verdict"), b.verdictText, b.verdictColor)
            b.healthText?.let { w.row(tr("صحة البطارية", "Battery health"), it, b.verdictColor) }
            w.row(tr("درجة الثقة", "Confidence"), b.confidenceText)
            if (!b.determined && b.missing.isNotEmpty()) {
                w.paragraph(
                    tr("ليش ما انحكم عليها:", "Why it was not rated:") + "\n" + b.missing.joinToString("\n") { "•  $it" },
                    9.5f, Color.DKGRAY, false, 4f
                )
            }
            w.row(tr("مصدر النسبة", "Health source"), b.healthSourceText)
            b.measuredMah?.let { w.row(tr("السعة المقاسة أثناء الشحن", "Capacity measured while charging"), "$it mAh  ·  ${b.levelDelta}%") }
            b.dischargeMah?.let { w.row(tr("السعة المقاسة أثناء التفريغ", "Capacity measured on discharge"), "$it mAh") }
            b.segmentsAgree?.let { w.row(tr("اتفاق نصفي القياس", "Measurement halves agree"), if (it) tr("نعم ✓", "Yes ✓") else tr("لا", "No")) }
            b.designMah?.let { w.row(tr("السعة الأصلية", "Design capacity"), "$it mAh (${b.sourceText})") }
            b.cycles?.let { w.row(tr("دورات الشحن", "Charge cycles"), "$it") }
            w.row(
                tr("المقاومة الداخلية", "Internal resistance"),
                b.irMohm?.let { "$it mΩ" } ?: tr("غير متاحة في هذا الجهاز", "Not available on this device")
            )
            b.maxChargeMa?.let { w.row(tr("أعلى تيار شحن", "Peak charge current"), "$it mA") }
            b.maxTempC?.let { w.row(tr("أعلى حرارة أثناء الشحن", "Max temperature while charging"), String.format(Locale.US, "%.1f°C", it)) }
            val df = SimpleDateFormat("yyyy/MM/dd", Locale.US)
            b.mfgDate?.let { w.row(tr("تاريخ تصنيع البطارية", "Battery manufacture date"), df.format(Date(it))) }
            b.firstUse?.let { w.row(tr("أول استخدام للبطارية", "Battery first used"), df.format(Date(it))) }
            w.row(
                tr("انتفاخ", "Swelling"),
                if (b.swollen) tr("نعم ⚠", "Yes ⚠") else tr("لا يوجد", "None"),
                if (b.swollen) RED else GREEN
            )
            if (b.capsSummary.isNotEmpty()) {
                val ok = b.capsSummary.filter { it.second }.joinToString("، ") { it.first }
                val no = b.capsSummary.filter { !it.second }.joinToString("، ") { it.first }
                w.y += 4f
                w.paragraph(
                    tr("قراءات متاحة في هذا الجوال: ", "Readings available on this phone: ") + ok.ifBlank { "-" } +
                        "\n" + tr("غير متاحة: ", "Not available: ") + no.ifBlank { "-" },
                    9f, Color.GRAY
                )
            }
            w.paragraph(
                tr(
                    "أي قياس غير متاح في الجهاز يُستبعد ولا يُنقص من التقييم. وعند ثقة أقل من عالية يُحسب الحكم لصالح البطارية ضمن هامش الخطأ.",
                    "Any measurement the device doesn't support is excluded and never lowers the verdict. Below high confidence, the verdict favors the battery within the margin of error."
                ),
                9f, Color.GRAY
            )
        }

        // ---------- الأداء والثبات ----------
        if (extras.perf != null || extras.ram != null || snap.bootCount != null) {
            w.sectionTitle(tr("الأداء والثبات", "Performance & stability"))
            extras.perf?.let { p ->
                w.row(
                    tr("المعالج تحت الضغط", "Processor under load"),
                    if (p.passed) tr("سليم ✓", "OK ✓") else tr("فيه مشكلة ✗", "Issue ✗"),
                    if (p.passed) GREEN else RED
                )
                w.row(tr("سرعة النواة الواحدة", "Single-core score"), "${p.singleScore}")
                w.row(tr("كل الأنوية: البداية ← بعد دقيقة", "All cores: start → after 1 min"), "${p.multiStart} → ${p.multiEnd}")
                w.row(tr("انخفاض الأداء مع الحرارة", "Drop under heat"), "${p.throttlePct}%", if (p.throttlePct > 40) RED else Color.BLACK)
                w.row(tr("الحرارة: البداية ← الأعلى", "Temp: start → max"), String.format(Locale.US, "%.0f° → %.0f°", p.tempStart, p.tempMax))
                w.row(tr("نعومة الشاشة", "Smoothness"), "${p.avgFps}/${p.refreshHz} fps · " + tr("متأخرة ${p.jankPct}%", "late ${p.jankPct}%"), if (p.jankPct > 10) RED else Color.BLACK)
                w.row(tr("تعليقات الشاشة", "Screen freezes"), "${p.freezes}", if (p.freezes > 0) RED else Color.BLACK)
            }
            extras.ram?.let { r ->
                w.row(
                    tr("الرام", "RAM"),
                    if (r.errors == 0) tr("سليمة ✓ (فحص ${r.testedMb} MB)", "OK ✓ (${r.testedMb} MB tested)")
                    else tr("${r.errors} خطأ ✗", "${r.errors} errors ✗"),
                    if (r.errors == 0) GREEN else RED
                )
            }
            snap.bootCount?.let { c ->
                val rate = snap.bootsPerDay?.let { String.format(Locale.US, " · %.1f/", it) + tr("يوم", "day") } ?: ""
                w.row(tr("مرات إعادة التشغيل", "Restarts"), "$c$rate", if ((snap.bootsPerDay ?: 0.0) > 1.5) RED else Color.BLACK)
            }
        }

        // ---------- ظروف الفحص ----------
        extras.conditions?.let { c ->
            w.sectionTitle(tr("ظروف الفحص", "Test conditions"))
            w.row(tr("حرارة الجوال عند الفحص", "Phone temperature"), String.format(Locale.US, "%.0f°C", c.tempC), if (c.tempC > 40f) RED else Color.BLACK)
            w.row(tr("وضع توفير الطاقة", "Battery saver"), if (c.powerSave) tr("شغّال ⚠", "On ⚠") else tr("مقفل", "Off"), if (c.powerSave) RED else Color.BLACK)
            if (c.availRamPct >= 0) w.row(tr("الرام المتاحة", "Available RAM"), "${c.availRamPct}%  (${c.availRamMb} MB)", if (c.availRamPct < 15) 0xFFA86B0C.toInt() else Color.BLACK)
            if (c.freeStoragePct >= 0) w.row(
                tr("التخزين الفاضي", "Free storage"),
                "${c.freeStoragePct}%  (" + String.format(Locale.US, "%.1f GB", c.freeStorageGb) + ")",
                if (c.freeStoragePct < 10) 0xFFA86B0C.toInt() else Color.BLACK
            )
            w.row(tr("على الشاحن", "Charging"), if (c.charging) tr("نعم", "Yes") else tr("لا", "No"))
            extras.perf?.takeIf { it.forced }?.let {
                w.paragraph(tr(
                    "اختبار المعالج اشتغل في ظروف غير مناسبة، فنتيجته ممكن تكون أسوأ من الحقيقة.",
                    "The processor test ran in non-ideal conditions, so its result may be worse than reality."
                ), 9.5f, 0xFFA86B0C.toInt())
            }
        }

        // ---------- ملف الاستخدام ----------
        extras.usage?.let { u ->
            w.sectionTitle(tr("ملف الاستخدام", "Usage profile"))
            w.paragraph(u.summary, 11f, BRAND_DARK, true)
            if (!u.recentReset) {
                w.row(tr("مستخدم منذ", "In use for"), u.inUseText)
                u.avgDailyMin?.let { w.row(tr("متوسط الشاشة يومياً (آخر أسبوع)", "Avg. daily screen time (last week)"), hm(it)) }
                u.longAvgDailyMin?.let { w.row(tr("متوسط يومي على المدى الطويل", "Long-term daily average"), hm(it)) }
                w.row(tr("مستوى الاستخدام", "Usage level"), u.intensityText)
                if (u.historyDays > 0) w.row(tr("السجل المتاح يغطي", "History covers"), tr("${u.historyDays} يوم", "${u.historyDays} days"))
                if (u.shares.isNotEmpty()) {
                    w.y += 4f
                    w.paragraph(tr("توزيع الاستخدام", "Usage breakdown"), 10.5f, Color.DKGRAY, true, 4f)
                    for ((cat, pct) in u.shares.take(6)) w.bar(cat.label, pct, cat.color)
                }
            }
            w.paragraph(
                tr(
                    "مبني على سجل استخدام أندرويد منذ آخر ضبط مصنع، ويعرض فئات ونسب فقط بدون أسماء تطبيقات.",
                    "Based on Android usage history since the last factory reset; shows categories and shares only, no app names."
                ),
                8.5f, Color.GRAY
            )
        }

        // ---------- الحالة الخارجية ----------
        if (extras.body != null || extras.screen != null || extras.notes.isNotBlank()) {
            w.sectionTitle(tr("الحالة الخارجية", "Cosmetic condition"))
            extras.body?.let { w.row(tr("الهيكل", "Body"), it.label, condColor(it)) }
            extras.screen?.let { w.row(tr("زجاج الشاشة", "Screen glass"), it.label, condColor(it)) }
            if (extras.notes.isNotBlank()) {
                w.y += 2f
                w.paragraph(tr("ملاحظات: ", "Notes: ") + extras.notes.trim(), 10.5f, Color.DKGRAY)
            }
        }

        // ---------- نتائج الاختبارات ----------
        w.sectionTitle(tr("نتائج الاختبارات", "Test results"))
        for (t in tests) {
            val r = results[t]
            var (label, color) = when (r) {
                true -> tr("سليم ✓", "Pass ✓") to GREEN
                false -> tr("فيه مشكلة ✗", "Fail ✗") to RED
                null -> (
                    if (extras.mode == Mode.QUICK && t !in Mode.QUICK.tests) tr("خارج الفحص السريع", "Not in quick inspection")
                    else tr("لم يُختبر", "Not tested")
                    ) to Color.GRAY
            }
            extras.details[t]?.let { if (r != null) label += "  ·  $it" }
            w.row(t.title, label, color)
        }

        // ---------- مواصفات الجهاز (كل تبويب الجهاز) ----------
        if (snap.sections.isNotEmpty()) {
            w.sectionTitle(tr("مواصفات الجهاز بالتفصيل", "Full device specifications"))
            w.paragraph(tr(
                "كل القراءات التالية مأخوذة من الجهاز نفسه وقت الفحص.",
                "All readings below were taken from the device itself at inspection time."
            ), 9f, Color.GRAY)
            for (s in snap.sections) {
                w.subTitle(s.title)
                for (i in s.items) w.row(i.label, i.value)
            }
        }

        // ---------- حدود الفحص ----------
        w.sectionTitle(tr("ما لا يغطيه هذا الفحص", "What this inspection does not cover"))
        w.paragraph(
            tr(
                "هذا التقرير ناتج عن فحص برمجي للجهاز وقت إنشائه، ولا يكشف:\n" +
                    "•  هل القطع أصلية أو مستبدلة (الشاشة، البطارية، الكاميرا).\n" +
                    "•  دخول الماء أو الرطوبة.\n" +
                    "•  هل الجوال مسروق أو عليه بلاغ (فحص IMEI لدى الجهات المختصة).\n" +
                    "•  الأعطال المتقطعة اللي ما ظهرت وقت الفحص.\n" +
                    "وبعض القيم مثل صحة البطارية تقديرية حسب ما يسمح به النظام.",
                "This report reflects a software inspection at the time it was created. It does not detect:\n" +
                    "•  Whether parts are original or replaced (screen, battery, camera).\n" +
                    "•  Water or moisture damage.\n" +
                    "•  Whether the phone is stolen or blacklisted (check the IMEI with the relevant authority).\n" +
                    "•  Intermittent faults that did not appear during the inspection.\n" +
                    "Some values, such as battery health, are estimates within what the system allows."
            ),
            9.5f, Color.DKGRAY
        )
        w.finish()

        // نحفظ التقرير بشكل دائم عشان يظهر في السجل
        val dir = File(ctx.filesDir, "reports").apply { mkdirs() }
        val file = File(dir, "$reportId.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()

        History.add(
            ctx,
            HistoryEntry(
                reportId, now.time, snap.deviceName, score.percent, snap.remote, file.absolutePath,
                when (extras.mode) {
                    Mode.QUICK -> "q"
                    Mode.FULL -> "f"
                    null -> ""
                }
            )
        )
        return file
    }

    private fun hm(min: Int): String =
        if (min >= 60) tr("${min / 60} ساعة ${min % 60} دقيقة", "${min / 60}h ${min % 60}m") else tr("$min دقيقة", "$min min")

    private fun condColor(c: Cond): Int = when (c) {
        Cond.EXCELLENT -> GREEN
        Cond.LIGHT -> 0xFF5E7076.toInt()
        Cond.VISIBLE -> 0xFFC98A1B.toInt()
        Cond.BROKEN -> RED
    }

    private fun loadLogo(ctx: Context): Bitmap? = try {
        val raw = BitmapFactory.decodeResource(ctx.resources, R.drawable.company_logo)
        // نصغّره عشان حجم الملف يبقى خفيف
        Bitmap.createScaledBitmap(raw, 600, 600 * raw.height / raw.width, true)
    } catch (e: Exception) {
        null
    }
}

private class PdfWriter(
    private val doc: PdfDocument,
    private val en: Boolean,
    private val reportId: String,
    private val watermark: String? = null,
) {
    val pageW = 595
    val pageH = 842
    val margin = 40f
    private val bottom = 48f
    private val contentW: Int get() = (pageW - 2 * margin).toInt()
    private var page: PdfDocument.Page? = null
    private var number = 0
    var y = margin

    val canvas: Canvas get() = page!!.canvas

    private val linePaint = Paint().apply {
        color = 0xFFE6E6E6.toInt()
        strokeWidth = 0.8f
    }
    private val accentPaint = Paint().apply { color = BRAND_GOLD }

    fun newPage() {
        page?.let { footer(); doc.finishPage(it) }
        number++
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, number).create())
        y = margin
        // علامة مائية مائلة في وسط الصفحة
        watermark?.let { wm ->
            val p = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x14C7432E
                textSize = 86f
                typeface = Fonts.bold
                textAlign = Paint.Align.CENTER
            }
            canvas.save()
            canvas.rotate(-35f, pageW / 2f, pageH / 2f)
            canvas.drawText(wm, pageW / 2f, pageH / 2f, p)
            canvas.restore()
        }
    }

    /** عنوان فرعي داخل قسم */
    fun subTitle(t: String) {
        y += 8f
        ensure(40f)
        paragraph(t, 11.5f, BRAND_GOLD, true, gapAfter = 2f)
    }

    fun finish() {
        page?.let { footer(); doc.finishPage(it) }
        page = null
    }

    /** تذييل كل صفحة: اسم الشركة ورقم التقرير ورقم الصفحة */
    private fun footer() {
        val yy = pageH - 30f
        canvas.drawLine(margin, yy - 8f, pageW - margin, yy - 8f, linePaint)
        val text = "DUWAINI  ·  $reportId  ·  " + tr("صفحة $number", "Page $number")
        val l = layout(text, 8.5f, Color.GRAY, false, contentW, Layout.Alignment.ALIGN_CENTER)
        draw(l, margin, yy)
    }

    /** رمز QR على جهة، ونص على الجهة الثانية */
    fun qrBlock(m: com.google.zxing.common.BitMatrix, text: String) {
        val size = 108f
        val l = layout(text, 9.5f, Color.DKGRAY, false, (contentW - size - 16).toInt(), Layout.Alignment.ALIGN_NORMAL)
        ensure(maxOf(size, l.height.toFloat()) + 8f)
        val qrX = if (en) pageW - margin - size else margin
        val cell = size / m.width
        val black = Paint().apply { color = Color.BLACK }
        for (yy in 0 until m.height) {
            for (xx in 0 until m.width) {
                if (m.get(xx, yy)) {
                    canvas.drawRect(qrX + xx * cell, y + yy * cell, qrX + (xx + 1) * cell, y + (yy + 1) * cell, black)
                }
            }
        }
        val tx = if (en) margin else margin + size + 16f
        draw(l, tx, y + 2f)
        y += maxOf(size, l.height.toFloat()) + 8f
    }

    private fun ensure(h: Float) {
        if (y + h > pageH - bottom) newPage()
    }

    private fun layout(text: String, size: Float, color: Int, bold: Boolean, width: Int, align: Layout.Alignment): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Fonts.bold else Fonts.regular
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, p, width.coerceAtLeast(10))
            .setAlignment(align)
            .setTextDirection(if (en) TextDirectionHeuristics.LTR else TextDirectionHeuristics.RTL)
            .build()
    }

    private fun draw(l: StaticLayout, x: Float, top: Float) {
        canvas.save()
        canvas.translate(x, top)
        l.draw(canvas)
        canvas.restore()
    }

    fun paragraph(
        text: String,
        size: Float = 11f,
        color: Int = Color.BLACK,
        bold: Boolean = false,
        gapAfter: Float = 6f,
        x: Float = margin,
        width: Int = contentW,
    ) {
        val l = layout(text, size, color, bold, width, Layout.Alignment.ALIGN_NORMAL)
        ensure(l.height.toFloat())
        draw(l, x, y)
        y += l.height + gapAfter
    }

    fun sectionTitle(t: String) {
        y += 12f
        ensure(52f)
        paragraph(t, 14f, BRAND_DARK, true, gapAfter = 3f)
        canvas.drawRect(margin, y, pageW - margin, y + 1.5f, accentPaint)
        y += 6f
    }

    /** سطر بنسبة وشريط ملوّن */
    fun bar(label: String, pct: Int, color: Int) {
        ensure(22f)
        val labelW = (contentW * 0.32f).toInt()
        val pctW = 40
        val barW = contentW - labelW - pctW - 12
        val l = layout(label, 10f, Color.DKGRAY, false, labelW, Layout.Alignment.ALIGN_NORMAL)
        val p = layout("$pct%", 10f, Color.BLACK, true, pctW, Layout.Alignment.ALIGN_OPPOSITE)
        val barTop = y + 4f
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFFEDEDED.toInt() }
        val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val fillW = barW * pct.coerceIn(0, 100) / 100f
        if (en) {
            draw(l, margin, y)
            val bx = margin + labelW + 6
            canvas.drawRoundRect(RectF(bx, barTop, bx + barW, barTop + 8f), 4f, 4f, bg)
            canvas.drawRoundRect(RectF(bx, barTop, bx + fillW, barTop + 8f), 4f, 4f, fg)
            draw(p, margin + labelW + 12 + barW, y)
        } else {
            val right = pageW - margin
            draw(l, right - labelW, y)
            val bxRight = right - labelW - 6
            canvas.drawRoundRect(RectF(bxRight - barW, barTop, bxRight, barTop + 8f), 4f, 4f, bg)
            canvas.drawRoundRect(RectF(bxRight - fillW, barTop, bxRight, barTop + 8f), 4f, 4f, fg)
            draw(p, margin, y)
        }
        y += maxOf(l.height.toFloat(), 16f) + 4f
    }

    fun row(label: String, value: String, valueColor: Int = Color.BLACK) {
        val half = contentW / 2
        val l1 = layout(label, 10.5f, Color.DKGRAY, false, half, Layout.Alignment.ALIGN_NORMAL)
        val l2 = layout(value, 10.5f, valueColor, true, half, Layout.Alignment.ALIGN_OPPOSITE)
        val h = maxOf(l1.height, l2.height).toFloat()
        ensure(h + 8f)
        // العنوان على جهة بداية القراءة، والقيمة على الجهة الثانية
        if (en) {
            draw(l1, margin, y)
            draw(l2, margin + half, y)
        } else {
            draw(l1, margin + half, y)
            draw(l2, margin, y)
        }
        y += h + 3f
        canvas.drawLine(margin, y, pageW - margin, y, linePaint)
        y += 4f
    }
}
