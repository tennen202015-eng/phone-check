package com.phonecheck.app

import android.content.Context
import android.util.Base64
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * مستويات الاستخدام:
 * - مجاني: اختبارات بسيطة، والنتائج على الشاشة فقط.
 * - فحص كامل لمرة واحدة: رمز موقّع مربوط بجوال واحد ولمدة محددة.
 * - مشترك (محل أو جوال زبون في محل): كل شي + التقرير المعتمد.
 */
object Access {

    /** الاختبارات القوية (للمشتركين والفحص الكامل) */
    val LOCKED: Set<Test> = setOf(
        Test.BATTERY, Test.CPU, Test.RAM, Test.STORAGE, Test.BURN_IN,
        Test.MULTITOUCH, Test.ACCOUNTS, Test.CHARGING,
    )

    /** كل الميزات مفتوحة */
    val full: Boolean get() = License.unlocked || Pass.valid

    /** تقرير معتمد باسم المحل */
    val certified: Boolean get() = License.unlocked

    fun locked(t: Test): Boolean = !full && t in LOCKED
}

/** رمز "فحص كامل لمرة واحدة": PCP1.<كود الجهاز>.<وقت الانتهاء>.<التوقيع> */
object Pass {
    private const val PREFS = "pass"
    const val PREFIX = "PCP1."

    // المفتاح العام (المفتاح الخاص في لوحة الإدارة عندك فقط)
    private const val PUBLIC_KEY =
        "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEaGVIARvXMxzeYt6mwRn77VpY3nbaeKbhZm/CNP46QfHRKY8i639zjAP5qF+zRR0Cpzljg/HFnNaXHxYHU3HW3Q=="

    var expiryMs: Long = 0L
        private set
    private var trustedNow: () -> Long = { System.currentTimeMillis() }

    val valid: Boolean get() = expiryMs > 0 && trustedNow() < expiryMs

    val hoursLeft: Int
        get() = if (!valid) 0 else ((expiryMs - trustedNow()) / 3_600_000L).toInt() + 1

    fun load(ctx: Context) {
        val app = ctx.applicationContext
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        expiryMs = p.getLong("exp", 0L)
        // الوقت الموثوق: الأكبر بين ساعة الجوال وآخر وقت خادم شفناه (عشان رجوع الساعة لورا ما يمدد الرمز)
        trustedNow = { maxOf(System.currentTimeMillis(), License.lastServerTime(app)) }
        // نتأكد إن الرمز المحفوظ لسه لنفس الجهاز
        val saved = p.getString("token", "") ?: ""
        if (saved.isNotBlank() && check(app, saved) == null) expiryMs = 0L
    }

    /** يفعّل الرمز. يرجع رسالة خطأ أو null لو نجح */
    fun activate(ctx: Context, raw: String): String? {
        val token = raw.trim().replace("\\s".toRegex(), "")
        val exp = check(ctx, token) ?: return tr(
            "الرمز غير صحيح أو مو لهذا الجوال. تأكد إنك أرسلت كود الجهاز الصحيح ونسخت الرمز كامل.",
            "Invalid code, or not for this phone. Make sure you sent the right device code and copied the whole code."
        )
        if (exp <= maxOf(System.currentTimeMillis(), License.lastServerTime(ctx))) {
            return tr("الرمز صحيح بس مدته انتهت.", "The code is valid but has expired.")
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("token", token).putLong("exp", exp).apply()
        load(ctx)
        return null
    }

    /** يتحقق من التوقيع ومن إن الرمز لهذا الجهاز، ويرجع وقت الانتهاء */
    private fun check(ctx: Context, token: String): Long? = try {
        require(token.startsWith(PREFIX))
        val parts = token.removePrefix(PREFIX).split(".")
        require(parts.size == 3)
        val code = parts[0]
        val expSec = parts[1].toLong()
        require(code == License.normKey(License.deviceCode(ctx)))
        val msg = (PREFIX + code + "." + parts[1]).toByteArray(Charsets.UTF_8)
        val sig = Base64.decode(parts[2], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        require(sig.size == 64)
        val key = KeyFactory.getInstance("EC").generatePublic(
            X509EncodedKeySpec(Base64.decode(PUBLIC_KEY, Base64.DEFAULT))
        )
        val ok = Signature.getInstance("SHA256withECDSA").run {
            initVerify(key)
            update(msg)
            verify(rawToDer(sig))
        }
        require(ok)
        expSec * 1000
    } catch (e: Exception) {
        null
    }

    /** المتصفح يوقّع بصيغة r||s، وجافا تبي DER */
    private fun rawToDer(raw: ByteArray): ByteArray {
        fun enc(b: ByteArray): ByteArray {
            var v = b.dropWhile { it.toInt() == 0 }.toByteArray()
            if (v.isEmpty()) v = byteArrayOf(0)
            if ((v[0].toInt() and 0x80) != 0) v = byteArrayOf(0) + v
            return byteArrayOf(0x02, v.size.toByte()) + v
        }
        val r = enc(raw.copyOfRange(0, 32))
        val s = enc(raw.copyOfRange(32, 64))
        return byteArrayOf(0x30, (r.size + s.size).toByte()) + r + s
    }
}
