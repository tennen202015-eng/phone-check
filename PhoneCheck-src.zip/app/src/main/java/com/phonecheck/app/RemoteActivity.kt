package com.phonecheck.app

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** فحص جوال ثاني: يعرض رابط صفحة الفحص، ثم يمسح رمز النتيجة ويطلّع التقرير */
class RemoteActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var snapshot: DeviceSnapshot? = null
    private val results = linkedMapOf<Test, Boolean>()

    private val scanner = registerForActivityResult(ScanContract()) { r ->
        val text = r.contents ?: return@registerForActivityResult
        if (!parse(text)) {
            PcDialog(this)
                .setTitle(tr("الرمز غير صالح", "Invalid code"))
                .setMessage(tr("هذا مو رمز نتيجة من صفحة فاحص الجوال. امسح الرمز اللي يطلع في آخر صفحة الفحص.", "This is not a Phone Check result code. Scan the code shown at the end of the test page."))
                .setPositiveButton(tr("امسح مرة ثانية", "Scan again")) { _, _ -> scan() }
                .setNegativeButton(tr("إلغاء", "Cancel"), null)
                .show()
        } else {
            render()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            layoutDirection = Lang.dir
            setBackgroundColor(BG)
            addView(root)
        }
        setContentView(scroll)
        window.statusBarColor = PETROL
        render()
    }

    private fun scan() {
        val opts = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt(tr("امسح الرمز اللي على شاشة الجوال المفحوص", "Scan the code on the inspected phone's screen"))
            .setBeepEnabled(false)
            .setOrientationLocked(false)
        scanner.launch(opts)
    }

    // ---------- قراءة النتيجة ----------
    private fun parse(code: String): Boolean = try {
        require(code.startsWith("PCK1."))
        val json = String(
            Base64.decode(code.removePrefix("PCK1."), Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP),
            Charsets.UTF_8
        )
        val o = JSONObject(json)
        results.clear()
        val r = o.optJSONObject("r") ?: JSONObject()
        for ((key, test) in REMOTE_KEYS) {
            if (r.has(key)) results[test] = r.optInt(key, 0) == 1
        }

        val name = o.optString("n").trim().ifBlank { tr("جوال غير محدد", "Unspecified phone") }
        val items = mutableListOf<InfoItem>()
        o.optString("os").takeIf { it.isNotBlank() }?.let { items += InfoItem(tr("النظام", "OS"), it) }
        o.optString("scr").takeIf { it.isNotBlank() }?.let { items += InfoItem(tr("دقة الشاشة", "Screen resolution"), it) }
        if (o.has("cores") && !o.isNull("cores")) items += InfoItem(tr("أنوية المعالج", "CPU cores"), o.optInt("cores").toString())
        if (o.has("mem") && !o.isNull("mem")) items += InfoItem(tr("الرام (تقريبي)", "RAM (approx.)"), tr("${o.optDouble("mem").toInt()} GB أو أكثر", "${o.optDouble("mem").toInt()} GB or more"))
        if (o.has("bat") && !o.isNull("bat")) items += InfoItem(tr("نسبة البطارية وقت الفحص", "Battery level at test"), "${o.optInt("bat")}%")
        val ts = o.optLong("ts", System.currentTimeMillis())
        items += InfoItem(tr("وقت الفحص", "Tested at"), SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(ts)))
        items += InfoItem(tr("طريقة الفحص", "Method"), tr("عن بُعد عبر المتصفح", "Remote, via browser"))

        snapshot = DeviceSnapshot(
            deviceName = name,
            sections = listOf(InfoSection(tr("معلومات الجهاز", "Device info"), items)),
            batteryHealthCode = BatteryManager.BATTERY_HEALTH_UNKNOWN,
            batteryTempC = 0f,
            batteryEstimatePct = null,
            cycleCount = null,
            sensorsFound = 0,
            sensorsExpected = 0,
            rooted = false,
            remote = true,
        )
        true
    } catch (e: Exception) {
        false
    }

    // ---------- الواجهة ----------
    private fun render() {
        root.removeAllViews()
        val snap = snapshot
        if (snap == null) renderSetup() else renderResult(snap)
    }

    private fun header(title: String, sub: String): View {
        val r = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(22))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        box.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT))
        box.addView(text(title, 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
        if (sub.isNotBlank()) box.addView(text(sub, 14f, Fonts.regular, LIGHT).apply { setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun renderSetup() {
        root.addView(header(tr("فحص جوال ثاني", "Inspect another phone"), tr("بدون تثبيت أي تطبيق على الجوال المفحوص. يشتغل على الآيفون والأندرويد.", "No app install needed on the inspected phone. Works on iPhone and Android.")))
        val body = body()

        // الخطوة 1
        body.addView(stepHeading("1", tr("افتح صفحة الفحص على الجوال المفحوص", "Open the test page on the inspected phone")))
        val s1 = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        s1.addView(text(tr("خلّ الجوال المفحوص يمسح هذا الرمز بكاميرته، أو أرسل له الرابط.", "Let the inspected phone scan this code with its camera, or send it the link."), 14f, Fonts.regular, SLATE))
        val qr = try {
            BarcodeEncoder().encodeBitmap(WEB_URL, BarcodeFormat.QR_CODE, 640, 640)
        } catch (e: Exception) {
            null
        }
        if (qr != null) {
            s1.addView(ImageView(this).apply {
                setImageBitmap(qr)
                adjustViewBounds = true
            }, LinearLayout.LayoutParams(dp(220), dp(220)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(12)
            })
        }
        s1.addView(text(WEB_URL, 12f, Fonts.regular, SLATE).apply {
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        s1.addView(pill(tr("أرسل الرابط", "Send link"), PETROL, PETROL, filled = false) { shareLink() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
        body.addView(s1, blockParams())

        // الخطوة 2
        body.addView(stepHeading("2", tr("امسح رمز النتيجة", "Scan the result code")))
        val s2 = surface().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        s2.addView(text(tr("لما يخلص الجوال المفحوص الاختبارات، بيطلع رمز على شاشته. امسحه من هنا ويطلع لك التقرير.", "When the inspected phone finishes, a code appears on its screen. Scan it here to get the report."), 14f, Fonts.regular, SLATE))
        s2.addView(pill(tr("امسح النتيجة", "Scan result"), PETROL, Color.WHITE, filled = true) { scan() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) })
        body.addView(s2, blockParams())

        body.addView(text(
            tr("ملاحظة: المتصفح ما يسمح بقراءة صحة البطارية والمعالج والبصمة وسماعة المكالمات، فهذي ما تدخل في الفحص عن بُعد.", "Note: browsers cannot read battery health, chipset, fingerprint or earpiece, so these are not part of remote inspection."),
            13f, Fonts.regular, SLATE
        ).apply { setPadding(dp(4), dp(8), dp(4), 0) })
    }

    private fun renderResult(snap: DeviceSnapshot) {
        val sc = Scoring.compute(snap, results)
        root.addView(header(snap.deviceName, tr("نتيجة الفحص عن بُعد", "Remote inspection result")))
        val body = body()

        val scoreBox = surface().apply {
            setPadding(dp(16), dp(18), dp(16), dp(18))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scoreBox.addView(text("${sc.percent}", 56f, Fonts.bold, Scoring.gradeColor(sc.percent)).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        })
        scoreBox.addView(text(tr("من 100", "out of 100") + "  —  ${sc.grade}", 16f, Fonts.medium, TEXT).apply { gravity = Gravity.CENTER })
        scoreBox.addView(text(tr("مبني على ${sc.tested} من ${sc.total} اختبار", "Based on ${sc.tested} of ${sc.total} tests"), 13f, Fonts.regular, SLATE).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        body.addView(scoreBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16); bottomMargin = dp(10) })

        body.addView(plainHeading(tr("نتائج الاختبارات", "Test results")))
        val list = surface()
        REMOTE_TESTS.forEachIndexed { i, t ->
            if (i > 0) list.addView(divider(dp(56)))
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            val r = results[t]
            row.addView(mark(r), LinearLayout.LayoutParams(dp(28), dp(28)))
            row.addView(text(t.title, 15f, Fonts.medium, TEXT), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
            row.addView(text(when (r) { true -> tr("سليم", "Pass"); false -> tr("فيه مشكلة", "Fail"); null -> tr("لم يُختبر", "Not tested") }, 13f, Fonts.medium,
                when (r) { true -> GREEN; false -> RED; null -> SLATE }))
            list.addView(row)
        }
        body.addView(list, blockParams())

        body.addView(plainHeading(tr("معلومات الجهاز", "Device info")))
        val info = surface().apply { setPadding(dp(16), dp(8), dp(16), dp(8)) }
        for (item in snap.sections.first().items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            row.addView(text(item.label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(item.value, 14f, Fonts.medium, TEXT).apply { gravity = Gravity.END })
            info.addView(row)
        }
        body.addView(info, blockParams())

        val btns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        btns.addView(pill(tr("عرض التقرير", "View report"), PETROL, Color.WHITE, filled = true) { openReport(false) },
            LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(6) })
        btns.addView(pill(tr("مشاركة", "Share"), PETROL, PETROL, filled = false) { openReport(true) },
            LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(6) })
        body.addView(btns)
        body.addView(pill(tr("افحص جوال آخر", "Inspect another"), SLATE, SLATE, filled = false) {
            snapshot = null
            results.clear()
            lastReport = null
            render()
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
    }

    // ---------- مشاركة ----------
    private fun shareLink() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, tr("افتح هذا الرابط من الجوال اللي تبي تفحصه: ", "Open this link on the phone you want to inspect: ") + WEB_URL)
        }
        startActivity(Intent.createChooser(i, tr("أرسل الرابط", "Send link")))
    }

    private var lastReport: Pair<String, java.io.File>? = null

    private fun openReport(share: Boolean) {
        val snap = snapshot ?: return
        val key = listOf(snap.deviceName, results, Lang.en).toString()
        val cached = lastReport?.takeIf { it.first == key && it.second.exists() }?.second
        val file = cached ?: try {
            ReportPdf.create(this, snap, Scoring.compute(snap, results), results, REMOTE_TESTS)
                .also { lastReport = key to it }
        } catch (e: Exception) {
            Toast.makeText(this, tr("تعذّر إنشاء التقرير: ", "Could not create the report: ") + e.message, Toast.LENGTH_LONG).show()
            return
        }
        openPdf(file, share)
    }

    // ---------- عناصر مشتركة ----------
    private fun body(): LinearLayout {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(36))
        }
        root.addView(b)
        return b
    }

    private fun stepHeading(num: String, title: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(24), dp(4), dp(10))
        }
        row.addView(TextView(this).apply {
            text = num
            textSize = 14f
            typeface = Fonts.bold
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            includeFontPadding = false
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(PETROL)
            }
        }, LinearLayout.LayoutParams(dp(26), dp(26)))
        row.addView(text(title, 17f, Fonts.bold, TEXT), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        return row
    }

    private fun plainHeading(title: String): View =
        text(title, 18f, Fonts.bold, TEXT).apply { setPadding(dp(4), dp(16), dp(4), dp(10)) }

    private fun mark(r: Boolean?): View = TextView(this).apply {
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Fonts.bold
        includeFontPadding = false
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            when (r) {
                true -> setColor(PASS_BG)
                false -> setColor(FAIL_BG)
                null -> {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), LINE)
                }
            }
        }
        text = when (r) {
            true -> "✓"
            false -> "✕"
            null -> ""
        }
        setTextColor(if (r == true) GREEN else RED)
    }

    private fun surface(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(20).toFloat()
        }
        clipToOutline = true
    }

    private fun blockParams() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }

    private fun divider(insetStart: Int): View = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { marginStart = insetStart }
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun pill(label: String, bg: Int, fg: Int, filled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            textSize = 15f
            typeface = Fonts.bold
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                if (filled) setColor(bg) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), bg)
                }
            }
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
