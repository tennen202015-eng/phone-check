package com.phonecheck.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * اختبار اللمس: كل المربعات لازم تتلون بالأخضر.
 * زر "فيه منطقة ما تستجيب" يظهر بعد 3 ثواني بدون لمس = فشل.
 * زر الرجوع = إيقاف الفحص.
 */
class TouchTestActivity : AppCompatActivity() {

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private lateinit var failBtn: TextView
    private val showFail = Runnable { failBtn.visibility = View.VISIBLE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        val frame = FrameLayout(this)
        lateinit var hint: TextView
        val grid = TouchGridView(this, onTouch = {
            hint.visibility = View.GONE
            failBtn.visibility = View.GONE
            handler.removeCallbacks(showFail)
            handler.postDelayed(showFail, 3000)
        }) {
            setResult(Activity.RESULT_OK)
            finish()
        }
        frame.addView(grid, FrameLayout.LayoutParams(-1, -1))
        hint = TextView(this).apply {
            text = tr(
                "مرّر إصبعك على كل المربعات حتى تصير خضراء\n\nللإيقاف اضغط رجوع",
                "Swipe over every square until all turn green\n\nPress Back to stop"
            )
            setTextColor(Color.DKGRAY)
            textSize = 16f
            typeface = Fonts.medium
            gravity = Gravity.CENTER
            setPadding(40, 0, 40, 0)
        }
        frame.addView(hint, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        val d = resources.displayMetrics.density
        failBtn = TextView(this).apply {
            text = tr("فيه منطقة ما تستجيب", "An area does not respond")
            textSize = 14f
            typeface = Fonts.bold
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding((18 * d).toInt(), (12 * d).toInt(), (18 * d).toInt(), (12 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 24 * d
                setColor(0xDD14272C.toInt())
            }
            visibility = View.VISIBLE
            setOnClickListener {
                setResult(RESULT_FIRST_USER)
                finish()
            }
        }
        frame.addView(failBtn, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = (40 * d).toInt()
        })
        setContentView(frame)
        goFullscreen()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

class TouchGridView(
    ctx: Context,
    private val onTouch: () -> Unit = {},
    private val onComplete: () -> Unit,
) : View(ctx) {
    private val cols = 8
    private val rows = 14
    private val done = Array(rows) { BooleanArray(cols) }
    private var count = 0
    private var finished = false

    private val fill = Paint().apply { color = 0xFF43A047.toInt() }
    private val line = Paint().apply {
        color = Color.LTGRAY
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    init {
        setBackgroundColor(Color.WHITE)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cw = width / cols.toFloat()
        val ch = height / rows.toFloat()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val l = c * cw
                val t = r * ch
                if (done[r][c]) canvas.drawRect(l, t, l + cw, t + ch, fill)
                canvas.drawRect(l, t, l + cw, t + ch, line)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        onTouch()
        for (h in 0 until e.historySize) {
            for (i in 0 until e.pointerCount) mark(e.getHistoricalX(i, h), e.getHistoricalY(i, h))
        }
        for (i in 0 until e.pointerCount) mark(e.getX(i), e.getY(i))
        invalidate()
        if (!finished && count == rows * cols) {
            finished = true
            postDelayed({ onComplete() }, 300)
        }
        return true
    }

    private fun mark(x: Float, y: Float) {
        if (width == 0 || height == 0) return
        val c = (x / (width / cols.toFloat())).toInt().coerceIn(0, cols - 1)
        val r = (y / (height / rows.toFloat())).toInt().coerceIn(0, rows - 1)
        if (!done[r][c]) {
            done[r][c] = true
            count++
        }
    }
}
