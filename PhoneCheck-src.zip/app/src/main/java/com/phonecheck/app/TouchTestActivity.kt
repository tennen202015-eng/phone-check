package com.phonecheck.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** اختبار اللمس: كل المربعات لازم تتلون بالأخضر */
class TouchTestActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val frame = FrameLayout(this)
        val grid = TouchGridView(this) {
            setResult(Activity.RESULT_OK)
            finish()
        }
        frame.addView(grid, FrameLayout.LayoutParams(-1, -1))
        val hint = TextView(this).apply {
            text = "مرّر إصبعك على كل المربعات حتى تصير خضراء\n\nإذا فيه منطقة ما تستجيب، اضغط رجوع"
            setTextColor(Color.DKGRAY)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(40, 0, 40, 0)
        }
        frame.addView(hint, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        setContentView(frame)
        goFullscreen()
    }
}

class TouchGridView(ctx: Context, private val onComplete: () -> Unit) : View(ctx) {
    private val cols = 8
    private val rows = 14
    private val done = Array(rows) { BooleanArray(cols) }
    private var count = 0
    private var finished = false

    private val fill = Paint().apply { color = 0xFF43A047.toInt() }
    private val line = Paint().apply {
        color = Color.LTGRAY
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    init {
        setBackgroundColor(Color.WHITE)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cw = width / cols.toFloat()
        val ch = height / rows.toFloat()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val l = c * cw
                val t = r * ch
                if (done[r][c]) canvas.drawRect(l, t, l + cw, t + ch, fill)
                canvas.drawRect(l, t, l + cw, t + ch, line)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        for (h in 0 until e.historySize) {
            for (i in 0 until e.pointerCount) mark(e.getHistoricalX(i, h), e.getHistoricalY(i, h))
        }
        for (i in 0 until e.pointerCount) mark(e.getX(i), e.getY(i))
        invalidate()
        if (!finished && count == rows * cols) {
            finished = true
            postDelayed({ onComplete() }, 300)
        }
        return true
    }

    private fun mark(x: Float, y: Float) {
        if (width == 0 || height == 0) return
        val c = (x / (width / cols.toFloat())).toInt().coerceIn(0, cols - 1)
        val r = (y / (height / rows.toFloat())).toInt().coerceIn(0, rows - 1)
        if (!done[r][c]) {
            done[r][c] = true
            count++
        }
    }
}
