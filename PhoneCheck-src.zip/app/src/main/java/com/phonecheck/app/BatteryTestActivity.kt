package com.phonecheck.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

/**
 * فحص البطارية العميق، 4 خطوات:
 * 1) سؤال الانتفاخ
 * 2) المقاومة الداخلية: بحمل على المعالج لو الجوال يسمح بقراءة الجهد باستمرار،
 *    وإلا بطريقة فصل وتوصيل الشاحن (الجوال يحدّث الجهد فوراً لحظة التغيير)
 * 3) قياس السعة الفعلية أثناء الشحن
 * 4) النتيجة
 */
class BatteryTestActivity : AppCompatActivity() {

    private enum class Step { SWELL, RESIST, CHARGE, TOGGLE, DONE }
    private enum class TPhase { WAIT_PLUG, WAIT_UNPLUG, UNPLUGGED, READING, DONE }
    private enum class RPhase { WAIT_UNPLUG, IDLE, LOAD, DONE }
    private enum class CPhase { WAIT_PLUG, MEASURE, DONE }

    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bm: BatteryManager

    private var step = Step.SWELL
    private var swollen = false

    /** true = الجوال يسمح بقراءة الجهد من ملفات النظام، فنستخدم اختبار الحمل */
    private var useLoadTest = false

    // ---------- المقاومة بطريقة فصل/توصيل الشاحن ----------
    private var tPhase = TPhase.WAIT_PLUG
    private var tPhaseStart = 0L
    private var prevPlugged: Boolean? = null
    private var vUnplug: Int? = null
    private var iDischarge: Int? = null
    private var toggleRounds = 0
    private val toggleR = mutableListOf<Int>()

    // قراءات البث الأخيرة
    private var last: Intent? = null
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            last = i
            val v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            val p = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val before = prevPlugged
            prevPlugged = p
            if (before != null && before != p) onPlugEvent(p, v)
            // نجمع الجهد من البث فقط لو ملفات النظام مو متاحة
            if (sysVoltOk == false && v in 2500..5000) {
                when (rPhase) {
                    RPhase.IDLE -> idleV += v
                    RPhase.LOAD -> if (SystemClock.elapsedRealtime() - phaseStart > 3000) loadV += v
                    else -> {}
                }
            }
        }
    }

    // ---------- المقاومة الداخلية ----------
    private var rPhase = RPhase.WAIT_UNPLUG
    private var phaseStart = 0L
    private var sysVoltOk: Boolean? = null
    private val idleV = mutableListOf<Int>()
    private val loadV = mutableListOf<Int>()
    private val idleI = mutableListOf<Int>()
    private val loadI = mutableListOf<Int>()
    private val loadRunning = AtomicBoolean(false)
    private var irMohm: Int? = null
    private var irNote = ""

    // ---------- السعة ----------
    private var cPhase = CPhase.WAIT_PLUG
    private var measureStart = 0L
    private var lastTick = 0L
    private var lastLevel = -1
    private var integMah = 0.0
    private var ccOk = true
    private class Point(val level: Int, val ccUah: Long?, val integ: Double)
    private val points = mutableListOf<Point>()
    private var measuredMah: Int? = null
    private var method = -1
    private var levelDelta = 0

    private var maxTemp = 0f
    private var report: BatteryReport? = null

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        useLoadTest = BatteryProbe.sysVoltageMv() != null
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = PETROL
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(ScrollView(this).apply {
            layoutDirection = Lang.dir
            setBackgroundColor(BG)
            addView(root)
        })
        last = registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        render()
        handler.postDelayed(tick, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopLoad()
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
            // تجاهل
        }
        super.onDestroy()
    }

    // ---------- قراءات ----------
    private fun plugged(): Boolean = (last?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

    private fun level(): Int {
        val l = last?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = last?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l >= 0 && s > 0) l * 100 / s else -1
    }

    private fun tempC(): Float = (last?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

    private fun currentMa(): Int? = BatteryProbe.currentMa(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))

    private fun chargeCounter(): Long? =
        BatteryProbe.chargeCounterUah(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER))

    private fun cycles(): Int? {
        if (Build.VERSION.SDK_INT >= 34) {
            last?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)?.takeIf { it > 0 }?.let { return it }
        }
        return BatteryProbe.sysCycles()
    }

    // ---------- التشغيل الدوري ----------
    private fun onTick() {
        val t = tempC()
        if (t > maxTemp) maxTemp = t
        when (step) {
            Step.RESIST -> tickResist()
            Step.CHARGE -> tickCharge()
            Step.TOGGLE -> if (tPhase == TPhase.WAIT_UNPLUG || tPhase == TPhase.UNPLUGGED) render()
            else -> {}
        }
    }

    private fun tickResist() {
        val now = SystemClock.elapsedRealtime()
        when (rPhase) {
            RPhase.WAIT_UNPLUG -> if (!plugged()) {
                rPhase = RPhase.IDLE
                phaseStart = now
                sysVoltOk = BatteryProbe.sysVoltageMv() != null
                render()
            }
            RPhase.IDLE -> {
                if (plugged()) return restartResist()
                sample(idleV, idleI)
                if (now - phaseStart > 8000) {
                    rPhase = RPhase.LOAD
                    phaseStart = now
                    startLoad()
                }
                render()
            }
            RPhase.LOAD -> {
                if (plugged()) return restartResist()
                // نتجاهل أول 3 ثواني لين يستقر الحمل
                if (now - phaseStart > 3000) sample(loadV, loadI)
                if (now - phaseStart > 15000) {
                    stopLoad()
                    computeResistance()
                    rPhase = RPhase.DONE
                }
                render()
            }
            RPhase.DONE -> {}
        }
    }

    private fun sample(vList: MutableList<Int>, iList: MutableList<Int>) {
        if (sysVoltOk == true) BatteryProbe.sysVoltageMv()?.let { vList += it }
        currentMa()?.let { iList += it }
    }

    private fun restartResist() {
        stopLoad()
        idleV.clear(); loadV.clear(); idleI.clear(); loadI.clear()
        rPhase = RPhase.WAIT_UNPLUG
        render()
    }

    private fun computeResistance() {
        if (idleV.isEmpty() || loadV.isEmpty() || idleI.isEmpty() || loadI.isEmpty()) {
            irMohm = null
            irNote = tr("الجهاز ما يعطي قراءات جهد كافية لهذا القياس.", "This device does not report enough voltage readings for this test.")
            return
        }
        val vi = idleV.average()
        val vl = loadV.average()
        val ii = idleI.average()
        val il = loadI.average()
        val dI = il - ii
        val dV = vi - vl
        if (dI < 150 || dV <= 0) {
            irMohm = null
            irNote = tr("فرق الحمل كان صغير جداً، فالقياس غير موثوق.", "The load difference was too small for a reliable reading.")
            return
        }
        val r = (dV / dI * 1000).roundToInt()
        irMohm = r.takeIf { it in 20..2000 }
        irNote = if (irMohm == null) tr("القراءة خارج المعقول، فتم تجاهلها.", "Reading out of range, ignored.") else ""
    }

    private fun startLoad() {
        loadRunning.set(true)
        window.attributes = window.attributes.also { it.screenBrightness = 1f }
        repeat(Runtime.getRuntime().availableProcessors()) {
            Thread {
                var x = 0.0
                while (loadRunning.get()) {
                    for (k in 1..20000) x += Math.sqrt(k.toDouble() + x % 7)
                }
            }.apply { priority = Thread.MAX_PRIORITY }.start()
        }
    }

    private fun stopLoad() {
        if (!loadRunning.getAndSet(false)) return
        window.attributes = window.attributes.also {
            it.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
    }

    private fun tickCharge() {
        val now = SystemClock.elapsedRealtime()
        when (cPhase) {
            CPhase.WAIT_PLUG -> if (plugged()) {
                cPhase = CPhase.MEASURE
                measureStart = now
                lastTick = now
                lastLevel = level()
                integMah = 0.0
                points.clear()
                render()
            }
            CPhase.MEASURE -> {
                if (!plugged()) {
                    // انفصل الشاحن: نوقف القياس ونرجع ننتظر
                    cPhase = CPhase.WAIT_PLUG
                    render()
                    return
                }
                val dtH = (now - lastTick) / 3_600_000.0
                lastTick = now
                currentMa()?.let { integMah += it * dtH }
                val lv = level()
                if (lv > lastLevel && lastLevel >= 0) {
                    val cc = chargeCounter()
                    if (cc == null) ccOk = false
                    points += Point(lv, cc, integMah)
                }
                lastLevel = lv
                levelDelta = if (points.size >= 2) points.last().level - points.first().level else 0
                if (levelDelta >= 8 || now - measureStart > 20 * 60_000) {
                    finishCharge()
                    return
                }
                render()
            }
            CPhase.DONE -> {}
        }
    }

    /** السعة = الطاقة اللي دخلت ÷ النسبة اللي زادت × 100 */
    private fun estimateCapacity(): Pair<Int, Int>? {
        if (points.size < 2) return null
        val a = points.first()
        val b = points.last()
        val d = b.level - a.level
        if (d < 2) return null
        if (ccOk && a.ccUah != null && b.ccUah != null && b.ccUah > a.ccUah) {
            return ((b.ccUah - a.ccUah) / 1000.0 / d * 100).roundToInt() to 0
        }
        val dm = b.integ - a.integ
        if (dm > 0) return (dm / d * 100).roundToInt() to 1
        return null
    }

    private fun finishCharge() {
        cPhase = CPhase.DONE
        val est = estimateCapacity()
        val design = DesignCapacity.resolve(this)?.first
        val sane = est?.first?.let { c ->
            if (design != null) c in (design * 0.3).toInt()..(design * 1.5).toInt() else c in 1000..10000
        } ?: false
        if (est != null && sane && levelDelta >= 3) {
            measuredMah = est.first
            method = est.second
        } else {
            measuredMah = null
            method = -1
        }
        if (useLoadTest) {
            step = Step.DONE
            buildReport()
        } else {
            step = Step.TOGGLE
            tPhase = if (plugged()) TPhase.WAIT_UNPLUG else TPhase.WAIT_PLUG
            tPhaseStart = SystemClock.elapsedRealtime()
        }
        render()
    }

    // ---------- المقاومة: فصل وتوصيل الشاحن ----------
    // لحظة الفصل والتوصيل يتغيّر التيار بقوة (من شحن لتفريغ والعكس) والجوال يحدّث قراءة الجهد فوراً.
    // المقاومة = فرق الجهد ÷ فرق التيار. نكررها مرتين ونأخذ المتوسط.
    private fun onPlugEvent(nowPlugged: Boolean, v: Int) {
        if (step != Step.TOGGLE) return
        val now = SystemClock.elapsedRealtime()
        when {
            tPhase == TPhase.WAIT_PLUG && nowPlugged -> {
                tPhase = TPhase.WAIT_UNPLUG
                tPhaseStart = now
            }
            tPhase == TPhase.WAIT_UNPLUG && !nowPlugged -> {
                vUnplug = v.takeIf { it in 2500..5000 }
                iDischarge = null
                tPhase = TPhase.UNPLUGGED
                tPhaseStart = now
                handler.postDelayed({ iDischarge = currentMa() }, 1200)
            }
            tPhase == TPhase.UNPLUGGED && nowPlugged -> {
                if (now - tPhaseStart < 5000) {
                    // وصّله بسرعة: نعيد الجولة
                    tPhase = TPhase.WAIT_UNPLUG
                    tPhaseStart = now
                } else {
                    val vu = vUnplug
                    val id = iDischarge
                    tPhase = TPhase.READING
                    handler.postDelayed({
                        val ic = currentMa()
                        if (vu != null && id != null && ic != null && v in 2500..5000) {
                            val dI = ic + id
                            val dV = v - vu
                            if (dI >= 300 && dV > 3) {
                                val r = dV * 1000 / dI
                                if (r in 20..2000) toggleR += r
                            }
                        }
                        toggleRounds++
                        if (toggleRounds >= 2) {
                            finishToggle()
                        } else {
                            tPhase = TPhase.WAIT_UNPLUG
                            tPhaseStart = SystemClock.elapsedRealtime()
                        }
                        render()
                    }, 1200)
                }
            }
            else -> return
        }
        render()
    }

    private fun finishToggle(skipped: Boolean = false) {
        if (toggleR.isNotEmpty()) {
            irMohm = toggleR.average().roundToInt()
            irNote = ""
        } else {
            irMohm = null
            irNote = if (skipped) tr("تم التخطي", "Skipped") else tr(
                "ما قدرنا نقيس المقاومة في هذا الجهاز: قراءات الجهد ما تغيّرت كفاية وقت فصل وتوصيل الشاحن.",
                "Could not measure resistance on this device: voltage readings did not change enough when unplugging and plugging the charger."
            )
        }
        tPhase = TPhase.DONE
        step = Step.DONE
        buildReport()
    }

    private fun renderToggle(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("المقاومة الداخلية", "Internal resistance")))
        c.addView(para(tr(
            "البطارية المتعبة يتغيّر جهدها بقوة لما يتغيّر الحمل، وهذا سبب الطفي المفاجئ. بنقيس الجهد لحظة فصل الشاحن وتوصيله، مرتين.",
            "A worn battery's voltage swings strongly when the load changes, which causes sudden shutdowns. We measure the voltage the moment the charger is unplugged and plugged in, twice."
        )))
        val now = SystemClock.elapsedRealtime()
        val round = (toggleRounds + 1).coerceAtMost(2)
        val status = when (tPhase) {
            TPhase.WAIT_PLUG -> tr("وصّل الشاحن…", "Plug in the charger…")
            TPhase.WAIT_UNPLUG -> {
                val left = ((5000 - (now - tPhaseStart)) / 1000).coerceAtLeast(0)
                tr("الجولة $round من 2: ", "Round $round of 2: ") +
                    if (left > 0) tr("خلّ الشاحن موصول ($left ث)…", "keep the charger plugged in (${left}s)…")
                    else tr("افصل الشاحن الآن", "unplug the charger now")
            }
            TPhase.UNPLUGGED -> {
                val left = ((8000 - (now - tPhaseStart)) / 1000).coerceAtLeast(0)
                tr("الجولة $round من 2: ", "Round $round of 2: ") +
                    if (left > 0) tr("انتظر $left ث بدون شاحن…", "wait ${left}s unplugged…")
                    else tr("وصّل الشاحن الآن", "plug the charger back in now")
            }
            TPhase.READING -> tr("جاري القياس…", "Measuring…")
            TPhase.DONE -> ""
        }
        c.addView(text(status, 16f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, 0) })
        if (toggleR.isNotEmpty()) {
            c.addView(para(tr("القراءات: ", "Readings: ") + toggleR.joinToString("، ") { "$it mΩ" }))
        }
        if (level() >= 95) c.addView(para(tr(
            "تنبيه: البطارية قريبة من 100%، فتيار الشحن ضعيف والقياس ممكن ما ينجح.",
            "Note: the battery is near 100%, so charging current is low and the test may not succeed."
        )).apply { setTextColor(0xFFC98A1B.toInt()) })
        c.addView(link(tr("تخطّي هذه الخطوة", "Skip this step")) {
            finishToggle(skipped = true)
            render()
        })
    }

    private fun buildReport() {
        val design = DesignCapacity.resolve(this)
        val cyc = cycles()
        var m = method
        var health: Int? = null
        if (measuredMah != null && design != null) {
            health = (measuredMah!! * 100.0 / design.first).roundToInt().coerceIn(0, 100)
        } else if (cyc != null) {
            // تقدير تقريبي: أغلب البطاريات توصل 80% تقريباً بعد 800 دورة
            health = (100 - cyc * 0.025).roundToInt().coerceIn(50, 100)
            m = 2
        }
        val confidence = when {
            m in 0..1 && levelDelta >= 8 && design != null && design.second != CapSource.SYSTEM -> 2
            m in 0..1 -> 1
            else -> 0
        }
        var verdict = when {
            health == null -> 1
            health >= 85 -> 0
            health >= 80 -> 1
            health >= 70 -> 2
            else -> 3
        }
        irMohm?.let {
            if (it > 400) verdict = maxOf(verdict, 3) else if (it > 280) verdict = maxOf(verdict, 2)
        }
        if (maxTemp > 50f) verdict = maxOf(verdict, 3) else if (maxTemp > 45f) verdict = maxOf(verdict, 2)
        if (swollen) verdict = 4

        report = BatteryReport(
            healthPct = health,
            confidence = confidence,
            measuredMah = measuredMah,
            designMah = design?.first,
            designSource = design?.second,
            method = m,
            levelDelta = levelDelta,
            cycles = cyc,
            irMohm = irMohm,
            maxTempC = maxTemp.takeIf { it > 0f },
            swollen = swollen,
            verdict = verdict,
        )
    }

    private fun save() {
        val r = report ?: return
        Results.battery = r
        Results.details[Test.BATTERY] = r.summary
        setResult(if (r.passed) RESULT_OK else RESULT_FIRST_USER)
        finish()
    }

    // ---------- الواجهة ----------
    private fun render() {
        root.removeAllViews()
        root.addView(header())
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(36))
        }
        root.addView(body)
        body.addView(stepsBar(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        when (step) {
            Step.SWELL -> renderSwell(body)
            Step.RESIST -> renderResist(body)
            Step.CHARGE -> renderCharge(body)
            Step.TOGGLE -> renderToggle(body)
            Step.DONE -> renderDone(body)
        }
    }

    private fun header(): View {
        val r = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(22))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text("✕  " + tr("إيقاف", "Stop"), 14f, Fonts.bold, Color.WHITE).apply {
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), LIGHT)
            }
            setOnClickListener { finish() }
        })
        box.addView(top)
        box.addView(text(tr("فحص البطارية العميق", "Deep battery test"), 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
        val lv = level()
        val live = tr("الشحن الآن", "Now") + ": " + (if (lv >= 0) "$lv%" else "-") +
            "   ·   " + String.format(Locale.US, "%.1f°C", tempC()) +
            "   ·   " + (if (plugged()) tr("على الشاحن", "Charging") else tr("بدون شاحن", "On battery"))
        box.addView(text(live, 13f, Fonts.regular, LIGHT).apply { setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun stepsBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val order = if (useLoadTest) listOf(Step.SWELL, Step.RESIST, Step.CHARGE, Step.DONE)
        else listOf(Step.SWELL, Step.CHARGE, Step.TOGGLE, Step.DONE)
        val cur = order.indexOf(step)
        order.forEachIndexed { i, st ->
            val n = when (st) {
                Step.SWELL -> tr("الشكل", "Shape")
                Step.RESIST, Step.TOGGLE -> tr("المقاومة", "Resistance")
                Step.CHARGE -> tr("السعة", "Capacity")
                Step.DONE -> tr("النتيجة", "Result")
            }
            val state = when {
                i < cur -> 2
                i == cur -> 1
                else -> 0
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            col.addView(View(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(3).toFloat()
                    setColor(if (state > 0) PETROL else LINE)
                }
            }, LinearLayout.LayoutParams(-1, dp(5)))
            col.addView(text(n, 12f, if (state == 1) Fonts.bold else Fonts.regular, if (state > 0) TEXT else GRAY).apply {
                setPadding(0, dp(6), 0, 0)
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (i > 0) marginStart = dp(6)
            })
        }
        return row
    }

    private fun renderSwell(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("هل البطارية منتفخة؟", "Is the battery swollen?")))
        c.addView(para(tr(
            "شيّك بعينك: هل الشاشة مرفوعة من الطرف، أو الغطاء الخلفي منفوخ أو فيه فراغ، أو الجوال ما يستقر على الطاولة ويهتز لما تضغط على وسطه؟",
            "Check by eye: is the screen lifting at an edge, the back cover bulging or gapped, or does the phone rock when pressed in the middle on a table?"
        )))
        c.addView(row2(
            pill(tr("لا، سليمة", "No, looks normal"), PETROL, Color.WHITE, true) {
                swollen = false
                step = if (useLoadTest) Step.RESIST else Step.CHARGE
                render()
            },
            pill(tr("نعم، منتفخة", "Yes, swollen"), RED, RED, false) {
                swollen = true
                step = Step.DONE
                buildReport()
                render()
            }
        ))
    }

    private fun renderResist(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("المقاومة الداخلية", "Internal resistance")))
        c.addView(para(tr(
            "البطارية المتعبة يهبط جهدها بسرعة تحت الحمل، وهذا سبب الطفي المفاجئ. بنشغّل حمل على المعالج 15 ثانية ونقيس.",
            "A worn battery's voltage sags quickly under load, which causes sudden shutdowns. We load the processor for 15 seconds and measure."
        )))
        val status = when (rPhase) {
            RPhase.WAIT_UNPLUG -> tr("افصل الشاحن عشان نبدأ…", "Unplug the charger to begin…")
            RPhase.IDLE -> tr("قياس الوضع الهادئ… ", "Measuring at rest… ") + secs(8000)
            RPhase.LOAD -> tr("تحت الحمل… (الجوال بيسخن شوي، طبيعي) ", "Under load… (the phone may warm up, that's normal) ") + secs(15000)
            RPhase.DONE -> irMohm?.let { tr("المقاومة: $it mΩ", "Resistance: $it mΩ") + "  —  " + irLabel(it) } ?: irNote
        }
        c.addView(text(status, 16f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, 0) })
        if (rPhase == RPhase.DONE) {
            c.addView(pill(tr("التالي: قياس السعة", "Next: capacity"), PETROL, Color.WHITE, true) {
                step = Step.CHARGE
                render()
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
        } else {
            c.addView(link(tr("تخطّي هذه الخطوة", "Skip this step")) {
                stopLoad()
                irMohm = null
                irNote = tr("تم التخطي", "Skipped")
                step = Step.CHARGE
                render()
            })
        }
    }

    private fun renderCharge(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("السعة الفعلية", "Actual capacity")))
        c.addView(para(tr(
            "نقيس كم طاقة تدخل البطارية مقابل كل 1% شحن، ومنها نحسب سعتها الحقيقية. القياس أدق لو البطارية أقل من 80% وتشحن بشاحن عادي.",
            "We measure how much charge enters per 1% to calculate the real capacity. Most accurate below 80% with a regular charger."
        )))
        val lv = level()
        when (cPhase) {
            CPhase.WAIT_PLUG -> {
                c.addView(text(tr("وصّل الشاحن الآن…", "Plug in the charger now…"), 16f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, 0) })
                if (lv >= 90) c.addView(para(tr(
                    "تنبيه: الشحن $lv%. فوق 90% الشحن يبطأ والقياس يطلع أقل دقة.",
                    "Note: battery is at $lv%. Above 90% charging slows and the result is less accurate."
                )).apply { setTextColor(0xFFC98A1B.toInt()) })
            }
            CPhase.MEASURE -> {
                val el = (SystemClock.elapsedRealtime() - measureStart) / 1000
                c.addView(stat(tr("المدة", "Elapsed"), String.format(Locale.US, "%d:%02d", el / 60, el % 60)))
                c.addView(stat(tr("النسبة اللي انقاست", "Measured range"), "$levelDelta% / 8%"))
                currentMa()?.let { c.addView(stat(tr("تيار الشحن", "Charge current"), "$it mA")) }
                estimateCapacity()?.let { c.addView(stat(tr("السعة التقديرية الحين", "Estimate so far"), "${it.first} mAh")) }
                if (points.isEmpty()) c.addView(para(tr(
                    "ننتظر أول تغيّر في نسبة الشحن عشان نبدأ العد…",
                    "Waiting for the first change in charge level to start counting…"
                )))
                c.addView(pill(
                    if (levelDelta >= 3) tr("إنهاء القياس الآن", "Finish now") else tr("إنهاء بدون قياس السعة", "Finish without capacity"),
                    PETROL, PETROL, false
                ) { finishCharge() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
            }
            CPhase.DONE -> {}
        }
        if (cPhase == CPhase.WAIT_PLUG) {
            c.addView(link(tr("تخطّي هذه الخطوة", "Skip this step")) { finishCharge() })
            // بطاقة السعة الأصلية ما تظهر أثناء القياس لأن الشاشة تتحدث كل ثانية
            designCard(body)
        }
    }

    private fun renderDone(body: LinearLayout) {
        val r = report ?: return
        val c = card(body)
        c.addView(text(r.verdictText, 24f, Fonts.bold, r.verdictColor))
        c.addView(text(r.confidenceText, 14f, Fonts.medium, SLATE).apply { setPadding(0, dp(2), 0, dp(8)) })
        r.healthPct?.let { c.addView(stat(tr("صحة البطارية", "Battery health"), "$it%")) }
        r.measuredMah?.let { c.addView(stat(tr("السعة الفعلية المقاسة", "Measured capacity"), "$it mAh")) }
        r.designMah?.let { c.addView(stat(tr("السعة الأصلية", "Design capacity"), "$it mAh (${r.sourceText})")) }
        c.addView(stat(tr("طريقة القياس", "Method"), r.methodText))
        r.cycles?.let { c.addView(stat(tr("دورات الشحن", "Charge cycles"), "$it")) }
        c.addView(stat(tr("المقاومة الداخلية", "Internal resistance"), r.irMohm?.let { "$it mΩ — " + irLabel(it) } ?: tr("غير متاحة", "Not available")))
        r.maxTempC?.let { c.addView(stat(tr("أعلى حرارة أثناء الفحص", "Max temperature"), String.format(Locale.US, "%.1f°C", it))) }
        c.addView(stat(tr("انتفاخ", "Swelling"), if (r.swollen) tr("نعم ⚠", "Yes ⚠") else tr("لا", "No")))

        if (r.swollen) c.addView(para(tr(
            "البطارية المنتفخة خطر حريق. لا تشحن الجوال، وغيّر البطارية عند فني موثوق.",
            "A swollen battery is a fire risk. Do not charge the phone; have the battery replaced by a trusted technician."
        )).apply { setTextColor(RED) })
        if (r.confidence == 0 && !r.swollen) c.addView(para(tr(
            "الثقة منخفضة لأن قياس السعة ما اكتمل. للحصول على نتيجة أدق، أعد الفحص والبطارية أقل من 80%، وخلّها تشحن لين ينقاس 8%.",
            "Low confidence because the capacity measurement did not complete. For accuracy, retest below 80% charge and let it charge until 8% is measured."
        )))

        c.addView(pill(tr("حفظ النتيجة", "Save result"), PETROL, Color.WHITE, true) { save() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
        c.addView(pill(tr("إعادة الفحص", "Retest"), PETROL, PETROL, false) { recreate() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        designCard(body)
    }

    /** بطاقة السعة الأصلية مع إمكانية التعديل */
    private fun designCard(body: LinearLayout) {
        val c = card(body)
        val d = DesignCapacity.resolve(this)
        c.addView(title(tr("السعة الأصلية للبطارية", "Original battery capacity")))
        c.addView(para(
            if (d != null) "${d.first} mAh  ·  " + when (d.second) {
                CapSource.TABLE -> tr("من قاعدة بيانات الموديلات", "from the model database")
                CapSource.SYSTEM -> tr("من النظام (ممكن تكون غير دقيقة)", "from the system (may be inaccurate)")
                CapSource.MANUAL -> tr("أدخلتها يدوياً", "entered manually")
            } else tr(
                "ما لقينا السعة الأصلية لهذا الموديل. اكتبها من مواصفات الجوال عشان نحسب نسبة الصحة.",
                "We could not find the original capacity for this model. Enter it from the phone's specs to calculate health."
            )
        ))
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = tr("مثلاً 5000", "e.g. 5000")
            setText(DesignCapacity.manual(this@BatteryTestActivity)?.toString() ?: "")
            typeface = Fonts.regular
            textSize = 15f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), LINE)
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(pill(tr("حفظ", "Save"), PETROL, Color.WHITE, true) {
            val v = input.text.toString().trim().toIntOrNull()
            DesignCapacity.setManual(this, v?.takeIf { it in 1000..12000 })
            if (step == Step.DONE) buildReport()
            render()
        }, LinearLayout.LayoutParams(dp(90), dp(48)).apply { marginStart = dp(10) })
        c.addView(row)
    }

    private fun irLabel(r: Int): String = when {
        r <= 180 -> tr("ممتازة", "excellent")
        r <= 280 -> tr("طبيعية", "normal")
        r <= 400 -> tr("مرتفعة", "high")
        else -> tr("مرتفعة جداً", "very high")
    }

    private fun secs(total: Long): String {
        val left = ((total - (SystemClock.elapsedRealtime() - phaseStart)) / 1000).coerceAtLeast(0)
        return "($left" + tr(" ث)", "s)")
    }

    // ---------- عناصر ----------
    private fun card(body: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
        }
        body.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return c
    }

    private fun title(s: String) = text(s, 18f, Fonts.bold, TEXT)

    private fun para(s: String) = text(s, 14f, Fonts.regular, SLATE).apply {
        setLineSpacing(0f, 1.3f)
        setPadding(0, dp(6), 0, 0)
    }

    private fun stat(label: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, dp(7))
        }
        row.addView(text(label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 14f, Fonts.bold, TEXT).apply { gravity = Gravity.END })
        return row
    }

    private fun row2(a: View, b: View): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(16), 0, 0)
        }
        row.addView(a, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(6) })
        row.addView(b, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(6) })
        return row
    }

    private fun link(s: String, onClick: () -> Unit) = text(s, 14f, Fonts.bold, SLATE).apply {
        setPadding(0, dp(16), 0, dp(4))
        setOnClickListener { onClick() }
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun pill(label: String, bg: Int, fg: Int, filled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            textSize = 15f
            typeface = Fonts.bold
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                if (filled) setColor(bg) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), bg)
                }
            }
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
