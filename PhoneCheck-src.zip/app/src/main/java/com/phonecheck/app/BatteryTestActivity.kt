package com.phonecheck.app

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * فحص البطارية العميق. نجمع أكبر عدد من المصادر المستقلة، وكل ما اتفقت زادت الثقة:
 * 0) فحص قدرات الجوال (قراءة المصنع، ملفات النظام، التيار، عدّاد الشحن، الجهد)
 * 1) الانتفاخ  2) المقاومة الداخلية  3) السعة أثناء الشحن  4) تأكيد السعة بالتفريغ (اختياري)  5) النتيجة
 *
 * قاعدة عدم الظلم: أي قياس ما ينجح يُستبعد وما ينقص من التقييم، ولما تكون الدقة أقل نعطي البطارية الأفضلية.
 */
class BatteryTestActivity : AppCompatActivity() {

    private enum class Step { PROBE, SWELL, RESIST, CHARGE, TOGGLE, DISCHARGE, DONE }
    private enum class RPhase { WAIT_UNPLUG, IDLE, LOAD, DONE }
    private enum class CPhase { WAIT_PLUG, MEASURE, DONE }
    private enum class TPhase { WAIT_PLUG, WAIT_UNPLUG, UNPLUGGED, READING, DONE }
    private enum class DPhase { OFFER, WAIT_UNPLUG, MEASURE, DONE }

    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bm: BatteryManager

    private var step = Step.PROBE
    private var swollen = false
    private var caps: BatteryCaps? = null

    // ---------- الفحص المبدئي ----------
    private var probeStart = 0L
    private val probeCurrent = mutableListOf<Int?>()
    private val probeCc = mutableListOf<Long?>()
    private val probeVolts = mutableSetOf<Int>()

    // ---------- المقاومة (حمل) ----------
    private var rPhase = RPhase.WAIT_UNPLUG
    private var phaseStart = 0L
    private val idleV = mutableListOf<Int>()
    private val loadV = mutableListOf<Int>()
    private val idleI = mutableListOf<Int>()
    private val loadI = mutableListOf<Int>()
    private val loadRunning = AtomicBoolean(false)

    // ---------- المقاومة (فصل/توصيل) ----------
    private var tPhase = TPhase.WAIT_PLUG
    private var tPhaseStart = 0L
    private var prevPlugged: Boolean? = null
    private var vUnplug: Int? = null
    private var vPlug: Int? = null
    private var iDischarge: Int? = null
    private var toggleRounds = 0
    private val toggleR = mutableListOf<Int>()
    private val toggleLog = StringBuilder()

    private var irMohm: Int? = null
    private var irReliable = false
    private var irNote = ""

    // ---------- السعة أثناء الشحن ----------
    private var cPhase = CPhase.WAIT_PLUG
    private var measureStart = 0L
    private var lastTick = 0L
    private var lastLevel = -1
    private var integMah = 0.0
    private var ccOk = true
    private class Point(val level: Int, val ccUah: Long?, val integ: Double)
    private val points = mutableListOf<Point>()
    private var measuredMah: Int? = null
    private var segmentsAgree: Boolean? = null
    private var method = -1
    private var levelDelta = 0
    private var maxChargeMa = 0
    private val chargeCurrents = mutableListOf<Int>()
    private var chargeInvalid = ""      // سبب رفض قياس الشحن
    private var interrupted = false     // انقطع القياس لأن المستخدم طلع من التطبيق
    private var hotAbort = false        // انلغى القياس لأن البطارية سخنت فوق 42°
    private var stallStart = 0L         // متى وقف الشحن وهو موصول (ميزة حماية البطارية)
    private var stalled = false

    // ---------- تأكيد بالتفريغ ----------
    private var dPhase = DPhase.OFFER
    private var dStart = 0L
    private var dLastTick = 0L
    private var dLastLevel = -1
    private var dInteg = 0.0
    private val dPoints = mutableListOf<Point>()
    private var dischargeMah: Int? = null

    private var maxTemp = 0f
    private var report: BatteryReport? = null

    private var last: Intent? = null
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            last = i
            val v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            val p = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val now = SystemClock.elapsedRealtime()
            if (step == Step.PROBE && v in 2500..5000) probeVolts += v
            // في طريقة الفصل/التوصيل نأخذ آخر قراءة جهد خلال 3 ثواني بعد الحدث
            if (step == Step.TOGGLE && v in 2500..5000) {
                if (tPhase == TPhase.UNPLUGGED && now - tPhaseStart < 3000) vUnplug = v
                if (tPhase == TPhase.READING) vPlug = v
            }
            val before = prevPlugged
            prevPlugged = p
            if (before != null && before != p) onPlugEvent(p, v)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Fonts.init(this)
        bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setEdgeContent(ScrollView(this).apply {
            layoutDirection = Lang.dir
            setBackgroundColor(BG)
            addView(root)
        })
        last = registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        probeStart = SystemClock.elapsedRealtime()
        render()
        handler.postDelayed(tick, 1000)
    }

    /** لو طلعت من التطبيق أثناء القياس، يُلغى ويبدأ من جديد (الاستخدام يغيّر التيار ويخرب الدقة) */
    override fun onPause() {
        super.onPause()
        if (step == Step.CHARGE && cPhase == CPhase.MEASURE) {
            cPhase = CPhase.WAIT_PLUG
            points.clear()
            chargeCurrents.clear()
            interrupted = true
        }
        if (step == Step.DISCHARGE && dPhase == DPhase.MEASURE) {
            stopLoad()
            dPhase = DPhase.WAIT_UNPLUG
            dPoints.clear()
            interrupted = true
        }
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    /** شروط بدء قياس السعة */
    private fun chargeConditions(): List<Pair<String, Boolean>> {
        val lv = level()
        val t = tempC()
        val d = DesignCapacity.resolve(this)?.second
        return listOf(
            tr("نسبة البطارية 80% أو أقل (الآن $lv%)", "Battery at 80% or less (now $lv%)") to (lv in 1..80),
            tr("حرارة البطارية بين 15 و40 درجة (الآن ${t.roundToInt()}°)", "Battery between 15 and 40°C (now ${t.roundToInt()}°)") to (t in 15f..40f),
            tr("السعة الأصلية معروفة (من الجدول أو مكتوبة)", "Design capacity known (database or entered)") to (d == CapSource.TABLE || d == CapSource.MANUAL),
            tr("الشاحن موصول", "Charger connected") to plugged(),
        )
    }

    private fun canStartCharge(): Boolean = chargeConditions().take(2).all { it.second } && plugged()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopLoad()
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
            // تجاهل
        }
        super.onDestroy()
    }

    // ---------- قراءات ----------
    private fun plugged(): Boolean = (last?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

    private fun level(): Int {
        val l = last?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = last?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l >= 0 && s > 0) l * 100 / s else -1
    }

    private fun tempC(): Float = (last?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

    private fun currentMa(): Int? =
        BatteryProbe.currentMa(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            ?: BatteryProbe.currentMa(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE))

    private fun chargeCounter(): Long? =
        BatteryProbe.chargeCounterUah(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER))

    // ---------- التشغيل الدوري ----------
    private fun onTick() {
        when (step) {
            Step.PROBE -> tickProbe()
            Step.RESIST -> tickResist()
            Step.CHARGE -> tickCharge()
            Step.TOGGLE -> if (tPhase == TPhase.WAIT_UNPLUG || tPhase == TPhase.UNPLUGGED) render()
            Step.DISCHARGE -> tickDischarge()
            else -> {}
        }
    }

    private fun tickProbe() {
        if (caps != null) return
        probeCurrent += currentMa()
        probeCc += chargeCounter()
        if (SystemClock.elapsedRealtime() - probeStart >= 8000) {
            caps = BatteryProbe.probe(this, probeCurrent, probeCc, probeVolts)
            ccOk = caps?.chargeCounterOk == true
        }
        render()
    }

    private fun afterSwell() {
        val c = caps
        step = if (c != null && c.sysVoltage && c.currentOk) Step.RESIST else Step.CHARGE
        render()
    }

    private fun afterCharge() {
        val c = caps
        if (c != null && !c.sysVoltage && c.currentOk) {
            step = Step.TOGGLE
            tPhase = if (plugged()) TPhase.WAIT_UNPLUG else TPhase.WAIT_PLUG
            tPhaseStart = SystemClock.elapsedRealtime()
        } else {
            if (c != null && !c.currentOk && irNote.isEmpty()) {
                irNote = tr(
                    "هذا الجوال ما يعطي التطبيقات قراءة التيار، فقياس المقاومة غير ممكن عليه. هذا ما يأثر على تقييم البطارية.",
                    "This phone does not expose current readings to apps, so resistance cannot be measured. This does not affect the battery verdict."
                )
            }
            toDischargeOrDone()
        }
        render()
    }

    private fun toDischargeOrDone() {
        val c = caps
        if (c != null && (c.chargeCounterOk || c.currentOk)) {
            step = Step.DISCHARGE
            dPhase = DPhase.OFFER
        } else {
            step = Step.DONE
            buildReport()
        }
    }

    // ---------- المقاومة: اختبار الحمل (لما الجهد اللحظي متاح) ----------
    private fun tickResist() {
        val now = SystemClock.elapsedRealtime()
        when (rPhase) {
            RPhase.WAIT_UNPLUG -> if (!plugged()) {
                rPhase = RPhase.IDLE
                phaseStart = now
                render()
            }
            RPhase.IDLE -> {
                if (plugged()) return restartResist()
                sample(idleV, idleI)
                if (now - phaseStart > 8000) {
                    rPhase = RPhase.LOAD
                    phaseStart = now
                    startLoad()
                }
                render()
            }
            RPhase.LOAD -> {
                if (plugged()) return restartResist()
                if (now - phaseStart > 3000) sample(loadV, loadI)
                if (now - phaseStart > 15000) {
                    stopLoad()
                    computeResistance()
                    rPhase = RPhase.DONE
                }
                render()
            }
            RPhase.DONE -> {}
        }
    }

    private fun sample(vList: MutableList<Int>, iList: MutableList<Int>) {
        BatteryProbe.sysVoltageMv()?.let { vList += it }
        currentMa()?.let { iList += it }
    }

    private fun restartResist() {
        stopLoad()
        idleV.clear(); loadV.clear(); idleI.clear(); loadI.clear()
        rPhase = RPhase.WAIT_UNPLUG
        render()
    }

    private fun computeResistance() {
        if (idleV.isEmpty() || loadV.isEmpty() || idleI.isEmpty() || loadI.isEmpty()) {
            irNote = tr("ما وصلت قراءات كافية أثناء القياس.", "Not enough readings during the test.")
            return
        }
        val dI = loadI.average() - idleI.average()
        val dV = idleV.average() - loadV.average()
        if (dI < 150 || dV <= 0) {
            irNote = tr("فرق الحمل كان صغير جداً، فالقياس غير موثوق.", "The load difference was too small for a reliable reading.")
            return
        }
        val r = (dV / dI * 1000).roundToInt()
        if (r in 20..2000) {
            irMohm = r
            irReliable = true
        } else {
            irNote = tr("القراءة خارج المعقول، فتم تجاهلها.", "Reading out of range, ignored.")
        }
    }

    private fun startLoad() {
        loadRunning.set(true)
        window.attributes = window.attributes.also { it.screenBrightness = 1f }
        repeat(Runtime.getRuntime().availableProcessors()) {
            Thread {
                var x = 0.0
                while (loadRunning.get()) {
                    for (k in 1..20000) x += Math.sqrt(k.toDouble() + x % 7)
                }
            }.apply { priority = Thread.MAX_PRIORITY }.start()
        }
    }

    private fun stopLoad() {
        if (!loadRunning.getAndSet(false)) return
        window.attributes = window.attributes.also {
            it.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
    }

    // ---------- السعة أثناء الشحن ----------
    private fun tickCharge() {
        val now = SystemClock.elapsedRealtime()
        when (cPhase) {
            CPhase.WAIT_PLUG -> if (canStartCharge()) {
                cPhase = CPhase.MEASURE
                chargeCurrents.clear()
                measureStart = now
                lastTick = now
                lastLevel = level()
                integMah = 0.0
                points.clear()
                stallStart = 0L
                render()
            } else {
                render()
            }
            CPhase.MEASURE -> {
                if (!plugged()) {
                    cPhase = CPhase.WAIT_PLUG
                    render()
                    return
                }
                val t = tempC()
                if (t > maxTemp) maxTemp = t
                // حرارة عالية أثناء الشحن تخرب القياس (الشحن يتباطأ والبطارية تتصرف غير طبيعي)
                // فنلغي ونرجع ننتظر لين تبرد تحت 40، والقياس يبدأ من جديد لحاله
                if (t > 42f) {
                    hotAbort = true
                    cPhase = CPhase.WAIT_PLUG
                    points.clear()
                    chargeCurrents.clear()
                    render()
                    return
                }
                // لو الشحن وقف وهو موصول والبطارية مو مليانة: غالباً ميزة "حماية البطارية" أو "الشحن الذكي"
                val st = last?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                if (st != BatteryManager.BATTERY_STATUS_CHARGING && level() < 100) {
                    if (stallStart == 0L) stallStart = now
                    if (now - stallStart > 3 * 60_000) {
                        stalled = true
                        finishCharge()
                        return
                    }
                } else {
                    stallStart = 0L
                }
                val dtH = (now - lastTick) / 3_600_000.0
                lastTick = now
                currentMa()?.let {
                    integMah += it * dtH
                    chargeCurrents += it
                    if (it > maxChargeMa) maxChargeMa = it
                }
                val lv = level()
                if (lv > lastLevel && lastLevel >= 0) {
                    val cc = chargeCounter()
                    if (cc == null) ccOk = false
                    points += Point(lv, cc, integMah)
                }
                lastLevel = lv
                levelDelta = if (points.size >= 2) points.last().level - points.first().level else 0
                if (levelDelta >= 10 || now - measureStart > 25 * 60_000) {
                    finishCharge()
                    return
                }
                render()
            }
            CPhase.DONE -> {}
        }
    }

    /** السعة = الطاقة اللي دخلت أو طلعت ÷ النسبة اللي تغيّرت × 100 */
    private fun capacityBetween(a: Point, b: Point, useCc: Boolean): Int? {
        val d = abs(b.level - a.level)
        if (d < 2) return null
        if (useCc && a.ccUah != null && b.ccUah != null) {
            val dc = abs(b.ccUah - a.ccUah)
            if (dc > 0) return (dc / 1000.0 / d * 100).roundToInt()
        }
        val dm = abs(b.integ - a.integ)
        return if (dm > 0) (dm / d * 100).roundToInt() else null
    }

    private fun estimateCapacity(): Pair<Int, Int>? {
        if (points.size < 2) return null
        val useCc = ccOk && points.all { it.ccUah != null }
        val c = capacityBetween(points.first(), points.last(), useCc) ?: return null
        return c to (if (useCc) 0 else 1)
    }

    private fun sane(c: Int): Boolean {
        val design = DesignCapacity.resolve(this)?.first
        return if (design != null) c in (design * 0.3).toInt()..(design * 1.5).toInt() else c in 1000..12000
    }

    private fun finishCharge() {
        cPhase = CPhase.DONE
        val est = estimateCapacity()
        // جودة الشاحن: تيار ضعيف أو متذبذب يخرب القياس، فنرفضه
        val med = chargeCurrents.sorted().let { if (it.isEmpty()) null else it[it.size / 2] }
        val weak = med != null && med < 300
        val unstable = med != null && chargeCurrents.count { it < med * 0.3 } > chargeCurrents.size * 0.2
        chargeInvalid = when {
            stalled && levelDelta < 10 -> tr(
                "الشحن وقف لحاله قبل ما يكتمل القياس. غالباً ميزة \"حماية البطارية\" أو \"الشحن الذكي\" شغّالة: قفّلها من إعدادات البطارية وأعد الفحص.",
                "Charging stopped by itself before the measurement finished. A \"battery protection\" or \"adaptive charging\" feature is probably on: turn it off in battery settings and retest."
            )
            points.size < 2 -> tr("ما بدأ قياس السعة (الشروط ما تحققت أو تم التخطي).", "Capacity measurement did not start (conditions not met or skipped).")
            weak -> tr("الشاحن ضعيف (أقل من 300 mA). استخدم شاحن أقوى وأعد الفحص.", "Charger too weak (under 300 mA). Use a stronger charger and retest.")
            unstable -> tr("تيار الشحن كان متذبذب (ممكن استخدام أثناء القياس أو كيبل سيء).", "Charging current was unstable (phone used during the test, or a bad cable).")
            levelDelta < 4 -> tr("القياس كان قصير جداً (${levelDelta}%).", "Measurement too short (${levelDelta}%).")
            est == null || !sane(est.first) -> tr("القراءات طلعت غير منطقية، فتم رفضها.", "Readings were implausible and were rejected.")
            else -> ""
        }
        if (est != null && sane(est.first) && levelDelta >= 4 && !weak && !unstable) {
            measuredMah = est.first
            method = est.second
            // نقسم القياس نصين ونشوف هل متفقين
            if (points.size >= 7) {
                val useCc = method == 0
                val mid = points.size / 2
                val c1 = capacityBetween(points.first(), points[mid], useCc)
                val c2 = capacityBetween(points[mid], points.last(), useCc)
                if (c1 != null && c2 != null) segmentsAgree = abs(c1 - c2) <= (c1 + c2) / 2 * 0.10
            }
        }
        afterCharge()
    }

    // ---------- المقاومة: فصل وتوصيل الشاحن ----------
    private fun onPlugEvent(nowPlugged: Boolean, v: Int) {
        if (step != Step.TOGGLE) return
        val now = SystemClock.elapsedRealtime()
        when {
            tPhase == TPhase.WAIT_PLUG && nowPlugged -> {
                tPhase = TPhase.WAIT_UNPLUG
                tPhaseStart = now
            }
            tPhase == TPhase.WAIT_UNPLUG && !nowPlugged -> {
                vUnplug = v.takeIf { it in 2500..5000 }
                iDischarge = null
                tPhase = TPhase.UNPLUGGED
                tPhaseStart = now
                handler.postDelayed({ iDischarge = currentMa() }, 1500)
            }
            tPhase == TPhase.UNPLUGGED && nowPlugged -> {
                if (now - tPhaseStart < 5000) {
                    tPhase = TPhase.WAIT_UNPLUG
                    tPhaseStart = now
                } else {
                    vPlug = v.takeIf { it in 2500..5000 }
                    tPhase = TPhase.READING
                    val vu = vUnplug
                    val id = iDischarge
                    var ic1: Int? = null
                    handler.postDelayed({ ic1 = currentMa() }, 1500)
                    handler.postDelayed({
                        val ic2 = currentMa()
                        val ic = listOfNotNull(ic1, ic2).takeIf { it.isNotEmpty() }?.average()?.roundToInt()
                        val vp = vPlug
                        toggleLog.appendLine("round ${toggleRounds + 1}: vU=$vu iD=$id vP=$vp iC=$ic1/$ic2")
                        if (vu != null && vp != null && id != null && ic != null) {
                            val dI = ic + id
                            val dV = vp - vu
                            if (dI >= 300 && dV > 3) {
                                val r = dV * 1000 / dI
                                if (r in 20..2000) toggleR += r
                            }
                        }
                        toggleRounds++
                        if (toggleRounds >= 3 || (toggleRounds >= 2 && toggleR.size >= 2)) {
                            finishToggle()
                        } else {
                            tPhase = TPhase.WAIT_UNPLUG
                            tPhaseStart = SystemClock.elapsedRealtime()
                        }
                        render()
                    }, 3000)
                }
            }
            else -> return
        }
        render()
    }

    private fun finishToggle(skipped: Boolean = false) {
        if (toggleR.isNotEmpty()) {
            irMohm = toggleR.sorted()[toggleR.size / 2]
            // نعتبرها موثوقة لو فيه قراءتين متقاربتين على الأقل
            irReliable = toggleR.size >= 2 && (toggleR.max() - toggleR.min()) <= toggleR.average() * 0.3
            irNote = if (irReliable) "" else tr(
                "قراءة واحدة أو متفاوتة، للعلم فقط ولا تأثر على الحكم.",
                "Single or inconsistent reading; for information only, does not affect the verdict."
            )
        } else {
            irMohm = null
            irNote = if (skipped) tr("تم التخطي", "Skipped") else tr(
                "هذا الجوال ما يحدّث قراءة الجهد لحظة فصل وتوصيل الشاحن، فقياس المقاومة غير ممكن عليه. هذا ما يأثر على تقييم البطارية.",
                "This phone does not refresh its voltage reading when the charger is plugged or unplugged, so resistance cannot be measured. This does not affect the battery verdict."
            )
        }
        tPhase = TPhase.DONE
        toDischargeOrDone()
    }

    // ---------- تأكيد السعة بالتفريغ ----------
    private fun tickDischarge() {
        val now = SystemClock.elapsedRealtime()
        when (dPhase) {
            DPhase.WAIT_UNPLUG -> if (!plugged()) {
                dPhase = DPhase.MEASURE
                dStart = now
                dLastTick = now
                dLastLevel = level()
                dInteg = 0.0
                dPoints.clear()
                startLoad()
                render()
            }
            DPhase.MEASURE -> {
                if (plugged()) {
                    stopLoad()
                    dPhase = DPhase.WAIT_UNPLUG
                    render()
                    return
                }
                val dtH = (now - dLastTick) / 3_600_000.0
                dLastTick = now
                currentMa()?.let { dInteg += it * dtH }
                val lv = level()
                if (lv < dLastLevel && dLastLevel >= 0) dPoints += Point(lv, chargeCounter(), dInteg)
                dLastLevel = lv
                val drop = if (dPoints.size >= 2) dPoints.first().level - dPoints.last().level else 0
                if (drop >= 4 || now - dStart > 15 * 60_000) {
                    finishDischarge()
                    return
                }
                render()
            }
            else -> {}
        }
    }

    private fun finishDischarge() {
        stopLoad()
        dPhase = DPhase.DONE
        if (dPoints.size >= 2) {
            val useCc = dPoints.all { it.ccUah != null } && ccOk
            capacityBetween(dPoints.first(), dPoints.last(), useCc)?.takeIf { sane(it) }?.let { dischargeMah = it }
        }
        step = Step.DONE
        buildReport()
        render()
    }

    // ---------- الحكم ----------
    private fun buildReport() {
        val c = caps
        val design = DesignCapacity.resolve(this)
        val cyc = c?.cycles

        // السعة المقاسة: لو قياس التفريغ متفق مع الشحن نأخذ المتوسط
        val chg = measuredMah
        val dis = dischargeMah
        val dischargeAgrees = chg != null && dis != null && abs(chg - dis) <= (chg + dis) / 2 * 0.10
        val measured = when {
            chg != null && dis != null && dischargeAgrees -> (chg + dis) / 2
            chg != null -> chg
            else -> dis
        }
        val measuredHealth = if (measured != null && design != null) (measured * 100.0 / design.first).roundToInt().coerceIn(1, 100) else null
        val cycleHealth = cyc?.let { (100 - it * 0.025).roundToInt().coerceIn(50, 100) }
        val oem = c?.oemHealth
        val direct = c?.directHealth

        var health: Int? = null
        var source: HealthSource? = null
        var margin: Int? = null
        var confidence = 0
        val missing = mutableListOf<String>()
        val designKnown = design?.second == CapSource.TABLE || design?.second == CapSource.MANUAL

        // شروط صارمة: نسبة الصحة من القياس تطلع فقط لو:
        // قياس 10% كامل + نصين متفقين + سعة أصلية من الجدول أو مكتوبة
        val strictMeasured = measuredHealth != null && levelDelta >= 10 && segmentsAgree == true && designKnown

        when {
            oem != null -> {
                health = oem
                source = HealthSource.MANUFACTURER
                confidence = 3
            }
            direct != null -> {
                health = direct
                source = HealthSource.SYSTEM_FILES
                margin = 3
                confidence = if (measuredHealth != null && abs(measuredHealth - direct) <= 8) 2 else 1
            }
            strictMeasured -> {
                health = measuredHealth
                source = HealthSource.MEASURED
                var m = ceil(100.0 / (2 * levelDelta)).toInt().coerceIn(2, 10)
                if (dischargeAgrees) m = (m * 0.7).roundToInt().coerceAtLeast(2)
                margin = m
                // الثقة العالية تحتاج مصدر ثالث مستقل متفق
                val third = dischargeAgrees || (cycleHealth != null && abs(cycleHealth - measuredHealth!!) <= 10)
                confidence = if (third) 2 else 1
            }
            else -> {
                if (chargeInvalid.isNotBlank()) missing += chargeInvalid
                if (measuredMah != null && levelDelta < 10) missing += tr("لازم يكتمل قياس 10% (انقاس ${levelDelta}%).", "A full 10% must be measured (got ${levelDelta}%).")
                if (measuredMah != null && segmentsAgree != true) missing += tr("نصفين القياس ما اتفقوا، فالقراءة غير ثابتة.", "The two halves of the measurement disagreed, so the reading is not stable.")
                if (!designKnown) missing += tr("السعة الأصلية غير مؤكدة. اكتبها من مواصفات الجوال.", "Design capacity not confirmed. Enter it from the phone's specs.")
                if (interrupted) missing += tr("انقطع القياس مرة لأنك طلعت من التطبيق.", "The measurement was interrupted because you left the app.")
                if (missing.isEmpty()) missing += tr("ما توفرت بيانات كافية.", "Not enough data.")
            }
        }

        // عدم الظلم: لما الثقة متوسطة، نحكم على الحد الأعلى من الهامش
        val mg = margin
        val hl = health
        val judged = if (hl == null) null else if (confidence <= 1 && mg != null) hl + mg / 2 else hl
        var verdict = when {
            judged == null -> -1
            judged >= 85 -> 0
            judged >= 80 -> 1
            judged >= 70 -> 2
            else -> 3
        }
        if (verdict >= 0) {
            // المقاومة تأثر فقط لو القياس موثوق
            val ir = irMohm
            if (ir != null && irReliable) {
                if (ir > 450) verdict = maxOf(verdict, 3) else if (ir > 300) verdict = maxOf(verdict, 2)
            }
            // الحرارة أثناء الشحن العادي فقط (مو أثناء الحمل)
            if (maxTemp > 55f) verdict = maxOf(verdict, 3) else if (maxTemp > 48f) verdict = maxOf(verdict, 2)
        }
        if (swollen) verdict = 4

        val capsList = c?.let {
            listOf(
                tr("قراءة الشركة المصنعة", "Manufacturer reading") to (it.oemHealth != null),
                tr("ملفات نظام البطارية", "Battery system files") to (it.directHealth != null && it.oemHealth == null),
                tr("عدّاد الشحن", "Charge counter") to it.chargeCounterOk,
                tr("قراءة التيار", "Current reading") to it.currentOk,
                tr("الجهد اللحظي", "Live voltage") to (it.sysVoltage || it.voltUpdates >= 2),
                tr("عدد الدورات", "Cycle count") to (it.cycles != null),
            )
        } ?: emptyList()

        report = BatteryReport(
            healthPct = health,
            healthMargin = margin,
            healthSource = source,
            confidence = if (health == null) 0 else confidence,
            provisional = health != null && confidence <= 1,
            measuredMah = chg,
            dischargeMah = dis,
            segmentsAgree = segmentsAgree,
            designMah = design?.first,
            designSource = design?.second,
            method = method,
            levelDelta = levelDelta,
            cycles = cyc,
            irMohm = irMohm,
            irNote = irNote,
            maxTempC = maxTemp.takeIf { it > 0f },
            maxChargeMa = maxChargeMa.takeIf { it > 0 },
            swollen = swollen,
            verdict = verdict,
            mfgDate = c?.mfgDate,
            firstUse = c?.firstUse,
            capsSummary = capsList,
            missing = if (verdict == -1) missing else emptyList(),
        )
    }

    private fun save() {
        val r = report ?: return
        Results.battery = r
        Results.details[Test.BATTERY] = r.summary
        setResult(
            when {
                !r.determined -> RESULT_UNDETERMINED
                r.passed -> RESULT_OK
                else -> RESULT_FIRST_USER
            }
        )
        finish()
    }

    private fun diagnostics(): String = buildString {
        appendLine("PhoneCheck battery diagnostics")
        append(caps?.raw ?: "")
        appendLine("charge: delta=$levelDelta method=$method measured=$measuredMah segments=$segmentsAgree maxI=$maxChargeMa")
        appendLine("charge points=" + points.joinToString { "${it.level}:${it.ccUah}:${it.integ.roundToInt()}" })
        appendLine("discharge points=" + dPoints.joinToString { "${it.level}:${it.ccUah}:${it.integ.roundToInt()}" } + " result=$dischargeMah")
        appendLine("ir=$irMohm reliable=$irReliable toggleR=$toggleR")
        append(toggleLog)
        appendLine("load idleV=${idleV.size} loadV=${loadV.size} idleI=${idleI.size} loadI=${loadI.size}")
    }

    private fun copyDiagnostics() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("diagnostics", diagnostics()))
        Toast.makeText(this, tr("تم نسخ بيانات التشخيص", "Diagnostics copied"), Toast.LENGTH_SHORT).show()
    }

    // ---------- الواجهة ----------
    private fun render() {
        root.removeAllViews()
        root.addView(header())
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(36))
        }
        root.addView(body)
        if (step != Step.PROBE) body.addView(stepsBar(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        when (step) {
            Step.PROBE -> renderProbe(body)
            Step.SWELL -> renderSwell(body)
            Step.RESIST -> renderResist(body)
            Step.CHARGE -> renderCharge(body)
            Step.TOGGLE -> renderToggle(body)
            Step.DISCHARGE -> renderDischarge(body)
            Step.DONE -> renderDone(body)
        }
    }

    private fun header(): View {
        val r = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(22))
            background = GradientDrawable().apply {
                setColor(PETROL)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text(tr("فاحص الجوال", "Phone Check"), 14f, Fonts.medium, LIGHT), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text("✕  " + tr("إيقاف", "Stop"), 14f, Fonts.bold, Color.WHITE).apply {
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), LIGHT)
            }
            setOnClickListener { finish() }
        })
        box.addView(top)
        box.addView(text(tr("فحص البطارية العميق", "Deep battery test"), 22f, Fonts.bold, Color.WHITE).apply { setPadding(0, dp(2), 0, 0) })
        val lv = level()
        val live = tr("الشحن الآن", "Now") + ": " + (if (lv >= 0) "$lv%" else "-") +
            "   ·   " + String.format(Locale.US, "%.1f°C", tempC()) +
            "   ·   " + (if (plugged()) tr("على الشاحن", "Charging") else tr("بدون شاحن", "On battery"))
        box.addView(text(live, 13f, Fonts.regular, LIGHT).apply { setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun stepsBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val c = caps
        val order = mutableListOf(Step.SWELL)
        if (c != null && c.sysVoltage && c.currentOk) order += Step.RESIST
        order += Step.CHARGE
        if (c != null && !c.sysVoltage && c.currentOk) order += Step.TOGGLE
        if (c != null && (c.chargeCounterOk || c.currentOk)) order += Step.DISCHARGE
        order += Step.DONE
        val cur = order.indexOf(step)
        order.forEachIndexed { i, st ->
            val n = when (st) {
                Step.SWELL -> tr("الشكل", "Shape")
                Step.RESIST, Step.TOGGLE -> tr("المقاومة", "Resistance")
                Step.CHARGE -> tr("السعة", "Capacity")
                Step.DISCHARGE -> tr("التأكيد", "Confirm")
                Step.DONE -> tr("النتيجة", "Result")
                Step.PROBE -> ""
            }
            val state = when {
                i < cur -> 2
                i == cur -> 1
                else -> 0
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            col.addView(View(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(3).toFloat()
                    setColor(if (state > 0) PETROL else LINE)
                }
            }, LinearLayout.LayoutParams(-1, dp(5)))
            col.addView(text(n, 11f, if (state == 1) Fonts.bold else Fonts.regular, if (state > 0) TEXT else GRAY).apply {
                setPadding(0, dp(6), 0, 0)
                gravity = Gravity.CENTER
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (i > 0) marginStart = dp(5)
            })
        }
        return row
    }

    private fun renderProbe(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("فحص قدرات الجوال", "Checking what this phone supports")))
        val cp = caps
        if (cp == null) {
            val left = ((8000 - (SystemClock.elapsedRealtime() - probeStart)) / 1000).coerceAtLeast(0)
            c.addView(para(tr(
                "كل جوال يعطي التطبيقات قراءات مختلفة عن البطارية. نشوف أول وش متاح عشان نختار أدق طريقة… ($left ث)",
                "Every phone exposes different battery readings to apps. We first check what's available to pick the most accurate method… (${left}s)"
            )))
            return
        }
        c.addView(para(tr("هذا اللي يسمح فيه جوالك، وكيف بنستخدمه:", "Here is what your phone allows, and how we use it:")))
        fun cap(ok: Boolean, name: String, use: String) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(9), 0, dp(9))
            }
            row.addView(text(if (ok) "✓" else "✕", 16f, Fonts.bold, if (ok) GREEN else GRAY), LinearLayout.LayoutParams(dp(28), -2))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(text(name, 14f, Fonts.bold, if (ok) TEXT else SLATE))
            col.addView(text(use, 12.5f, Fonts.regular, SLATE))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(row)
        }
        val direct = cp.directHealth
        val fromFiles = direct != null && cp.oemHealth == null
        cap(cp.oemHealth != null, tr("قراءة الشركة المصنعة", "Manufacturer health reading"),
            cp.oemHealth?.let { tr("صحة البطارية حسب المصنع: $it%. أدق مصدر ممكن.", "Manufacturer-reported health: $it%. The most accurate source.") }
                ?: tr("غير متاحة للتطبيقات في هذا الجوال.", "Not available to apps on this phone."))
        cap(fromFiles, tr("ملفات نظام البطارية", "Battery system files"),
            if (fromFiles) tr("تعطي صحة مباشرة: $direct%.", "Gives direct health: $direct%.")
            else tr("محجوبة في هذا الجوال.", "Blocked on this phone."))
        cap(cp.chargeCounterOk, tr("عدّاد الشحن", "Charge counter"),
            if (cp.chargeCounterOk) tr("نقيس السعة الحقيقية بدقة عالية.", "We measure the real capacity accurately.")
            else tr("بنقيس السعة من التيار بدلاً منه (دقة أقل).", "We'll measure capacity from current instead (less accurate)."))
        cap(cp.currentOk, tr("قراءة التيار", "Current reading"),
            if (cp.currentOk) tr("نستخدمها في السعة والمقاومة.", "Used for capacity and resistance.")
            else tr("غير متاحة، فالمقاومة ما يمكن قياسها.", "Not available, so resistance can't be measured."))
        cap(cp.sysVoltage || cp.voltUpdates >= 2, tr("الجهد اللحظي", "Live voltage"),
            if (cp.sysVoltage) tr("متاح، نقيس المقاومة باختبار الحمل.", "Available; resistance via load test.")
            else tr("محدود، بنجرّب طريقة فصل وتوصيل الشاحن.", "Limited; we'll try the plug/unplug method."))
        cap(cp.cycles != null, tr("عدد الدورات", "Cycle count"),
            cp.cycles?.let { tr("$it دورة شحن.", "$it charge cycles.") } ?: tr("غير متاح في هذا الجوال.", "Not available on this phone."))
        cp.mfgDate?.let { c.addView(para(tr("تاريخ تصنيع البطارية: ", "Battery manufacture date: ") + fmtDate(it))) }
        cp.firstUse?.let { c.addView(para(tr("أول استخدام: ", "First used: ") + fmtDate(it))) }

        c.addView(pill(tr("متابعة", "Continue"), PETROL, Color.WHITE, true) {
            step = Step.SWELL
            render()
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
        c.addView(link(tr("نسخ بيانات التشخيص", "Copy diagnostics")) { copyDiagnostics() })
    }

    private fun renderSwell(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("هل البطارية منتفخة؟", "Is the battery swollen?")))
        c.addView(para(tr(
            "شيّك بعينك: هل الشاشة مرفوعة من الطرف، أو الغطاء الخلفي منفوخ أو فيه فراغ، أو الجوال ما يستقر على الطاولة ويهتز لما تضغط على وسطه؟",
            "Check by eye: is the screen lifting at an edge, the back cover bulging or gapped, or does the phone rock when pressed in the middle on a table?"
        )))
        c.addView(row2(
            pill(tr("لا، سليمة", "No, looks normal"), PETROL, Color.WHITE, true) {
                swollen = false
                afterSwell()
            },
            pill(tr("نعم، منتفخة", "Yes, swollen"), RED, RED, false) {
                swollen = true
                step = Step.DONE
                buildReport()
                render()
            }
        ))
    }

    private fun renderResist(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("المقاومة الداخلية", "Internal resistance")))
        c.addView(para(tr(
            "البطارية المتعبة يهبط جهدها بسرعة تحت الحمل، وهذا سبب الطفي المفاجئ. بنشغّل حمل على المعالج 15 ثانية ونقيس.",
            "A worn battery's voltage sags quickly under load, which causes sudden shutdowns. We load the processor for 15 seconds and measure."
        )))
        val status = when (rPhase) {
            RPhase.WAIT_UNPLUG -> tr("افصل الشاحن عشان نبدأ…", "Unplug the charger to begin…")
            RPhase.IDLE -> tr("قياس الوضع الهادئ… ", "Measuring at rest… ") + secs(phaseStart, 8000)
            RPhase.LOAD -> tr("تحت الحمل… (الجوال بيسخن شوي، طبيعي) ", "Under load… (the phone may warm up, that's normal) ") + secs(phaseStart, 15000)
            RPhase.DONE -> irMohm?.let { tr("المقاومة: $it mΩ", "Resistance: $it mΩ") + "  —  " + irLabel(it) } ?: irNote
        }
        c.addView(text(status, 16f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, 0) })
        if (rPhase == RPhase.DONE) {
            c.addView(pill(tr("التالي: قياس السعة", "Next: capacity"), PETROL, Color.WHITE, true) {
                step = Step.CHARGE
                render()
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
        } else {
            c.addView(link(tr("تخطّي هذه الخطوة", "Skip this step")) {
                stopLoad()
                irNote = tr("تم التخطي", "Skipped")
                step = Step.CHARGE
                render()
            })
        }
    }

    private fun renderCharge(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("السعة الفعلية", "Actual capacity")))
        c.addView(para(tr(
            "نقيس كم طاقة تدخل البطارية مقابل كل 1% شحن، ومنها نحسب سعتها الحقيقية. نقيس 10% ونقسمها نصين نتأكد إنهم متفقين. الأدق إن البطارية تكون بين 20% و80%.",
            "We measure how much charge enters per 1% to calculate the real capacity. We measure 10% and split it in two halves to check they agree. Most accurate between 20% and 80%."
        )))
        val lv = level()
        when (cPhase) {
            CPhase.WAIT_PLUG -> {
                if (interrupted) c.addView(warn(tr(
                    "انقطع القياس لأنك طلعت من التطبيق، فبدأنا من جديد. خلّ التطبيق مفتوح لين يخلص.",
                    "The measurement was interrupted because you left the app, so it restarted. Keep the app open until it finishes."
                )))
                if (hotAbort) c.addView(warn(tr(
                    "البطارية سخنت فوق 42° أثناء القياس، فلغيناه عشان ما يطلع غلط. حط الجوال في مكان بارد وشيل الكفر، والقياس يبدأ لحاله لما تنزل تحت 40°.",
                    "The battery went above 42°C during the measurement, so we cancelled it to avoid a wrong result. Put the phone somewhere cool and remove the case; it restarts by itself below 40°C."
                )))
                c.addView(text(tr("شروط بدء القياس", "Conditions to start"), 15f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, dp(4)) })
                for ((label, ok) in chargeConditions()) {
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(0, dp(5), 0, dp(5))
                    }
                    row.addView(text(if (ok) "✓" else "✕", 15f, Fonts.bold, if (ok) GREEN else RED), LinearLayout.LayoutParams(dp(26), -2))
                    row.addView(text(label, 13.5f, Fonts.regular, if (ok) TEXT else SLATE), LinearLayout.LayoutParams(0, -2, 1f))
                    c.addView(row)
                }
                c.addView(para(tr(
                    "القياس يبدأ تلقائياً لما تتحقق الشروط. لا تستخدم الجوال ولا تطلع من التطبيق أثناء القياس. لو البطارية فوق 80%، استخدم الجوال لين تنزل ثم ارجع.",
                    "Measuring starts automatically once the conditions are met. Don't use the phone or leave the app during the test. If the battery is above 80%, use the phone until it drops, then come back."
                )))
                if (lv > 80) c.addView(warn(tr(
                    "البطارية $lv%: لازم تكون 80% أو أقل عشان القياس يكون دقيق.",
                    "Battery is $lv%: it must be 80% or less for an accurate measurement."
                )))
                c.addView(link(tr("تخطّي هذه الخطوة", "Skip this step")) { finishCharge() })
                // بطاقة السعة الأصلية ما تظهر أثناء القياس لأن الشاشة تتحدث كل ثانية
                designCard(body)
            }
            CPhase.MEASURE -> {
                val el = (SystemClock.elapsedRealtime() - measureStart) / 1000
                c.addView(stat(tr("المدة", "Elapsed"), String.format(Locale.US, "%d:%02d", el / 60, el % 60)))
                c.addView(stat(tr("النسبة اللي انقاست", "Measured range"), "$levelDelta% / 10%"))
                currentMa()?.let { c.addView(stat(tr("تيار الشحن", "Charge current"), "$it mA")) }
                estimateCapacity()?.let { c.addView(stat(tr("السعة التقديرية الحين", "Estimate so far"), "${it.first} mAh")) }
                if (points.isEmpty()) c.addView(para(tr(
                    "ننتظر أول تغيّر في نسبة الشحن عشان نبدأ العد…",
                    "Waiting for the first change in charge level to start counting…"
                )))
                c.addView(pill(
                    if (levelDelta >= 4) tr("إنهاء القياس الآن", "Finish now") else tr("إنهاء بدون قياس السعة", "Finish without capacity"),
                    PETROL, PETROL, false
                ) { finishCharge() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
            }
            CPhase.DONE -> {}
        }
    }

    private fun renderToggle(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("المقاومة الداخلية", "Internal resistance")))
        c.addView(para(tr(
            "جوالك ما يعطي الجهد بشكل مستمر، فبنقيسه لحظة فصل الشاحن وتوصيله، لأن الجوال يحدّث القراءة وقتها. نكررها لين نحصل قراءتين متفقتين.",
            "Your phone doesn't expose voltage continuously, so we read it the moment the charger is unplugged and plugged in, when the phone refreshes it. We repeat until two readings agree."
        )))
        val now = SystemClock.elapsedRealtime()
        val round = (toggleRounds + 1).coerceAtMost(3)
        val status = when (tPhase) {
            TPhase.WAIT_PLUG -> tr("وصّل الشاحن…", "Plug in the charger…")
            TPhase.WAIT_UNPLUG -> {
                val left = ((5000 - (now - tPhaseStart)) / 1000).coerceAtLeast(0)
                tr("الجولة $round: ", "Round $round: ") +
                    if (left > 0) tr("خلّ الشاحن موصول ($left ث)…", "keep the charger plugged in (${left}s)…")
                    else tr("افصل الشاحن الآن", "unplug the charger now")
            }
            TPhase.UNPLUGGED -> {
                val left = ((8000 - (now - tPhaseStart)) / 1000).coerceAtLeast(0)
                tr("الجولة $round: ", "Round $round: ") +
                    if (left > 0) tr("انتظر $left ث بدون شاحن…", "wait ${left}s unplugged…")
                    else tr("وصّل الشاحن الآن", "plug the charger back in now")
            }
            TPhase.READING -> tr("جاري القياس…", "Measuring…")
            TPhase.DONE -> ""
        }
        c.addView(text(status, 16f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, 0) })
        if (toggleR.isNotEmpty()) c.addView(para(tr("القراءات: ", "Readings: ") + toggleR.joinToString(" · ") { "$it mΩ" }))
        if (level() >= 95) c.addView(warn(tr(
            "البطارية قريبة من 100%، فتيار الشحن ضعيف والقياس ممكن ما ينجح.",
            "The battery is near 100%, so charging current is low and the test may not succeed."
        )))
        c.addView(link(tr("تخطّي هذه الخطوة", "Skip this step")) {
            finishToggle(skipped = true)
            render()
        })
    }

    private fun renderDischarge(body: LinearLayout) {
        val c = card(body)
        c.addView(title(tr("تأكيد السعة بالتفريغ (اختياري)", "Confirm capacity by discharge (optional)")))
        c.addView(para(tr(
            "قياس ثاني مستقل: نشغّل حمل على الجوال بدون شاحن ونقيس الطاقة اللي تطلع مقابل كل 1%. لو اتفق مع قياس الشحن ترتفع الثقة ويقل هامش الخطأ. ياخذ 8-15 دقيقة.",
            "A second, independent measurement: we load the phone off the charger and measure the charge drawn per 1%. If it agrees with the charging measurement, confidence rises and the margin shrinks. Takes 8-15 minutes."
        )))
        when (dPhase) {
            DPhase.OFFER -> {
                c.addView(pill(tr("ابدأ القياس التأكيدي", "Start confirmation"), PETROL, Color.WHITE, true) {
                    dPhase = DPhase.WAIT_UNPLUG
                    render()
                }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
                c.addView(pill(tr("تخطّي وعرض النتيجة", "Skip and show result"), PETROL, PETROL, false) {
                    dPhase = DPhase.DONE
                    step = Step.DONE
                    buildReport()
                    render()
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
            }
            DPhase.WAIT_UNPLUG -> c.addView(text(tr("افصل الشاحن عشان نبدأ…", "Unplug the charger to begin…"), 16f, Fonts.bold, TEXT).apply { setPadding(0, dp(12), 0, 0) })
            DPhase.MEASURE -> {
                val el = (SystemClock.elapsedRealtime() - dStart) / 1000
                val drop = if (dPoints.size >= 2) dPoints.first().level - dPoints.last().level else 0
                c.addView(stat(tr("المدة", "Elapsed"), String.format(Locale.US, "%d:%02d", el / 60, el % 60)))
                c.addView(stat(tr("النسبة اللي انقاست", "Measured range"), "$drop% / 4%"))
                currentMa()?.let { c.addView(stat(tr("تيار التفريغ", "Discharge current"), "$it mA")) }
                c.addView(para(tr("الجوال بيسخن شوي بسبب الحمل، هذا طبيعي.", "The phone will warm up a little from the load; that's normal.")))
                c.addView(pill(tr("إنهاء الآن", "Finish now"), PETROL, PETROL, false) { finishDischarge() },
                    LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
            }
            DPhase.DONE -> {}
        }
    }

    private fun renderDone(body: LinearLayout) {
        val r = report ?: return
        val c = card(body)
        c.addView(text(r.verdictText, 24f, Fonts.bold, r.verdictColor))
        c.addView(text(r.confidenceText, 14f, Fonts.medium, SLATE).apply { setPadding(0, dp(2), 0, dp(8)) })
        r.healthText?.let { c.addView(stat(tr("صحة البطارية", "Battery health"), it)) }
        c.addView(stat(tr("مصدر النسبة", "Health source"), r.healthSourceText))
        r.measuredMah?.let { c.addView(stat(tr("السعة أثناء الشحن", "Capacity (charging)"), "$it mAh")) }
        r.dischargeMah?.let { c.addView(stat(tr("السعة أثناء التفريغ", "Capacity (discharge)"), "$it mAh")) }
        r.segmentsAgree?.let { c.addView(stat(tr("نصفين القياس", "Measurement halves"), if (it) tr("متفقين ✓", "Agree ✓") else tr("متفاوتين", "Differ"))) }
        r.designMah?.let { c.addView(stat(tr("السعة الأصلية", "Design capacity"), "$it mAh (${r.sourceText})")) }
        r.cycles?.let { c.addView(stat(tr("دورات الشحن", "Charge cycles"), "$it")) }
        c.addView(stat(tr("المقاومة الداخلية", "Internal resistance"), r.irMohm?.let { "$it mΩ — " + irLabel(it) } ?: tr("غير متاحة", "Not available")))
        if (r.irNote.isNotBlank()) c.addView(para(r.irNote))
        r.maxChargeMa?.let { c.addView(stat(tr("أعلى تيار شحن", "Peak charge current"), "$it mA")) }
        r.maxTempC?.let { c.addView(stat(tr("أعلى حرارة أثناء الشحن", "Max temp while charging"), String.format(Locale.US, "%.1f°C", it))) }
        r.mfgDate?.let { c.addView(stat(tr("تاريخ تصنيع البطارية", "Battery made"), fmtDate(it))) }
        r.firstUse?.let { c.addView(stat(tr("أول استخدام", "First used"), fmtDate(it))) }
        c.addView(stat(tr("انتفاخ", "Swelling"), if (r.swollen) tr("نعم ⚠", "Yes ⚠") else tr("لا", "No")))

        if (!r.determined) {
            c.addView(text(tr("ليش ما قدرنا نحدد:", "Why we couldn't determine it:"), 14f, Fonts.bold, TEXT).apply { setPadding(0, dp(10), 0, dp(2)) })
            for (m in r.missing) c.addView(para("•  $m"))
            c.addView(para(tr(
                "ما نعطي نسبة إلا بشروط صارمة، عشان ما نظلم البطارية ولا نجاملها. أعد الفحص بعد ما تتحقق الشروط.",
                "We only give a percentage under strict conditions, so the battery is neither under- nor over-rated. Retest once the conditions are met."
            )))
        }
        if (r.swollen) c.addView(para(tr(
            "البطارية المنتفخة خطر حريق. لا تشحن الجوال، وغيّر البطارية عند فني موثوق.",
            "A swollen battery is a fire risk. Do not charge the phone; have the battery replaced by a trusted technician."
        )).apply { setTextColor(RED) })
        if (r.determined && r.confidence == 1 && !r.swollen) c.addView(para(tr(
            "الثقة متوسطة: الحكم يعطي البطارية الأفضلية ضمن هامش الخطأ عشان ما نظلمها. للثقة العالية سوِّ القياس التأكيدي بالتفريغ.",
            "Medium confidence: the verdict gives the battery the benefit of the doubt within the margin. For high confidence, run the discharge confirmation."
        )))

        c.addView(pill(tr("حفظ النتيجة", "Save result"), PETROL, Color.WHITE, true) { save() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })
        c.addView(pill(tr("إعادة الفحص", "Retest"), PETROL, PETROL, false) { recreate() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        c.addView(link(tr("نسخ بيانات التشخيص", "Copy diagnostics")) { copyDiagnostics() })
        designCard(body)
    }

    /** بطاقة السعة الأصلية مع إمكانية التعديل */
    private fun designCard(body: LinearLayout) {
        val c = card(body)
        val d = DesignCapacity.resolve(this)
        c.addView(title(tr("السعة الأصلية للبطارية", "Original battery capacity")))
        c.addView(para(
            if (d != null) "${d.first} mAh  ·  " + when (d.second) {
                CapSource.TABLE -> tr("من قاعدة بيانات الموديلات", "from the model database")
                CapSource.SYSTEM -> tr("من النظام (ممكن تكون غير دقيقة)", "from the system (may be inaccurate)")
                CapSource.MANUAL -> tr("أدخلتها يدوياً", "entered manually")
            } else tr(
                "ما لقينا السعة الأصلية لهذا الموديل. اكتبها من مواصفات الجوال عشان نحسب نسبة الصحة.",
                "We could not find the original capacity for this model. Enter it from the phone's specs to calculate health."
            )
        ))
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = tr("مثلاً 5000", "e.g. 5000")
            setText(DesignCapacity.manual(this@BatteryTestActivity)?.toString() ?: "")
            typeface = Fonts.regular
            textSize = 15f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), LINE)
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(pill(tr("حفظ", "Save"), PETROL, Color.WHITE, true) {
            val v = input.text.toString().trim().toIntOrNull()
            DesignCapacity.setManual(this, v?.takeIf { it in 1000..12000 })
            if (step == Step.DONE) buildReport()
            render()
        }, LinearLayout.LayoutParams(dp(90), dp(48)).apply { marginStart = dp(10) })
        c.addView(row)
    }

    private fun irLabel(r: Int): String = when {
        r <= 180 -> tr("ممتازة", "excellent")
        r <= 300 -> tr("طبيعية", "normal")
        r <= 450 -> tr("مرتفعة", "high")
        else -> tr("مرتفعة جداً", "very high")
    }

    private fun secs(start: Long, total: Long): String {
        val left = ((total - (SystemClock.elapsedRealtime() - start)) / 1000).coerceAtLeast(0)
        return "($left" + tr(" ث)", "s)")
    }

    private fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(ms))

    // ---------- عناصر ----------
    private fun card(body: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
        }
        body.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return c
    }

    private fun title(s: String) = text(s, 18f, Fonts.bold, TEXT)

    private fun para(s: String) = text(s, 14f, Fonts.regular, SLATE).apply {
        setLineSpacing(0f, 1.3f)
        setPadding(0, dp(6), 0, 0)
    }

    private fun warn(s: String) = para(s).apply { setTextColor(0xFFC98A1B.toInt()) }

    private fun stat(label: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, dp(7))
        }
        row.addView(text(label, 14f, Fonts.regular, SLATE), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 14f, Fonts.bold, TEXT).apply { gravity = Gravity.END })
        return row
    }

    private fun row2(a: View, b: View): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(16), 0, 0)
        }
        row.addView(a, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(6) })
        row.addView(b, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(6) })
        return row
    }

    private fun link(s: String, onClick: () -> Unit) = text(s, 14f, Fonts.bold, SLATE).apply {
        setPadding(0, dp(16), 0, dp(4))
        setOnClickListener { onClick() }
    }

    private fun text(s: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = size
        typeface = face
        setTextColor(color)
    }

    private fun pill(label: String, bg: Int, fg: Int, filled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            textSize = 15f
            typeface = Fonts.bold
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                if (filled) setColor(bg) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), bg)
                }
            }
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
