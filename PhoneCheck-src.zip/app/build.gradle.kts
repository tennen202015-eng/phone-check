import java.net.HttpURLConnection
import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.phonecheck.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.phonecheck.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 22
        versionName = "7.7"
    }

    // مفتاح توقيع ثابت للنسخ التجريبية، عشان التحديث يتثبّت فوق القديم.
    // للنشر في Google Play نستخدم مفتاح سري منفصل (ما يترفع للمستودع).
    signingConfigs {
        create("testing") {
            storeFile = file("testing.keystore")
            storePassword = "phonecheck-test"
            keyAlias = "phonecheck"
            keyPassword = "phonecheck-test"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("testing")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}

// تنزيل خط IBM Plex Sans Arabic وقت البناء (رخصة OFL). لو فشل التنزيل يستخدم التطبيق خط النظام.
val fontDir = file("src/main/assets/fonts")
val downloadFonts by tasks.registering {
    outputs.dir(fontDir)
    doLast {
        fontDir.mkdirs()
        val sources = listOf(
            "https://github.com/google/fonts/raw/main/ofl/ibmplexsansarabic/",
            "https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexsansarabic/",
        )
        val files = mapOf(
            "IBMPlexSansArabic-Regular.ttf" to "plex_regular.ttf",
            "IBMPlexSansArabic-SemiBold.ttf" to "plex_semibold.ttf",
            "IBMPlexSansArabic-Bold.ttf" to "plex_bold.ttf",
        )
        for ((src, dst) in files) {
            val out = File(fontDir, dst)
            if (out.exists() && out.length() > 10_000) continue
            for (base in sources) {
                try {
                    val conn = URI(base + src).toURL().openConnection() as HttpURLConnection
                    conn.instanceFollowRedirects = true
                    conn.connectTimeout = 20_000
                    conn.readTimeout = 30_000
                    conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
                    if (out.length() > 10_000) {
                        println("Downloaded font $dst")
                        break
                    }
                } catch (e: Exception) {
                    println("Font download failed from $base: ${e.message}")
                    out.delete()
                }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadFonts) }
