plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.phonecheck.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.phonecheck.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("com.google.android.material:material:1.12.0")
}

// تنزيل خط IBM Plex Sans Arabic وقت البناء (رخصة OFL). لو فشل التنزيل يستخدم التطبيق خط النظام.
val fontDir = file("src/main/assets/fonts")
val downloadFonts by tasks.registering {
    outputs.dir(fontDir)
    doLast {
        fontDir.mkdirs()
        val sources = listOf(
            "https://github.com/google/fonts/raw/main/ofl/ibmplexsansarabic/",
            "https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexsansarabic/",
        )
        val files = mapOf(
            "IBMPlexSansArabic-Regular.ttf" to "plex_regular.ttf",
            "IBMPlexSansArabic-SemiBold.ttf" to "plex_semibold.ttf",
            "IBMPlexSansArabic-Bold.ttf" to "plex_bold.ttf",
        )
        for ((src, dst) in files) {
            val out = File(fontDir, dst)
            if (out.exists() && out.length() > 10_000) continue
            for (base in sources) {
                try {
                    val conn = java.net.URI(base + src).toURL().openConnection() as java.net.HttpURLConnection
                    conn.instanceFollowRedirects = true
                    conn.connectTimeout = 20_000
                    conn.readTimeout = 30_000
                    conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
                    if (out.length() > 10_000) {
                        println("Downloaded font $dst")
                        break
                    }
                } catch (e: Exception) {
                    println("Font download failed from $base: ${e.message}")
                    out.delete()
                }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadFonts) }
